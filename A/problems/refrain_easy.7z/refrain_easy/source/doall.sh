#!/bin/sh

echo "unzip tests..."
unrar -y x tests.rar

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

