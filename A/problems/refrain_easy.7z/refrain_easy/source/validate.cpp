#include <testlib.h>

const int maxn = 100;
const int maxm = 10;

int main( int argc, char *argv[] ) {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxm);
  inf.readEoln();
  for (int i = 0; i < n; i++) {
    inf.readInt(1, m);
    if (i == n - 1)
      inf.readEoln();
    else
      inf.readSpace();
  }
  inf.readEof();
  return 0;
}

