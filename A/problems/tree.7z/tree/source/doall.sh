#!/bin/bash

PC="fpc -Mdelphi"
GENERATORS="gensmall gen genline genaline genzigzag genfulltree genraggedzigzag genstrangezigzag shuffle"

for i in $GENERATORS
do
	$PC "$i.dpr"
done

./gensmall 7 > 09
./gensmall 20 > 10
./gensmall 77 > 11
./gen 300 > 12
./genline 1000 | ./shuffle > 13
./genaline 1000 | ./shuffle > 14
./genline 50000 | ./shuffle > 15
./genaline 50000 | ./shuffle > 16
./gen 3456 > 17
./gen 13212 > 18
./gen 38180 > 19
./gen 49999 > 20
./genfulltree | ./shuffle > 21
./genzigzag 50000 | ./shuffle > 22
./genraggedzigzag 50000 | ./shuffle > 23
./genstrangezigzag 50000 | ./shuffle > 24

for i in "$GENERATORS"
do
	rm $i.o $i -f
done

for i in ??.manual
do 
	cp $i ../tests/${i/\.manual/}
done
mv ?? ../tests/
