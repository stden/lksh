#include <testlib.h>
#include <set>

const int maxn = 50000;
const int maxc = 30000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readEoln();
  std::set <int> a, b;
  for (int i = 0; i < n; i++) {
    int x = inf.readInt(-maxc, maxc);
    inf.readSpace();
    int y = inf.readInt(-maxc, maxc);
    inf.readEoln();
    ensuref(a.count(x) == 0, "первый ключ %d повторяется", x);
    ensuref(b.count(y) == 0, "второй ключ %d повторяется", x);
    a.insert(x), b.insert(y);
  }
  inf.readEof();
  return 0;
}

