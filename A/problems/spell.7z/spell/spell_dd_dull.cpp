#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>
#include <map>
#include <vector>
using namespace std;

int n;
string wrd[21];

void Load()
{
	scanf("%d", &n);
	int i;
	for (i = 0; i < n; i++)
	{
		char c = getchar();
		while (! ((c >= 'a') && (c <= 'z'))) c = getchar();
		wrd[i] = "";
		while ((c >= 'a') && (c <= 'z'))
		{
			wrd[i] += c;
			c = getchar();
		}
	}
}

map<string, int> subs;

void Solve()
{
	subs.clear();
	int i, j, k;
	for (i = 0; i < n; i++)
	{
		string cur;
		for (j = 0; j < wrd[i].size(); j++)
		{
			cur = "";
			for (k = j; k < wrd[i].size(); k++)
			{
				cur += wrd[i][k];
				if (subs.find(cur) == subs.end()) subs.insert(make_pair(cur, 0));
				subs[cur] |= (1 << i);
			}
		}
	}
	vector<string> gss;
	gss.clear();
	map<string, int>::iterator p;
	for (p = subs.begin(); p != subs.end(); p++)
	{
		if (p->second == (1 << n) - 1)
		{
			gss.push_back(p->first);
		}	
	}
	int q;
	scanf("%d", &q);
	for (i = 0; i < q; i++)
	{
		scanf("%d", &k);
		printf("%s\n", gss[k - 1].c_str());
	}
}

int main()
{
	freopen("spell.in", "rt", stdin);
	freopen("spell.out", "wt", stdout);
	Load();
	Solve();
	return 0;
}
