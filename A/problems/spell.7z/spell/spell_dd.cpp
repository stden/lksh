#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cassert>
using namespace std;

#pragma comment (linker, "/STACK:20000000")

int n;
char s[110000];
int ls;

void Load()
{
	scanf("%d", &n);
	ls = 0;
	int i;
	for (i = 0; i < n; i++)
	{
		char c = getchar();
		while (! ((c >= 'a') && (c <= 'z')) ) c = getchar();
		while ((c >= 'a') && (c <= 'z'))
		{
			s[ls] = c - 'a';
			ls++;
			c = getchar();
		}
		s[ls] = 26 + i;
		ls++;
	}
}

int go[210000][50];
int nstate;
int len[210000];
int suf[210000];
int reach[210000];

int Dfs(int ver)
{
	reach[ver] = 0;
	int i;
	for (i = 0; i < 26; i++)
	{
		if (go[ver][i] == -1) continue;
		if (reach[go[ver][i]] == -1) Dfs(go[ver][i]);
		reach[ver] |= reach[go[ver][i]];
	}
	for (i = 26; i < 26 + n; i++)
	{
		if (go[ver][i] != -1)
		{
			reach[ver] |= (1 << (i - 26));
		}
	}
	return reach[ver];
}

long long num[210000];

long long Count(int ver)
{
	if (num[ver] != -1) return num[ver];
	num[ver] = 0;
	if ((reach[ver] == (1 << n) - 1) && (ver != 1)) num[ver] = 1;
	int j;
	for (j = 0; j < 26; j++)
	{
		if (go[ver][j] != -1) num[ver] += Count(go[ver][j]);
	}
	return num[ver];
}

int totalanslen;

void RAns(int ver, long long k)
{
	if ((k == 1) && (ver != 1)) return;
	if (ver != 1) k--;
	int j;
	for (j = 0; j < 26; j++)
	{
		if (go[ver][j] == -1) continue;
		long long cr = Count(go[ver][j]);
		if (cr >= k)
		{
			totalanslen++;
			printf("%c", (char)(j + 'a'));
			RAns(go[ver][j], k);
			return;
		}
		else
		{
			k -= cr;
		}
	}
}

void Solve()
{
	int i;
	memset(go, 0xFF, sizeof(go));
	int last;
	nstate = 1;
	len[1] = 0;
	suf[1] = 0;
	last = 1;
	for (i = 0; i < ls; i++)
	{
		char csym = s[i];
		nstate++;
		int cst = nstate;
		len[cst] = i + 1;
		int cur = last;
		while ((cur != 0) && (go[cur][csym] == -1))
		{
			go[cur][csym] = cst;
			cur = suf[cur];
		}
		if (cur == 0) suf[cst] = 1;
		else
		{
			int nxt = go[cur][csym];
			if (len[nxt] == len[cur] + 1) suf[cst] = nxt;
			else
			{
				nstate++;
				int j;
				for (j = 0; j < 50; j++)
				{
					go[nstate][j] = go[nxt][j];
				}
				suf[nstate] = suf[nxt];
				suf[nxt] = suf[cst] = nstate;
				len[nstate] = len[cur] + 1;
				while ((cur != 0) && (go[cur][csym] == nxt))
				{
					go[cur][csym] = nstate;
					cur = suf[cur];
				}
			}
		}
		last = cst;
	}
	memset(reach, 0xFF, sizeof(reach));
	Dfs(1);
	memset(num, 0xFF, sizeof(num));
	int p;
	scanf("%d", &p);
	totalanslen = 0;
	for (i = 0; i < p; i++)
	{
		long long cpos;
		scanf("%lld", &cpos);
		RAns(1, cpos);
		printf("\n");
	}
	assert(totalanslen <= 100000);
	cerr << "Total answer length: " << totalanslen << "\n";
}

int main()
{
	freopen("spell.in", "rt", stdin);
	freopen("spell.out", "wt", stdout);
	Load();
	Solve();
	return 0;
}
