
#include <cstdio>
#include <iostream>
#include <map>
#include <vector>
#include <memory.h>



using namespace std;

class CEdg{
public:
	int nxt;
	int st;
	int len;
};
class CVer{
public:
	CEdg edg[46];
	int link;
	CEdg prev;
	CVer(){memset(edg, -1, sizeof(edg)); prev.nxt = prev.st = prev.len = link = -1;}
};

class SuffTree{
	public:
	CVer *suf;		
	char *s;
	int len;
	int nv, Count, lstcrt, Max, cur, need;
	int *Done;
	bool flg;
	SuffTree(){nv = Count = lstcrt = 0; flg = false;}
	void Add(int ver, int st, int en);
	void Build(char *ss, int llen);
	int GetLen(int ver);
	int Find(int ver, int &st, int en, int &pos);
	void SEA(int st);
};

void SuffTree::Add(int ver, int st, int en)
{
	nv++;
	suf[nv].prev.st = st;
	suf[nv].prev.len = en - st + 1;
	suf[nv].prev.nxt = ver;
	CEdg tmp;
	tmp.st = st;
	tmp.len = en - st + 1;
	tmp.nxt = nv;
	suf[ver].edg[s[st]] = tmp;
}


int SuffTree::GetLen(int ver)
{
	int l = suf[ver].prev.len;
	if (suf[ver].prev.st + suf[ver].prev.len - 1 > Max) l = Max - suf[ver].prev.st + 1;
	return l;
}

int SuffTree::Find(int ver, int &st, int en, int &pos)
{
	CEdg tmp;
	while (st <= en) {
		if (suf[ver].edg[s[st]].nxt == -1) {
			pos = 0;
			return ver;
		}
		tmp = suf[ver].edg[s[st]];
		if (en - st + 1 >= tmp.len) {
			int t = tmp.len;
			ver = tmp.nxt;
			st += t;
		} else break;
	}
	pos = en - st + 1;
	tmp = suf[ver].edg[s[st]];
	if (tmp.nxt == -1) {
		if (pos != 0){
			int t = 0;
			pos /= t;
		}
		return ver;
	}
	if (s[ tmp.st + pos ] == s[en + 1]) {
		if (tmp.st + pos > Max) {pos = -2; return ver;}
		pos = -1;
	}
	return ver;
}


void SuffTree::SEA(int st)
{
	
	lstcrt = 0;
	int t, nxt;
	Count--;
	flg = false;
	while (Count < st) {
        Count++;
		if (flg) {
			need = st;
			while (suf[cur].link < 0) {
				need -= GetLen(cur);
				cur = suf[cur].prev.nxt;
			}
			if (cur == 0) {
				need++;
			} 
			cur = suf[cur].link;
		}
		flg = true;
		int pos;
		cur = Find(cur, need, st - 1, pos);
		if (pos == -1) {
			if (lstcrt != 0) suf[lstcrt].link = cur;
			lstcrt = 0;
			return;
		}
		else 
		if (pos == -2) {
			cur = Done[Count]; 
        } else 
		if (pos == 0) {
			if (lstcrt != 0) suf[lstcrt].link = cur;
			lstcrt = 0;
			Add(cur, need, len - 1);
			Done[Count] = cur = nv;
		}
		else 
		{
			int ST, LEN;
			ST = suf[cur].edg[s[need]].st;
			LEN = suf[cur].edg[s[need]].len;
			t = suf[cur].edg[s[need]].st + pos;
			nv++;
			nxt = suf[cur].edg[s[need]].nxt;
			suf[cur].edg[s[need]].nxt = nv;
			suf[cur].edg[s[need]].st = ST;
			suf[cur].edg[s[need]].len = t - ST;
			suf[nv].edg[s[t]].st = t; 
			suf[nv].edg[s[t]].len = ST + LEN - t;
			suf[nv].edg[s[t]].nxt = nxt;
			suf[nv].prev.st = suf[cur].edg[s[need]].st;
			suf[nv].prev.len = suf[cur].edg[s[need]].len;
			suf[nv].prev.nxt = cur;
			suf[nxt].prev.st = suf[nv].edg[s[t]].st;
			suf[nxt].prev.len = suf[nv].edg[s[t]].len;
			suf[nxt].prev.nxt = nv;
			if (lstcrt != 0)
				suf[lstcrt].link = nv;
            lstcrt = nv;
            Add(nv, need  + GetLen(nv), len - 1);
            Done[Count] = cur = nv;
		}
	}
	if (lstcrt != 0) suf[lstcrt].link = 0;
	lstcrt = 0;
	need = Count;
	cur = 0;
}

void SuffTree::Build(char *ss, int llen)
{   
	int i;
	suf = new CVer[2 * llen + 10];
	Done = new int[2 * llen + 10];
	s = ss;
	len = llen;
	Add(0, 0, len - 1);

	Count = 0;
	Done[0] = 1;
	cur = 0;
	need = 0;
	Max = 0;
//	memset(suf, -1, sizeof(suf));
	suf[0].link = 0;
	for (i = 1; i < len; i++) {
		SEA(i);
		Max++;
	}
   	cerr << "DONE!\n";
}

char s[111111];
int mark[211111];
int wh[22];
int len;
int n;
int m;

void Load()
{
	cin >> n;
	int i;
	char c;
	len = 0;
	for (i = 1; i <= n; i++) {
		c = getchar();
		while (c < 'a' || c > 'z') c = getchar();
		while (c >= 'a' && c <= 'z') {
			s[len] = c - 'a';
			len++;
			c = getchar();
		}		
		s[len] = 'z' - 'a' + i;
		len++;
		wh[i] = len - 1;
	}
	if (n == 1) len--;

//	for (i = 0; i < len; i++) cerr << (int)s[i] << " ";
}


string ans;
long long cnt[211111];
SuffTree tree;

void Dfs(int ver, int ww)
{
	int i;
	int j;
	int st, en;
	int nxt;
	int mn, mj;
	for (i = 0; i < 26 + n; i++) {
		if (tree.suf[ver].edg[i].nxt != -1) {
			nxt = tree.suf[ver].edg[i].nxt;
			st = tree.suf[ver].edg[i].st;
			en = tree.suf[ver].edg[i].len + st - 1;
//			cerr << "Dfs " << ver << " ";
//			for (j = st; j <= en; j++) cerr << (int) s[j];
//			cerr << " nxt = " << nxt << "\n";
			mn = -1;
			mj = -1;
			for (j = 1; j <= n; j++) {
				if (wh[j] >= st && wh[j] <= en) {
					if (mn < 0 || mn > wh[j] - st) {
						mn = wh[j] - st;
						mj = j;
					}
				}
			}
			if (mj == -1) {
				Dfs(nxt, ww);
			} else {
				Dfs(nxt, 1);
				mark[ver] |= 1 << (mj - 1);
			}
			mark[ver] |= mark[nxt];
		}
	}
	if (ww) mark[ver] = 0;
	if (n == 1) mark[ver] = 1;
//	cerr << "mark[" << ver << "] = " << mark[ver] << "\n";    

}

void Count(int ver)
{
	int i, j, st, en;
	if (mark[ver] != (1 << n) - 1) {
		cnt[ver] = 0;
		return;
	}
	int nxt;
	int mn;
	int tm;
	for (i = 0; i < 26 + n; i++) {
		if (tree.suf[ver].edg[i].nxt != -1) {
			nxt = tree.suf[ver].edg[i].nxt;
			st = tree.suf[ver].edg[i].st;
			en = tree.suf[ver].edg[i].len + st - 1;
			Count(nxt);
			cnt[ver] += cnt[nxt];
			mn = en - st + 1;
			if (mark[nxt] != (1 << n) - 1)
			{
				mn = 0;
			}
			cnt[ver] += mn;
		}
	}
}


void Find(int ver, long long id)
{
	int i;
	long long cc;
	int nxt, st, en, mn, j;
	for (i = 0; i < 26 + n; i++) {
		if (tree.suf[ver].edg[i].nxt != -1) {
			nxt = tree.suf[ver].edg[i].nxt;
			st = tree.suf[ver].edg[i].st;
			en = tree.suf[ver].edg[i].len + st - 1;
			cc  = cnt[nxt];
			mn = en - st + 1;
			if (mark[nxt] != (1 << n) - 1) {
				continue;
			}
			cc += mn;
			if (cc < id) {
				id -= cc;
			} else {
				if (en - st + 1 >= id) {
					for (j = 0; j < id; j++) ans.push_back(s[st + j] + 'a');
					return;
				} else {
					for (j = st; j <= en; j++) ans.push_back(s[j] + 'a');					
					Find(nxt, id - en + st - 1);
					return;
				}
			}
		}
	}
}

void Solve()
{
	tree.Build(s, len);
	Dfs(0, 0);
	Count(0);
	int i;
	cin >> m;
	long long k;
	for (i = 1; i <= m; i++) {
		cin >> k;
		ans.clear();
		Find(0, k);
		printf("%s\n", ans.c_str());
	}
}

int main()
{
	freopen("spell.in", "rt", stdin);
	freopen("spell.out", "wt", stdout);
	Load();
	Solve();
	return 0;
}
