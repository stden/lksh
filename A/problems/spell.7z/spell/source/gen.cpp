#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include "random.h"

using namespace std;

long long R64()
{
	long long a = nextrand();
	a <<= 16;
	a |= nextrand();
	a <<= 16;
	a |= nextrand();
	a <<= 16;
	a |= nextrand();
	if (a < 0) a = -a;
	return a;
}

int ls;
int n;
char s[110000];

int go[210000][50];
int nstate;
int len[210000];
int suf[210000];
int reach[210000];

int Dfs(int ver)
{
	reach[ver] = 0;
	int i;
	for (i = 0; i < 26; i++)
	{
		if (go[ver][i] == -1) continue;
		if (reach[go[ver][i]] == -1) Dfs(go[ver][i]);
		reach[ver] |= reach[go[ver][i]];
	}
	for (i = 26; i < 26 + n; i++)
	{
		if (go[ver][i] != -1)
		{
			reach[ver] |= (1 << (i - 26));
		}
	}
	return reach[ver];
}

long long num[210000];

long long Count(int ver)
{
	if (num[ver] != -1) return num[ver];
	num[ver] = 0;
	if ((reach[ver] == (1 << n) - 1) && (ver != 1)) num[ver] = 1;
	int j;
	for (j = 0; j < 26; j++)
	{
		if (go[ver][j] != -1) num[ver] += Count(go[ver][j]);
	}
	return num[ver];
}

void RAns(int ver, long long k)
{
	if ((k == 1) && (ver != 1)) return;
	if (ver != 1) k--;
	int j;
	for (j = 0; j < 26; j++)
	{
		if (go[ver][j] == -1) continue;
		long long cr = Count(go[ver][j]);
		if (cr >= k)
		{
			printf("%c", (char)(j + 'a'));
			RAns(go[ver][j], k);
			return;
		}
		else
		{
			k -= cr;
		}
	}
}

long long total;

void Solve()
{
	int i;
	memset(go, 0xFF, sizeof(go));
	int last;
	nstate = 1;
	len[1] = 0;
	suf[1] = 0;
	last = 1;
	for (i = 0; i < ls; i++)
	{
		char csym = s[i];
		nstate++;
		int cst = nstate;
		len[cst] = i + 1;
		int cur = last;
		while ((cur != 0) && (go[cur][csym] == -1))
		{
			go[cur][csym] = cst;
			cur = suf[cur];
		}
		if (cur == 0) suf[cst] = 1;
		else
		{
			int nxt = go[cur][csym];
			if (len[nxt] == len[cur] + 1) suf[cst] = nxt;
			else
			{
				nstate++;
				int j;
				for (j = 0; j < 50; j++)
				{
					go[nstate][j] = go[nxt][j];
				}
				suf[nstate] = suf[nxt];
				suf[nxt] = suf[cst] = nstate;
				len[nstate] = len[cur] + 1;
				while ((cur != 0) && (go[cur][csym] == nxt))
				{
					go[cur][csym] = nstate;
					cur = suf[cur];
				}
			}
		}
		last = cst;
	}
	memset(reach, 0xFF, sizeof(reach));
	Dfs(1);
	memset(num, 0xFF, sizeof(num));
	total = Count(1);
}


int main(int argc, char *argv[])
{
	int minn = atoi(argv[1]);
	int maxn = atoi(argv[2]);
	int minl = atoi(argv[3]);
	int maxl = atoi(argv[4]);
	int minq = atoi(argv[5]);
	int maxq = atoi(argv[6]);
	int numl = atoi(argv[7]);
	if (argc > 8) initrand(atoi(argv[8]));
	else
	{	
		initrand(0);
	}
	int totlen = 100000;
	//generating strings
	n = R(minn, maxn);
	cout << n << "\n";
	int i;
	ls = 0;
	for (i = 0; i < n; i++)
	{
		int clen = R(minl, maxl);
		clen = min(clen, totlen - (n - i - 1));
		totlen -= clen;
		int j;
		for (j = 0; j < clen; j++)
		{
			char curc = R(0, numl - 1) + 'a';
			s[ls] = curc - 'a';
			ls++;
			cout << curc;
		}
		cout << "\n";
		s[ls] = 26 + i;
		ls++;
	}
	Solve();
	int q = R(minq, maxq);
	cerr << "Generating test with total of " << total << " substrings\n";
	cout << q << "\n";
	for (i = 0; i < q; i++)
	{
		cout << R64() % total + 1 << "\n";
	}
	return 0;
}
