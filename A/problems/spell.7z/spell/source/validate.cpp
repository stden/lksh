#include <string>
#include <testlib.h>

using namespace std;

const int MAXN = 20;
const int MAXSUML = 100000;
const int MAXM = 100000;
                        	
int main() 
{
	registerValidation();
	int n = inf.readInt(1, MAXN);
	inf.readEoln();
	int i;
	int slen = 0;
	for (i = 0; i < n; i++) 
	{
		string s = inf.readToken("[a-z]{1,100000}");
		slen += s.length();
    	inf.readEoln();
	}
	ensuref(slen <= MAXSUML, "Total length of strings is %d > %d", slen, MAXSUML);
	int m = inf.readInt(1, MAXM);
	inf.readEoln();
	for (i = 0; i < m; i++)
	{
		inf.readLong();
		inf.readEoln();
	}
	inf.readEof();
	return 0;
}

