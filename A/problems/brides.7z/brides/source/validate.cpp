#include <testlib.h>

const int maxn = 200;
const int maxm = 2000;
const int maxk = 100;
const int maxw = 1000000;

int main() {
  registerValidation();
  int n = inf.readInt(2, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxm);
  inf.readSpace();
  inf.readInt(1, maxk);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    int a = inf.readInt(1, n);
    inf.readSpace();
    int b = inf.readInt(1, n);
    inf.readSpace();
    inf.readInt(1, maxw);
    inf.readEoln();
    ensuref(a != b, "loop around vertex %d", a);
  }
  inf.readEof();
  return 0;
}

