// min-cost-k-flow
// dijkstra

#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:30000000")

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include <memory>
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define cinfile "brides.in"
#define coutfile "brides.out"

#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define f0(a) memset(a, 0, sizeof(a))

#define VI vector<int>
#define pb push_back
#define all(a) a.begin(), a.end()

const int inf = (int)1e+9;
const double eps = (double)1e-9;
const int nmax = 201;
const int mmax = 2001;

struct tedge {
    int x, y;
    int cost, f;
} edge[mmax*2];

vector < VI > d;
int n, m, k, kk;

void init()
{
    scanf("%d%d%d", &n, &m, &k);
    kk = k;
    int x, y, z;
    d.resize(n);
    forn(i, m) {
        scanf("%d%d%d", &x, &y, &z);
        --x;
        --y;
        edge[2*i].x = x;
        edge[2*i].y = y;
        edge[2*i].cost = z;
        edge[2*i].f = 0;
        d[x].pb(2*i);
        edge[2*i + 1].x = y;
        edge[2*i + 1].y = x;
        edge[2*i + 1].cost = z;
        edge[2*i + 1].f = 0;
        d[y].pb(2*i + 1);
    }
}

int dist[nmax];
int way[nmax];
int phi[nmax];
int use[nmax];

void solve()
{
    f0(phi);
    while (k > 0) {
        forn(i, n) {
            dist[i] = inf;
            way[i] = -1;
        }
        f0(use);
        dist[0] = 0;

        while (true) {
            int j = 0;
            forn(i, n) if (use[i] == 0) {
                if (use[j] == 1 || (use[j] == 0 && dist[i] < dist[j])) j = i;
            }
            if (use[j] == 1 || dist[j] == inf) break;
            use[j] = 1;

            forn(i, d[j].size()) {
                int t = d[j][i];
                int x = edge[t].x;
                int y = edge[t].y;
                if (edge[t].f == 1 || use[y] == 1) continue;
                int z = dist[x] + phi[x] - phi[y];
                if (edge[t].f < 0) z -= edge[t].cost;
                else z += edge[t].cost;

                if (dist[y] > z) {
                    dist[y] = z;
                    way[y] = t;
                }
            }
            if (j == n - 1) break;
        }
        if (dist[n - 1] == inf) break;

        int y = n - 1;
        while (y > 0) {
            int t = way[y];
            ++edge[t].f;
            --edge[t ^ 1].f;
            y = edge[t].x;
        }
        
        forn(i, n) {
            phi[i] += min(dist[i], dist[n - 1]);
        }

        --k;
    }
}

void writeanswer()
{
    if (k == 0) {
        double answer = 0;
        forn(t, 2*m) if (edge[t].f == 1) {
            answer += edge[t].cost;
        }
        printf("%0.5lf\n", answer / (double)kk);
        forn(i, d[0].size()) {
            int t = d[0][i];
            if (edge[t].f == 1) {
                VI ans;
                ans.pb(t / 2 + 1);
                int x = edge[t].y;
                while (x != n - 1) {
                    forn(j, d[x].size()) if (edge[d[x][j]].f == 1) {
                        ans.pb(d[x][j] / 2 + 1);
                        edge[d[x][j]].f = 0;
                        x = edge[d[x][j]].y;
                        break;                        
                    }
                }
                printf("%d", ans.size());
                forn(j, ans.size()) {
                    printf(" %d", ans[j]);
                }
                printf("\n");
            }
        }
    } else {
        printf("-1");
    }
}

int main()
{
    freopen(cinfile, "rt", stdin);
    freopen(coutfile, "wt", stdout);

    init();
    solve();
    writeanswer();    

    return 0;
}
