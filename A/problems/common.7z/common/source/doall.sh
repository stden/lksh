#!/bin/sh

echo "unzip tests..."
unrar -y x tests.rar || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

