#include <testlib.h>

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

typedef unsigned long long ull;

const ull P = 239017;

void substrings( string s, vector <ull> &r ) {
  for (int i = 0; i < (int)s.length(); i++) {
    ull res = 0;
    for (int j = i; j < (int)s.length(); j++) {
      res = res * P + s[j];
      r.push_back(res);
    }
  }
  sort(r.begin(), r.end());
}

int main() {
  registerValidation();
  string s1 = inf.readToken("[01]{1,4000}");
  inf.readEoln();
  string s2 = inf.readToken("[01]{1,4000}");
  inf.readEoln();
  vector <ull> r1, r2;
  substrings(s1, r1);
  substrings(s2, r2);
  int count = 0, i = 0, j = 0;
  while (i < (int)r1.size() && j < (int)r2.size()) {
    while (i < (int)r1.size() && r1[i] < r2[j])
      i++;
    while (j < (int)r2.size() && r2[j] < r1[i])
      j++;
    if (r1[i] == r2[j]) {
      count++;
      ull temp = r1[i];
      while (i < (int)r1.size() && r1[i] == temp)
        i++;
      while (j < (int)r2.size() && r2[j] == temp)
        j++;
    }
  }
  int k = inf.readInt(1, count);
  inf.readEoln();
  inf.readEof();
  return 0;
}

