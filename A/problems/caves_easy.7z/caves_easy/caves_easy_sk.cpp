//#pragma comment(linker, "/STACK:30000000")

#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>

using namespace std;

typedef vector <int> vi;

#define pb push_back
#define forn(i, n) for (int i = 0; i < (int)(n); i++)

#define m (1 << 18)

vi c[m];
int n, k, y, z, pa[m], si[m], dep[m], be[m], up[m], l[m], pos[m], tr[m + m];
int trl[m + m], fi[m], rev[m], id[m];

void dfs( int v, int p )
{
  pa[v] = p, dep[v] = (p == -1) ? 0 : (dep[p] + 1);
  si[v] = 1, be[v] = -1;
  id[v] = z++, trl[m + y++] = id[v], rev[id[v]] = v, fi[v] = y - 1;
  forn (i, c[v].size())
    if (c[v][i] != p)
      dfs(c[v][i], v), trl[m + y++] = id[v];
  if (si[be[p]] < si[v])
    be[p] = v;
  si[p] += si[v];
}

void build( int v, int p )
{
  l[k] = v, pos[v] = k++;
  up[v] = v;
  if (p != -1 && be[p] == v)
    up[v] = up[p];
  if (c[v].size())
    build(be[v], v);
  forn (i, c[v].size())
    if (c[v][i] != p && c[v][i] != be[v])
      build(c[v][i], v);
}

int sum( int a, int b ) { return max(a, b); }
int min( int a, int b ) { return a < b ? a : b; }

void set( int v, int a )
{
  int i = pos[v] + m;
  tr[i] += a;
  while (i != 1)
    tr[i >> 1] = sum(tr[i], tr[i ^ 1]), i >>= 1;
}

int gett( int *tr, int l, int r, int (*f)(int, int) )
{
  l += m, r += m;
  if (l > r) swap(l, r);
  if (l == r) return tr[l];
  int res = f(tr[l], tr[r]);
  while (l / 2 != r / 2)
  {
    if (!(l & 1)) res = f(res, tr[l + 1]);
    if (r & 1) res = f(res, tr[r - 1]);
    l /= 2, r /= 2;
  }
  return res;
}

int lca( int u, int v )
{
  return rev[gett(trl, fi[u], fi[v], min)];
}

int getp( int u, int p )
{
  int res = 0;
  while (up[u] != up[p])
    res = sum(res, gett(tr, pos[u], pos[up[u]], sum)), u = pa[up[u]];
  return sum(res, gett(tr, pos[u], pos[p], sum));
}

int get( int u, int v )
{
  int p = lca(u, v);
  return max(getp(u, p), getp(v, p))/* - tr[pos[p] + m]*/;
}

int main()
{
  freopen("caves.in", "r", stdin);
  freopen("caves.out", "w", stdout);
  scanf("%d", &n);
  int a, b;
  for (int i = 1; i < n; i++)
    scanf("%d%d", &a, &b), a--, b--, c[a].pb(b), c[b].pb(a);
  z = y = 0;
  dfs(0, -1);
  k = 0;
  build(0, -1);
  for (int i = m - 1; i >= 1; i--)
    trl[i] = min(trl[i + i], trl[i + i + 1]);
  memset(tr, 0, sizeof(tr));
  scanf("%*d");
  char t;
  while (scanf(" %c%d%d", &t, &a, &b) == 3 && t != 'e')
    if (t == 'G')
      printf("%d\n", get(a - 1, b - 1));
    else
      set(a - 1, b);
  return 0;
}
