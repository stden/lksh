#include <algorithm>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <cstring>

//#pragma comment(linker, "/STACK:10000000")

using namespace std;

#define maxn 132079

int mem[maxn * 4], mn = 0;

class Tree
{
public:
  int * tree;
  //vector <int> tree;
  int xn, an, st, id;
  void create( int n )
  {
    int t = 1;
    while (t < n)
      t <<= 1;
    st = t - 1;  
    t <<= 1;  
    t--;
    
    tree = mem + mn;
    //tree = vector <int> (t, 0);
    mn += t;
  }

  void add( int v, int a )
  {
    v += st;
    tree[v] += a;
    while (v)
    {
      v = (v - 1) >> 1;
      tree[v] = max(tree[v * 2 + 1], tree[v * 2 + 2]);
    }
  }
  
  int get( int l, int r )
  {
    l += st, r += st;
    int res = tree[l];
    res = max(res, tree[r]);
    while (l + 1 < r)
    {
      if (l & 1)
        res = max(res, tree[l + 1]); 
      if (!(r & 1))
        res = max(res, tree[r - 1]);
      r = (r - 1) >> 1;
      l = (l - 1) >> 1;
    }
    return res;
  }
};


vector <int> ne[maxn];
vector <int> q[maxn], qNum[maxn];

vector <Tree> trees;

char tp[maxn];
int q1[maxn], q2[maxn], q3[maxn], was[maxn], cnt[maxn], lca[maxn], prev[maxn], key[maxn],
    treeSize[maxn], tn, inTNum[maxn], tNum[maxn], first[maxn], par[maxn];

int get( int v )
{
  if (prev[v] == v)
    return v;
  return prev[v] = get(prev[v]);
}

int getKey( int v )
{
  return key[get(v)];
}

void uni( int a, int b, int newKey )
{
  a = get(a);
  b = get(b);
  if (rand() & 1)
    prev[a] = b, key[b] = newKey;
  else
    prev[b] = a, key[a] = newKey;
}

int dfs( int v ) 
{
  cnt[v] = 1;
  was[v] = 1;
  for (int i = 0; i < ne[v].size(); i++)
    if (!was[ne[v][i]])
    {
      cnt[v] += dfs(ne[v][i]);
      par[ne[v][i]] = v;
      uni(ne[v][i], v, v);
    }
  was[v] = 2;  
  for (int i = 0; i < q[v].size(); i++)
    if (was[q[v][i]] == 2)
    {
      lca[qNum[v][i]] = getKey(q[v][i]);
    }  
  return cnt[v];    
}

void buildTrees( int v, int currNum, int currI )
{
  inTNum[v] = currI;
  tNum[v] = currNum;
  treeSize[currNum]++;
  int to = -1;
  
  was[v] = 1;
  for (int i = 0; i < ne[v].size(); i++)
    if (!was[ne[v][i]] && (to == -1 || cnt[to] < cnt[ne[v][i]]))
      to = ne[v][i];
  if (to == -1)   
    return;
  buildTrees(to, currNum, currI + 1);  
  for (int i = 0; i < ne[v].size(); i++)
    if (!was[ne[v][i]] && ne[v][i] != to)
    {
      first[++tn] = ne[v][i];
      buildTrees(ne[v][i], tn, 0);
    }  
    
}

void I( int a, int v )
{
  trees[tNum[a]].add(inTNum[a], v);
}

int G( int a, int b )
{
  int tmp = 0;
  int res = -1;
  while (true)
  {
    tmp++;
    if (tmp > 100)
    {
      int a = 10;
      a /= 0;
      *((char *)(0)) = 666;
    }
    int p = a;
    
    if (tNum[b] == tNum[a])
      a = b;
    else
      a = first[tNum[a]];
    res = max(res, trees[tNum[a]].get(inTNum[a], inTNum[p]));
    
    if (a == b)
      break;
    a = par[a];  
  }
  return res;
}

int main( void )
{
  freopen("caves.in", "r", stdin);
  freopen("caves.out", "w", stdout);
  memset(mem, 0, sizeof(mem));
  
  int n;
  scanf("%d", &n);
  
  prev[0] = key[0] = 0;
  
  for (int i = 1; i < n; i++)
  {
    prev[i] = key[i] = i;
    int a, b;
    scanf("%d%d", &a, &b);
    a--, b--;
    ne[a].push_back(b);
    ne[b].push_back(a);
  }
  
  int m;
  scanf("%d", &m);
  for (int i = 0; i < m; i++)
  {
    char c;
    int a, b;
    while ((c = getc(stdin)) != 'G' && c != 'I');
    scanf("%d%d", &a, &b);
    
    tp[i] = c;

    if (c == 'G')
    {
      a--, b--;
      q1[i] = a, q2[i] = b;
      q[a].push_back(b);
      qNum[a].push_back(i);
      q[b].push_back(a);
      qNum[b].push_back(i);
    }
    else
    {
      a--;
      q1[i] = a;
      q3[i] = b;
      b = a;
    }
  }
  
  memset(was, 0, sizeof(was));
  dfs(0);
  
  memset(was, 0, sizeof(was));
  memset(treeSize, 0, sizeof(treeSize));
  buildTrees(0, 0, 0);
  
  trees.resize(++tn);
  for (int i = 0; i < tn; i++)
    trees[i].create(treeSize[i]);
    
  for (int i = 0; i < m; i++)
  {
    if (tp[i] == 'I')
    {
      I(q1[i], q3[i]);
    }  
    else
    {
      printf("%d\n", max(G(q1[i], lca[i]),G(q2[i], lca[i])));
    }
  }
 
  return 0;
}
