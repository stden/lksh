#include <testlib.h>

using namespace std;

const int maxn = 100;
const int maxq = 100;
const int maxv = 10000;

vector <int> g[maxn];
int u[maxn];

void dfs( int v )
{
  u[v] = 1;
  for (int i = 0; i < (int)g[v].size(); i++)
    if (!u[g[v][i]])
      dfs(g[v][i]);
}

int main()
{
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readEoln();
  for (int i = 1; i < n; i++) {
    int a = inf.readInt(1, n);
    inf.readSpace();
    int b = inf.readInt(1, n);
    inf.readEoln();
    g[a - 1].push_back(b - 1);
    g[b - 1].push_back(a - 1);
  }
  memset(u, 0, sizeof(u));
  dfs(0);
  for (int i = 0; i < n; i++)
    ensuref(u[i], "в вершину %d не попасть", i + 1);
  int q = inf.readInt(1, maxq);
  inf.readEoln();
  for (int i = 0; i < q; i++)  {
    char ch = inf.readChar();
    ensuref(ch == 'I' || ch == 'G', "запрос «%c» не поддерживается", ch);
    inf.readSpace();
    if (ch == 'I') {
      inf.readInt(1, n);
      inf.readSpace();
      inf.readInt(0, maxv);
    } else {
      inf.readInt(1, n);
      inf.readSpace();
      inf.readInt(1, n);
    }
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

