#!/bin/sh

unrar -y x tests.rar || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

