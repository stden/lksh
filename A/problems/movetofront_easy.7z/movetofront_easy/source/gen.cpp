#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include "random.h"

using std::swap;

int main( int argc, char *argv[] )
{
  srand(atoi(argv[1]));
  int n = rand() % 100 + 1;
  int m = rand() % 100 + 1;
  printf("%d %d\n", n, m);
  for (int i = 0; i < m; i++)
  {
    int l = rand() % n + 1;
    int r = rand() % n + 1;
    if (l > r)
      swap(l, r);
    printf("%d %d\n", l, r);
  }
  return 0;
}

