#!/bin/sh

echo "compile..."
echo "stupid suffix “.exe” added for compatibility with outdated operation systems"
g++ -O2 -Wall -o gen.exe gen.cpp || exit 1

echo -n "generate tests"
echo -n "."
cp 01.hand 01 || exit 1
rand=301703
for i in `seq -w 02 30`; do
  echo -n "."
  ./gen.exe $rand > $i || exit 1
  rand=$(($rand + 7))
done
echo ""

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

