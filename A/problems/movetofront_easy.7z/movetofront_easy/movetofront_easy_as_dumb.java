import java.io.*;
import java.util.StringTokenizer;
import java.util.Random;
import java.util.ArrayList;

public class movetofront_as_dumb {
    BufferedReader in;
    StringTokenizer st;
    PrintWriter out;

    int nextInt() throws IOException {
        while (st == null || !st.hasMoreTokens()) {
            st = new StringTokenizer(in.readLine());
        }
        return Integer.parseInt(st.nextToken());
    }

    public void run() throws IOException {
        in = new BufferedReader(new FileReader("movetofront.in"));
        out = new PrintWriter(new File("movetofront.out"));

        int n = nextInt();
        int m = nextInt();

        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = i + 1;
        }

        int[] b = new int[n];
        for (int i = 0; i < m; i++) {
            int l = nextInt() - 1;
            int r = nextInt() - 1;

            System.arraycopy(a, 0, b, 0, n);
            for (int j = l; j <= r; j++) {
                a[j - l] = b[j];
            }
            for (int j = 0; j < l; j++) {
                a[j + r - l + 1] = b[j];
            }
            for (int j = r + 1; j < n; j++) {
                a[j] = b[j];
            }
        }

        for (int i = 0; i < n; i++) {
            out.print(a[i] + " ");
        }
        out.println();

        in.close();
        out.close();
    }

    public static void main(String[] arg) throws IOException {
        new movetofront_as_dumb().run();
    }
}
