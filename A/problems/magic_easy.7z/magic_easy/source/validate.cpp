#include <testlib.h>

using namespace std;

#define pb push_back

const int maxn = 100;
const int maxm = 500;
const int maxk = 1000;

vector <int> g[maxn + 1];
int u[maxn + 1];

void dfs( int v ) {
  u[v] = 1;
  for (int i = 0; i < (int)g[v].size(); i++)
    if (!u[g[v][i]])
      dfs(g[v][i]);
}

int main( int argc, char *argv[] )
{
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxm);
  inf.readEoln();
  int f = inf.readInt(1, n);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    int a = inf.readInt(1, n);
    inf.readSpace();
    int b = inf.readInt(1, n);
    inf.readEoln();
    ensuref(a != b, "bad [3]");
    g[a].pb(b), g[b].pb(a);
  }
  memset(u, 0, sizeof(u));
  dfs(1);
  for (int i = 1; i <= n; i++) {
    ensuref(u[i], "bad [4]");
    sort(g[i].begin(), g[i].end());
    for (int j = 1; j < (int)g[i].size(); j++)
      ensuref(g[i][j] != g[i][j - 1], "bad [5]\n");
  }
  int k = inf.readInt(1, maxk);
  inf.readEoln();
  for (int i = 0; i < k; i++) {
    inf.readInt(1, n);
    inf.readSpace();
    inf.readInt(1, n);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

