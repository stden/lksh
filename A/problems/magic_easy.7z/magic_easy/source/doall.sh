#!/bin/sh

echo "compile..."
fpc gen.pas || exit 1
fpc gentree.pas || exit 1
g++ -O2 -Wall remake.cpp -o remake

echo -n "generate tests..."
for i in `seq -w 01 01`; do
  cp $i.hand $i
done

./gentree 20 1 10 0 10 > "tmp.in" || exit 1
./gen 30 3.2 > 02 || exit 1

./gentree 50 2 2 0 4 1 30 > "tmp.in" || exit 1
./gen 100 2.3 > 03 || exit 1

for i in `seq -w 04 25`; do
  ./gentree 100 3 20 0 40 14 10 16 100 > "tmp.in" || exit 1
  ./gen 100 0.6 > $i || exit 1
done

rm --force "tmp.in"
for i in ??; do
  ./remake < $i > temp.temp || exit 1
  mv temp.temp $i || exit 1
done
echo ""

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

