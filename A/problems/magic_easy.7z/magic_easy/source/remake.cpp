#include <cstdio>

int main( void )
{
  int n, m, st, a, b;
  scanf("%d%d%d", &n, &m, &st);
  printf("%d %d\n%d\n", n, m, st);
  while (m--)
  {
    scanf("%d%d", &a, &b);
    if (!a) a = 1;
    if (!b) b = 1;
    printf("%d %d\n", a, b);
  }
  scanf("%d", &m);
  printf("%d\n", m);
  while (m--)
  {
    scanf("%d%d", &a, &b);
    if (!a) a = 1;
    if (!b) b = 1;
    printf("%d %d\n", a, b);
  }
  return 0;
}
