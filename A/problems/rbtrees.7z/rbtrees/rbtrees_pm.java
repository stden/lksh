
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.math.BigInteger;

public class rbtrees_pm {


    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("rbtrees.in"));
        int n = scanner.nextInt();
        Node[] a = new Node[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = new Node(i);
        }
        boolean[] isRoot = new boolean[n];
        Arrays.fill(isRoot, true);
        for (Node node : a) {
            int i = scanner.nextInt();
            int j = scanner.nextInt();
            if (i > 0) {
                node.left = a[i - 1];
                isRoot[i - 1] = false;
            }
            if (j > 0) {
                node.right = a[j - 1];
                isRoot[j - 1] = false;
            }
        }
        int root = 0;
        while (!isRoot[root]) root++;
        a[root].calc();
        BigInteger s = BigInteger.ZERO;
        for (BigInteger aa : a[root].b) {
            s = s.add(aa);
        }
        for (BigInteger aa : a[root].r) {
            s = s.add(aa);
        }

        PrintWriter writer = new PrintWriter(new File("rbtrees.out"));
        writer.println(s);
        writer.close();
    }

    static class Node {
        Node left;
        Node right;

        int ind;

        public Node(int ind) {
            this.ind = ind;
        }

        List<BigInteger> r;
        List<BigInteger> b;

        public void calc() {
            r = new ArrayList<BigInteger>();
            b = new ArrayList<BigInteger>();
            if (right == null && left == null) {
                r.add(BigInteger.ONE);
                b.add(BigInteger.ONE);
            } else if (right == null ^ left == null) {
                if (right != null) {
                    right.calc();
                    r.add(BigInteger.ZERO);
                    b.add(right.r.get(0));
                } else {
                    left.calc();
                    r.add(BigInteger.ZERO);
                    b.add(left.r.get(0));
                }
            } else {
                left.calc();
                right.calc();
                r.add(BigInteger.ZERO);
                int k = Math.min(right.b.size(), left.b.size()) + 1;
                for (int i = 0; i < k; i++) {
                    if (i == k - 1) {
                        BigInteger s = right.b.get(i - 1).multiply(left.b.get(i - 1));
                        if (right.r.size() > i) {
                            s = s.add(right.r.get(i).multiply(left.b.get(i - 1)));
                        }
                        if (left.r.size() > i) {
                            s = s.add(left.r.get(i).multiply(right.b.get(i - 1)));
                        }
                        b.add(s);
                    } else {
                        r.add(right.b.get(i).multiply(left.b.get(i)));
                        if (i > 0) {
                            b.add(right.b.get(i - 1).multiply(left.b.get(i - 1)).add(
                                    right.r.get(i).multiply(left.b.get(i - 1))).add(
                                    right.b.get(i - 1).multiply(left.r.get(i))).add(
                                    right.r.get(i).multiply(left.r.get(i)))
                            );
                        } else {
                            b.add(right.r.get(i).multiply(left.r.get(i)));
                        }
                    }
                }
            }
        }
    }

}
