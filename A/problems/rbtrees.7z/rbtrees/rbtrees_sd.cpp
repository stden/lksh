/** Problem: rbtrees
  * Solution by: Semyon Dyatlov
  **/
#include <assert.h>
#include <stdio.h>

#define MAXN 1001
#define BASE 1000
#define MAXL 150
#define MAXQ 50

struct Big
{
  int size;
  int data[MAXL];

  void zero()
  {
    size = 1;
    data[0] = 0;
  }

  Big()
  {
    zero();
  }

  void output()
  {
    printf("%d",data[size-1]);
    for (int i=size-2;i>=0;i--)
      printf("%03d",data[i]);
    printf("\n");
  }

  void operator +=(Big &a)
  {
    int c = 0;
    for (int i=0;(i<a.size)||c;i++)
    {
      if (i>=size)
        data[size++] = 0;
      if (i>=a.size)
        a.data[i] = 0;
      c += data[i]+a.data[i];
      data[i] = c%BASE;
      c /= BASE;
    }    
    assert(size<MAXL);
  }

  void mul(const Big &a, const Big &b)
  {
    if ((a.size==1&&!a.data[0])||(b.size==1&&!b.data[0]))
    {
      zero();
      return;
    }
    size = a.size+b.size-1;
    int c = 0;
    for (int i=0;i<size;i++)
    {
      for (int j=0;(j<=i)&&(j<a.size);j++)
        c += a.data[j]*b.data[i-j];
      data[i] = c%BASE;
      c /= BASE;
    }
    while (c)
    {
      data[size++] = c%BASE;
      c /= BASE;
    }
    assert(size<MAXL);
  }
};

int max(int a, int b)
{
  return (a>b) ? a : b;
}

int min(int a, int b)
{
  return (a<b) ? a : b;
}

int n, ls[MAXN], rs[MAXN], lb[MAXN][2], rb[MAXN][2], root;
bool b[MAXN], nr[MAXN];
Big z[MAXN][2][MAXQ];

void go(int a)
{
  if (b[a])
    return;
  b[a] = true;
  go(ls[a]);
  go(rs[a]);
  lb[a][1] = max(lb[ls[a]][0],lb[rs[a]][0]);
  rb[a][1] = min(rb[ls[a]][0],rb[rs[a]][0]);
  assert(rb[a][1]<=MAXQ);
  for (int i=lb[a][1];i<rb[a][1];i++)
    z[a][1][i].mul(z[ls[a]][0][i],z[rs[a]][0][i]);
  lb[a][0] = 1+max(min(lb[ls[a]][0],lb[ls[a]][1]),min(lb[rs[a]][0],lb[rs[a]][1]));
  rb[a][0] = 1+min(max(rb[ls[a]][0],rb[ls[a]][1]),max(rb[rs[a]][0],rb[rs[a]][1]));
  assert(rb[a][0]<=MAXQ);
  for (int i=lb[a][0];i<rb[a][0];i++)
  {
    z[ls[a]][0][i-1] += z[ls[a]][1][i-1];
    z[rs[a]][0][i-1] += z[rs[a]][1][i-1];
    z[a][0][i].mul(z[ls[a]][0][i-1],z[rs[a]][0][i-1]);
  }
}

int main()
{
  freopen("rbtrees.in","rt",stdin);
  freopen("rbtrees.out","wt",stdout);

  scanf("%d",&n);
  for (int i=1;i<=n;i++)
  {
    scanf("%d%d",&ls[i],&rs[i]);
    nr[ls[i]] = true;
    nr[rs[i]] = true;
  }
  for (root=1;root<=n;root++)
    if (!nr[root])
      break;

  b[0] = true;
  lb[0][0] = 0;
  rb[0][0] = 1;
  lb[0][1] = 0;
  rb[0][1] = 0;
  for (int i=0;i<=n;i++)
    for (int j=0;j<2;j++)
      for (int k=0;k<MAXQ;k++)
        z[i][j][k].zero();
  z[0][0][0].data[0] = 1;
  for (int i=1;i<=n;i++)
    go(i);
  Big s;
  s.zero();
  for (int j=0;j<2;j++)
    for (int i=lb[root][j];i<rb[root][j];i++)
      s += z[root][j][i];
  s.output();

  return 0;
}
