import java.io.PrintWriter;
import java.util.Random;

public class gen_rbtree {
    static int[] left;
    static int[] right;
    static int n;

    static Random random;

    static void setLink(int parent, int by, int dest) {
        if (parent < 0)
            return;
        if (by == 0)
            left[parent] = dest;
        else
            right[parent] = dest;
    }

    static void makeTree(int parent, int by, int color, int blackDepth) {
        if (blackDepth == 0)
            if (random.nextInt(2) == 0)
                return;

        if (color == 0) {
            if (blackDepth == 0)
                return;

            int id = n++;
            setLink(parent, by, id);
            makeTree(id, 0, random.nextInt(2), blackDepth - 1);
            makeTree(id, 1, random.nextInt(2), blackDepth - 1);
        } else {
            int id = n++;
            setLink(parent, by, id);
            makeTree(id, 0, 0, blackDepth);
            makeTree(id, 1, 0, blackDepth);
        }
    }

    public static void main(String[] args) {
        PrintWriter writer = new PrintWriter(System.out);

        int m = Integer.parseInt(args[0]);

        random = new Random(m * 913731 + Integer.parseInt(args[1]));

        left = new int[10000];
        right = new int[10000];
        n = 0;
        for (int i = 0; i < 10000; ++i) {
            left[i] = -1;
            right[i] = -1;
        }

        makeTree(-1, -1, random.nextInt(2), m);

        writer.println(n);

        for (int i = 0; i < n; ++i)
            writer.println((left[i] + 1) + " " + (right[i] + 1));

        writer.close();
    }
}
