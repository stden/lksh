import java.io.PrintWriter;
import java.util.Random;

public class gen_random {
    public static void main(String[] args) {
        PrintWriter writer = new PrintWriter(System.out);

        int n = Integer.parseInt(args[0]);

        Random random = new Random(n * 3137);

        if (n % 2 == 0)
            --n;

        writer.println(n);

        int[] left = new int[n];
        int[] right = new int[n];

        for (int step = 0; step < (n - 1) / 2; ++step) {
            int cur;
            do {
                cur = random.nextInt(1 + 2 * step);
            } while (left[cur] > 0);

            left[cur] = 1 + 2 * step + 1;
            right[cur] = 2 + 2 * step + 1;
        }

        for (int i = 0; i < n; ++i)
            writer.println(left[i] + " " + right[i]);

        writer.close();
    }
}
