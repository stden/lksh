#include <testlib.h>

const int maxn = 1000;

int l[maxn], r[maxn], p[maxn], c[maxn];

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readEoln();
  memset(p, -1, sizeof(p));
  for (int i = 0; i < n; i++) {
    l[i] = inf.readInt(0, n) - 1;
    if (l[i] != -1)
      p[l[i]] = i;
    inf.readSpace();
    r[i] = inf.readInt(0, n) - 1;
    if (r[i] != -1)
      p[r[i]] = i;
    inf.readEoln();
  }
  inf.readEof();
  memset(c, 0, sizeof(c));
  for (int i = 0; i < n; i++) {
    for (int j = i; j != -1 && c[j] != 2; j = p[j]) {
      ensuref(c[j] != 1, "не дерево");
      c[j] = 1;
    }
    for (int j = i; j != -1 && c[j] != 2; j = p[j])
      c[j] = 2;
  }
  return 0;
}

