import java.io.PrintWriter;

public class gen_heap {
    public static void main(String[] args) {
        PrintWriter writer = new PrintWriter(System.out);

        int n = Integer.parseInt(args[0]);

        writer.println(n);

        for (int i = 1; i <= n; ++i)
            writer.println((2 * i <= n ? 2 * i : 0) + " " +(2 * i + 1 <= n ? 2 * i + 1 : 0));

        writer.close();
    }
}
