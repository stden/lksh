import java.util.Scanner;
import java.util.Random;
import java.io.PrintWriter;
import java.util.ArrayList;

public class add_trash {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PrintWriter writer = new PrintWriter(System.out);

        int n = scanner.nextInt();
        int m = Integer.parseInt(args[0]);

        Random random = new Random(n * 9321 + m * 37313);

        int[] left = new int[n + m];
        int[] right = new int[n + m];

        ArrayList<Integer> leaves = new ArrayList<Integer>();

        for (int i = 0; i < n; ++i) {
            left[i] = scanner.nextInt() - 1;
            right[i] = scanner.nextInt() - 1;

            if (left[i] == -1 && right[i] == -1)
                leaves.add(i);
        }

        for (int i = n; i < n + m; ++i) {
            left[i] = -1;
            right[i] = -1;
        }

        assert(m <= leaves.size());

        for (int step = 0; step < m; ++step) {
            int id = random.nextInt(leaves.size());
            int a = leaves.get(id);
            leaves.remove(id);
            if (random.nextInt(2) == 0)
                left[a] = n++;
            else
                right[a] = n++;
        }

        writer.println(n);

        for (int i = 0; i < n; ++i)
            writer.println((left[i] + 1) + " " + (right[i] + 1));

        writer.close();
    }
}
