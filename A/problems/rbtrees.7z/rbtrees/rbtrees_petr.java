import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.File;
import java.math.BigInteger;

public class rbtrees_petr {
    static Vertex Sentinel = new Vertex(true);

    static class Vertex {
        public Vertex leftChild;
        public Vertex rightChild;
        public boolean isSentinel;
        public boolean isChild;
        public BigInteger[] answerBlack;
        public BigInteger[] answerRed;

        public Vertex(boolean isSentinel) {
            isChild = false;
            this.isSentinel = isSentinel;

            if (isSentinel) {
                leftChild = null;
                rightChild = null;

                answerBlack = new BigInteger[1];
                answerBlack[0] = BigInteger.ONE;
                answerRed = new BigInteger[0];
            }
            else
            {
                leftChild = Sentinel;
                rightChild = Sentinel;

                answerBlack = null;
                answerRed = null;
            }
        }

        void FillAnswer() {
            if (isSentinel)
                return;

            leftChild.FillAnswer();
            rightChild.FillAnswer();

            answerRed = new BigInteger[Math.min(leftChild.answerBlack.length, rightChild.answerBlack.length)];
            for (int i = 0; i < answerRed.length; ++i)
                answerRed[i] = leftChild.answerBlack[i].multiply(rightChild.answerBlack[i]);

            answerBlack = new BigInteger[1 + Math.min(Math.max(leftChild.answerBlack.length, leftChild.answerRed.length),
                    Math.max(rightChild.answerBlack.length, rightChild.answerRed.length))];

            answerBlack[0] = BigInteger.ZERO;

            for (int i = 0; i < answerBlack.length - 1; ++i) {
                BigInteger leftWays = BigInteger.ZERO;
                if (i < leftChild.answerBlack.length)
                    leftWays = leftWays.add(leftChild.answerBlack[i]);
                if (i < leftChild.answerRed.length)
                    leftWays = leftWays.add(leftChild.answerRed[i]);

                BigInteger rightWays = BigInteger.ZERO;
                if (i < rightChild.answerBlack.length)
                    rightWays = rightWays.add(rightChild.answerBlack[i]);
                if (i < rightChild.answerRed.length)
                    rightWays = rightWays.add(rightChild.answerRed[i]);

                answerBlack[i + 1] = leftWays.multiply(rightWays);
            }
        }

        BigInteger GetTotalAnswer() {
            BigInteger res = BigInteger.ZERO;

            for (int i = 0; i < answerBlack.length; ++i)
                res = res.add(answerBlack[i]);

            for (int i = 0; i < answerRed.length; ++i)
                res = res.add(answerRed[i]);

            return res;
        }
    }

    public void solve() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("rbtrees.in"));
        PrintWriter writer = new PrintWriter(new FileOutputStream("rbtrees.out"));

        int numVertices = scanner.nextInt();

        assert(numVertices >= 1 && numVertices <= 1000);

        Vertex[] vertices = new Vertex[numVertices];

        for (int i = 0; i < numVertices; ++i)
            vertices[i] = new Vertex(false);

        for (Vertex vertex : vertices) {
            int leftChildId = scanner.nextInt() - 1;
            assert(leftChildId >= -1 && leftChildId < numVertices);
            if (leftChildId >= 0) {
                vertex.leftChild = vertices[leftChildId];
                assert(!vertex.leftChild.isChild);
                vertex.leftChild.isChild = true;
            }
            int rightChildId = scanner.nextInt() - 1;
            assert(rightChildId >= -1 && rightChildId < numVertices);
            if (rightChildId >= 0) {
                vertex.rightChild = vertices[rightChildId];
                assert(!vertex.rightChild.isChild);
                vertex.rightChild.isChild = true;
            }
        }

        Vertex root = null;

        for (Vertex vertex : vertices)
            if (!vertex.isChild) {
                assert(root == null);
                root = vertex;
            }

        assert(root != null);

        root.FillAnswer();

        writer.println(root.GetTotalAnswer());

        writer.close();
    }

    public static void main(String[] args) throws FileNotFoundException {
        new rbtrees_petr().solve();
    }

}
