#include <algorithm>
#include <cstdio>
#include <iostream>
#include <cstring>

using namespace std;


#define maxn 100010

char s[maxn];


long long h[maxn], rh[maxn], p[maxn], x = 103;
int n;

bool isP( int l, int r )
{
  long long a = h[r];
  if (l)
    a -= h[l - 1] * p[r - l + 1];

//  fprintf(stderr, "%d %d | ", l, r);
  l = n - l - 1;
  r = n - r - 1;
  swap(l, r);
 // fprintf(stderr, "%d %d\n", l, r);;
 
  long long b = rh[r];
  if (l)
    b -= rh[l - 1] * p[r - l + 1];

 // cerr << a << " " << b << endl;
  return a == b;
}

int get( int l, int r )
{
  if (s[l] != s[r])
    return 0;

  int a = 0, b = min(l, n - 1 - r) + 1;

//  fprintf(stderr, "%d %d %d %d\n", l, r, a, b);

  while (a + 1 < b)
  {
    int c = (a + b) / 2;
    if (isP(l - c, r + c))
      a = c;
    else
      b = c;
  }
  //fprintf(stderr, "%d %d | %d\n", l, r, a);
  return a + (l != r);
}

int main( void )
{
  freopen("palindr.in", "r", stdin);
  freopen("palindr.out", "w", stdout);

  gets(s);
  n = strlen(s);

  long long res = 0;


  p[0] = 1;
  for (int i = 1; i <= n; i++)
    p[i] = p[i - 1] * x;

  h[0] = s[0];
  for (int i = 1; i < n; i++)
    h[i] = h[i - 1] * x + s[i];

  rh[0] = s[n - 1];
  for (int i = 1; i < n; i++)
    rh[i] = rh[i - 1] * x + s[n - i - 1];

  //cerr << isP(0, 1) << endl;
  //return 0;

  for (int i = 0; i < n; i++)
  {
    res += get(i, i);
    if (i + 1 < n)
      res += get(i, i + 1);
  }

  cout << res << endl;

  return 0;
}