#include <testlib.h>

int main() {
  registerValidation();
  inf.readToken("[a-z]{1,100000}");
  inf.readEoln();
  inf.readEof();
  return 0;
}

