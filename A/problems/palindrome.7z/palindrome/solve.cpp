#define _CRT_SECURE_NO_DEPRECATE

#include <algorithm>
#include <cstdio>
#include <cstring>

using namespace std;

int n;
char s[200001];
int f[2][3][200001];

int main()
{
	gets(s);
	n = strlen(s);
	s[n] = '$';
	for (int i = n + 1; i <= 2 * n; i++)
		s[i] = s[2 * n - i];
	n = 2 * n + 1;
	int *a1 = f[0][0], *b1 = f[0][1], *c1 = f[0][2];
	int *a2 = f[1][0], *b2 = f[1][1], *c2 = f[1][2];
	int h = 1;
	while (h < n)
	{
		h <<= 1;
		swap(a1, a2);
		swap(b1, b2);
		swap(c1, c2);
	}
	return 0;
}
