#!/bin/sh

echo "compile..."
g++ -O2 -Wall -o gen.exe gen.cpp || exit 1

echo -n "generate tests..."
cp 01.hand 01
./gen.exe 1000001 10 10 > 02
./gen.exe 1000001 10 100 > 03
./gen.exe 1000001 30 30 > 04
./gen.exe 1000001 30 100 > 05
./gen.exe 1000001 100 30 > 06
./gen.exe 1000001 100 100 > 07
./gen.exe 1000001 100 1000 > 08
./gen.exe 1000001 100 1000000000 > 09
./gen.exe 1000001 100 1000000000 > 10
echo ""

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

