#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

long long Time()
{
  asm("rdtsc");
}

int R( int A, int B )
{
  return A + (unsigned)((rand() << 15) + rand()) % (unsigned)(B - A + 1);
}

int main( int argc, char *argv[] )
{
  int seed = atoi(argv[1]), n = atoi(argv[2]), c = atoi(argv[3]);

  // seed - base for random (0 means Time())
  // n - number of queries
  // c - range of all numbers in input will be [0..c]

  srand(seed ? seed : Time());
  printf("%d\n", n);
  while (n--)
    if (rand() % 10 < 3)
    {
      int l = R(0, c), r = R(0, c);
      printf("? %d %d\n", min(l, r), max(l, r));
    }
    else
      printf("+ %d\n", R(0, c));
  return 0;
}

