#include <cassert>
#include <cstdio>
#include <cstdlib>

#include <vector>
#include <iostream>

using namespace std;

#define pb push_back

#define MOD (int)1e9

vector <int> v;

void add( int x )
{
  for (int i = 0; i < (int)v.size(); i++)
    if (x == v[i])
      return;
  v.pb(x);
}

int main()
{
  int n;
  long long y = -1;

  freopen("sum.in", "r", stdin);
  freopen("sum.out", "w", stdout);

  cin >> n;
  assert(1 <= n && n <= 100);

  while (n--)
  {
    char ch;
    scanf(" %c", &ch);
    if (ch == '+')
    {
      int a;
      cin >> a;
      if (y == -1)
        add(a);
      else
        add((a + y) % MOD);
      y = -1;
    }
    else
    {
      int l, r;
      y = 0;
      cin >> l >> r;
      for (int i = 0; i < (int)v.size(); i++)
        if (l <= v[i] && v[i] <= r)
          y += v[i];
      cout << y << endl;
    }
  }
  return 0;
}
