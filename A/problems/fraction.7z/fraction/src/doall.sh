#!/bin/sh

## under windows
7z e -y tests.zip

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

