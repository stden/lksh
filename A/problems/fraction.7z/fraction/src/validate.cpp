#include <string>
#include <testlib.h>

using namespace std;

const int MAXN = 150000;
const int MAXK = 1000000000;
                        	
int main() 
{
	registerValidation();
	int n = inf.readInt(1, MAXN);
	inf.readSpace();
	int k = inf.readInt(0, MAXK);
	inf.readEoln();
	int i;
	for (i = 0; i < n; i++) 
	{
		char c = inf.readChar();
		ensuref('0' <= c && c <= '9', "Wrong character %c", c);
	}
	inf.readEoln();
	inf.readEof();
	return 0;
}

