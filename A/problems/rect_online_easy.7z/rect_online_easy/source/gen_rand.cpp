#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "random.h"

#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

FILE *F = NULL;

void NewTest()
{
  int static cnt = 0;
  char buf[99];

  do
  {
    if (F)
      fclose(F);
    cnt++;
    sprintf(buf, "%02d", cnt);
    F = fopen(buf, "rt");
  } while (F);

  sprintf(buf, "%02d", cnt);
  F = fopen(buf, "wt");
}

void GenRand( int n, int m, int c )
{
  fprintf(F, "%d\n", n);
  forn(i, n)
    fprintf(F, "%d %d\n", R(0, c), R(0, c));
  fprintf(F, "%d\n", m);
  forn(i, m)
  {
    int x1 = R(0, c), x2 = R(0, c);
    int y1 = R(0, c), y2 = R(0, c);
    fprintf(F, "%d %d %d %d\n", min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2));
  }
}

int main()
{
  initrand(239017);

  forn(i, 5)
    NewTest(), GenRand(10, 10, (i + 1) * 10);
  forn(i, 10)
    NewTest(), GenRand(100, 100, (i + 1) * 20);

  if (F)
    fclose(F);
  return 0;
}
