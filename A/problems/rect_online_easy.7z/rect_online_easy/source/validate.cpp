#include <testlib.h>

const int maxn = 100;
const int maxc = 1000000000;
const int maxm = 100;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readEoln();
  for (int i = 0; i < n; i++) {
    inf.readInt(-maxc, maxc);
    inf.readSpace();
    inf.readInt(-maxc, maxc);
    inf.readEoln();
  }
  int m = inf.readInt(1, maxm);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    int x1 = inf.readInt(-maxc, maxc);
    inf.readSpace();
    int y1 = inf.readInt(-maxc, maxc);
    inf.readSpace();
    inf.readInt(x1, maxc);
    inf.readSpace();
    inf.readInt(y1, maxc);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

