#!/bin/bash

g++ -O2 -Wall gen_rand.cpp -o gen_rand

for i in *.manual; do
  cp "$i" "${i/\.manual/}"
done

./gen_rand

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

