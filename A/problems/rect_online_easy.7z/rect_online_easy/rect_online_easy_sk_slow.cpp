#include <cstdio>
#include <cstdlib>
#include <cassert>

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

const int M = (int)1e9;
const int maxn = 100;

int n, m, x[maxn], y[maxn];

int main()
{
  freopen("rect_online.in", "r", stdin);
  freopen("rect_online.out", "w", stdout);

  scanf("%d", &n);
  assert(1 <= n && n <= 100);
  forn(i, n)
  {
    scanf("%d%d", &x[i], &y[i]);
    assert(0 <= x[i] && x[i] <= M);
    assert(0 <= y[i] && y[i] <= M);
  }

  scanf("%d", &m);
  assert(1 <= m && m <= 100);
  forn(i, m)
  {
    int x1, y1, x2, y2;
    scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
    assert(0 <= x1 && x1 <= x2 && x2 <= M);
    assert(0 <= y1 && y1 <= y2 && y2 <= M);

    int cnt = 0;
    forn(i, n)
      if (x1 <= x[i] && x[i] <= x2 && y1 <= y[i] && y[i] <= y2)
        cnt++, x[i] = y[i] = M + 1;

    printf("%d\n", cnt);
  }
  return 0;               
}
