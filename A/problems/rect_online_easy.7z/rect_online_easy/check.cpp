#define _CRT_SECURE_NO_DEPRECATE
#include "testlib.h"

using namespace std;

#define forn(i, n) for (int i = 0; i < (int)(n); ++i)

int main(int argc, char * argv[])
{
    registerTestlibCmd(argc, argv); 
    int n = inf.readInt();
    for (int i = 0; i < n; ++i) {
    	inf.readInt();
    	inf.readInt();
    }
    int m = inf.readInt();
    forn(i, m) {
    	int juryAns = ans.readInt();
    	int userAns = ouf.readInt();
    	if (juryAns != userAns) quitf(_wa, "Question No %d", i + 1);
    }
    quitf(_ok, "N = %d, M = %d", n, m);
}
