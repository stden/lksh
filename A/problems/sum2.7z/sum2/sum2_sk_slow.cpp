#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <set>

using namespace std;

#if (defined(WIN32) || !defined(__GNUC__))
#  define I64 "%I64d"
#else
#  define I64 "%Ld"
#endif

#define MOD (int)1e9

typedef long long ll;

int main()
{
  freopen("sum.in", "r", stdin);
  freopen("sum.out", "w", stdout);

  int n;
  set <int> s;

  long long sum = -1;
  s.insert(MOD + 1);
  scanf("%d", &n);
  while (n--)
  {
    char ch;
    scanf(" %c", &ch);
    if (ch == '+')
    {
      int a;
      scanf("%d", &a);
      if (sum == -1)
        s.insert(a);
      else
        s.insert((a + sum) % MOD), sum = -1;
    }
    else
    {
      int l, r;
      scanf("%d%d", &l, &r);

      sum = 0;
      for (set <int>::iterator it = s.lower_bound(l); *it <= r; it++)
        sum += *it;
      printf(I64 "\n", sum);
      s.insert(sum % MOD);
    }
  }
  return 0;
}
