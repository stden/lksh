#include <iostream>

using namespace std;

#if (defined(WIN32) || !defined(__GNUC__))
#  define I64 "%I64d"
#else
#  define I64 "%Ld"
#endif


#define forn(i, n) for (int i = 0; i < int(n); ++i)

int get_random() {        
	return (rand() << 16) | rand();
}

struct tree {
	int x, y;	
	tree* l, *r;
	long long sum;
	                                              
	tree(int x): x(x), y(get_random()), l(0), r(0), sum(x) {}
	tree() {}
};

void update(tree* v) {
	if (!v) return;
	v->sum = v->x;
	if (v->l) v->sum += v->l->sum;
	if (v->r) v->sum += v->r->sum;
}

void split(tree* t, int x, tree*& l, tree*& r) {
	if (!t)
		l = r = 0;
	else if (t->x <= x)
		split(t->r, x, t->r, r), l = t;			
	else
		split(t->l, x, l, t->l), r = t;
	update(l);
	update(r);
}

tree* merge(tree* l, tree* r) {
	tree* res;
	if (!l)
		res = r;
	else if (!r)
		res = l;
	else if (l->y > r->y)
		l->r = merge(l->r, r), res = l;
	else
		r->l = merge(l, r->l), res = r;
	update(res);
	return res;
}

tree* find(tree* t, int x) {
	if (!t) return 0;
	if (t->x == x) return t;
	if (t->x < x) 
		return find(t->r, x);
	else	
		return find(t->l, x);
}

void add(tree*& t, int x) {
	if (find(t, x)) return;
	tree* p = new tree(x);
	tree* l, *r;
	split(t, x, l, r);
	t = merge(l, p);
	t = merge(t, r);
}

long long rsq(tree*& t, int l, int r) {
	tree* a, *b, *c, *d;
	split(t, l - 1, a, b);
	split(b, r, c, d);
	long long ans = 0;
	if (c) ans += c->sum;
	t = merge(a, c);
	t = merge(t, d);
	return ans;
}

int main() {

	freopen("sum.in", "rt", stdin);
	freopen("sum.out", "wt", stdout);

	tree* t = 0;

	int n;
	scanf("%d", &n);
	long long last = 0;
	forn (it, n) {
		int c = getchar();
		while (c <= ' ') c = getchar();
		if (c == '?') {
			int l, r;
			scanf("%d%d", &l, &r);			
			last = rsq(t, l, r);
			printf(I64 "\n", last);
		} else {
			int i;
			scanf("%d", &i);
			last %= 1000000000;
			add(t, (i + last) % 1000000000);
			last = 0;
		}
	}

	return 0;
}