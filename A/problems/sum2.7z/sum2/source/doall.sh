#!/bin/sh

echo "compile..."
g++ -O2 -Wall -o gen.exe gen.cpp || exit 1

echo -n "generate tests..."
cp 01.hand 01
./gen.exe 1000001 30 100 > 02
./gen.exe 1000002 100 1000000000 > 03
./gen.exe 1000003 300 1000000000 > 04
./gen.exe 1000004 1000 1000000000 > 05
./gen.exe 1000005 3000 1000000000 > 06
./gen.exe 1000006 10000 1000000000 > 07
./gen.exe 1000007 30000 1000000000 > 08
./gen.exe 1000008 100000 1000000000 > 09
./gen.exe 1000009 300000 1000000000 > 10
echo ""

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

