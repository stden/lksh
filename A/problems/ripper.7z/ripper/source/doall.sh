#!/bin/bash

rm -rf ../tests/
mkdir ../tests/
7z x tests.7z
mv ?? ../tests/

