#include <testlib.h>

const int maxp = 100;
const int maxh = 100;
const int maxw = 100;

int main() {
  registerValidation();
  int p = inf.readInt(1, maxp);
  inf.readSpace();
  int h = inf.readInt(1, maxh);
  inf.readSpace();
  int w = inf.readInt(1, maxw);
  inf.readEoln();
  char temp[100];
  sprintf(temp, "[A-Z]{1,%d}", w);
  for (int i = 0; i < p; i++)
    for (int j = 0; j < h; j++) {
      inf.readToken(temp);
      inf.readEoln();
    }
  sprintf(temp, "[A-Z]{1,%d}", w = 1000000);
  inf.readToken(temp);
  inf.readEoln();
  inf.readEof();
  return 0;
}

