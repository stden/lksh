import java.io.*;
import java.util.*;


public class refrain_as implements Runnable {
    StreamTokenizer in;

    int n;
    int t;
    int[] c;
    int[][] next;
    boolean[] mark;
    int[] l;
    int[] f;
    long[] count;
    int[] solid;
    boolean[] u;

    void dfs(int x) {
        u[x] = true;

        if (mark[x]) {
            count[x] = 1;
        } else {
            count[x] = 0;
        }
        for (int i = 0; i < t; i++) {
            if (next[x][i] != -1) {
                if (!u[next[x][i]]) {
                    dfs(next[x][i]);
                }
                count[x] += count[next[x][i]];
            }
        }
    }

    public void run() {
        try {
            in = new StreamTokenizer(new FileReader(new File("refrain.in")));
            n = nextInt();
            t = nextInt();
            c = new int[n];
            for (int i = 0; i < n; i++) {
                c[i] = nextInt() - 1;
            }
        } catch (IOException e) {
        }
        next = new int[2 * n][t];
        Arrays.fill(next[0], -1);

        l = new int[2 * n];
        f = new int[2 * n];
        solid = new int[2 * n];

        int m = 1;
        l[m - 1] = 0;
        f[m - 1] = -1;
        int last = 0;
        for (int i = 0; i < n; i++) {
            int ns = m;
            m++;
            Arrays.fill(next[ns], -1);
            l[ns] = i + 1;
            solid[ns] = last;

            int p = last;
            while (p != -1 && next[p][c[i]] == -1) {
                next[p][c[i]] = ns;
                p = f[p];
            }

            if (p == -1) {
                f[ns] = 0;
            } else {
                int q = next[p][c[i]];
                if (l[q] == l[p] + 1) {
                    f[ns] = q;
                } else {
                    int r = m;
                    m++;
                    System.arraycopy(next[q], 0, next[r], 0, t);
                    f[r] = f[q];
                    f[q] = r;
                    f[ns] = r;
                    l[r] = l[p] + 1;
                    solid[r] = p;
                    while (p != -1 && next[p][c[i]] == q) {
                        next[p][c[i]] = r;
                        p = f[p];
                    }
                }
            }
            last = ns;
        }

        mark = new boolean[2 * n];
        int p = last;
        while (p != -1) {
            mark[p] = true;
            p = f[p];
        }

        count = new long[2 * n];
        u = new boolean[2 * n];
        dfs(0);

        long best = 0;
        int besti = 0;
        for (int i = 0; i < m; i++) {
            if (count[i] * l[i] > best) {
                best = count[i] * l[i];
                besti = i;
            }
        }

        int[] ans = new int[l[besti]];
        {
            int i = besti;
            while (i != 0) {
                int j = solid[i];
                for (int k = 0; k < t; k++) {
                    if (next[j][k] == i) {
                        ans[l[i] - 1] = k + 1;
                    }
                }
                i = j;
            }
        }

        PrintWriter out = null;
        try {
            out = new PrintWriter(new File("refrain.out"));
        } catch (FileNotFoundException e) {
        }
        out.println(best);
        out.println(ans.length);
        for (int i = 0; i < ans.length; i++) {
            out.print(ans[i] + " ");
        }
        out.println();
        out.close();
    }

    int nextInt() throws IOException {
        in.nextToken();
        return (int) in.nval;
    }

    public static void main(String[] arg) throws IOException {
        new Thread(new refrain_as()).start();
    }
}
