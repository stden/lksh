#include <testlib.h>

const int maxn = 50000;
const int maxm = 100000;
const int maxl = 50000;

int main() {
  registerValidation();
  int sumN = 0, sumM = 0, sumL = 0;
  while (true) {
    int n = inf.readInt(0, maxn);
    inf.readSpace();
    int m = inf.readInt(0, maxm);
    inf.readSpace();
    int t = inf.readInt(0, n);
    inf.readEoln();
    if (n == 0 && m == 0 && t == 0)
      break;
    ensuref(n > 0 && m > 0 && t > 0, "n, m, t должны быть положительны");
    ensuref((sumN += n) <= maxn, "сумма всех n превосходит ограничения");
    ensuref((sumM += m) <= maxm, "сумма всех m превосходит ограничения");
    int c[n];
    memset(c, 0, sizeof(c));
    for (int i = 0; i < t; i++) {
      int a = inf.readInt(1, n) - 1;
      ensuref(c[a] == 0, "вершина %d указана дважды в списке допускающих", a + 1);
      if (i == t - 1)
        inf.readEoln();
      else
        inf.readSpace();
    }
    for (int i = 0; i < m; i++) {
      inf.readInt(1, n);
      inf.readSpace();
      inf.readInt(1, n);
      inf.readSpace();
      inf.readToken("[a-z]");
      inf.readEoln();
    }
    int len = inf.readToken("[a-z]{1,50000}").length();
    inf.readEoln();
    ensuref((sumL += len) <= maxl, "сумма длин строк превосхоодит ограничения");
  }
  inf.readEof();
  return 0;
}

