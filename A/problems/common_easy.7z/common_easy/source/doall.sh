#!/bin/sh

g++ -O2 -Wall -o gen gen.cpp || exit 1

echo "generate tests..."
for i in *.hand; do
  cp "$i" "${i%.hand}"
done

./gen 37 50 > 07 || exit 1
./gen 43 60 > 08 || exit 1
./gen 97 75 > 09 || exit 1
./gen 83 32 > 10 || exit 1
./gen 23 27 > 11 || exit 1
./gen 91 98 > 12 || exit 1
./gen 87 99 > 13 || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

