#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#include <vector>

using namespace std;


vector < string > ans;

int main(int argc, char *argv[])
{
	int n, u;
	u = atoi(argv[1]), n = atoi(argv[2]); 	
	string a, b;
	for (int i = 0; i < n; ++i)
		a = a + char('0'+(rand()&1));
	for (int i = 0; i < n; ++i)
		b = b + char('0'+(rand()&1));
	int len = a.length();
	if (b.length() < len) len = b.length();
	
	for (int i = 1; i <= len; ++i)
	{
		for (int aa = 0; aa+i-1 < a.length(); ++aa)
			for (int bb = 0; bb+i-1 < b.length(); ++bb)
				if (a.substr(aa, i) == b.substr(bb, i))
					ans.push_back(a.substr(aa, i));
	}
	sort(ans.begin(), ans.end());
	ans.erase(unique(ans.begin(), ans.end()), ans.end());
	
	int k = (rand()&((ans.size())-1)) + 1;	
	cout << a << endl << b << endl;
	cout << k << endl;

	return 0;
}