#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#include <vector>

using namespace std;


vector < string > ans;

int main()
{
	freopen("common.in", "r", stdin);
	freopen("common.out", "w", stdout);

	string a, b;
	cin >> a >> b;
	int len = a.length();
	if (b.length() < len) len = b.length();
	
	for (int i = 1; i <= len; ++i)
	{
		for (int aa = 0; aa+i-1 < a.length(); ++aa)
			for (int bb = 0; bb+i-1 < b.length(); ++bb)
				if (a.substr(aa, i) == b.substr(bb, i))
					ans.push_back(a.substr(aa, i));
	}
	sort(ans.begin(), ans.end());
	ans.erase(unique(ans.begin(), ans.end()), ans.end());
	
	int k;
	cin >> k;	
	cout << ans[k-1] << endl;

	return 0;
}
