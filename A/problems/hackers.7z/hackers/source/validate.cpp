#include <testlib.h>

const int maxn = 50;
const int maxm = 100;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readSpace();
  int m = inf.readInt(0, maxm);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    int a = inf.readInt(1, n);
    inf.readSpace();
    int b = inf.readInt(1, n);
    inf.readEoln();
    ensuref(a != b, "петля вокруг вершины %d", a);
  }
  inf.readEof();
  return 0;
}

