#include <testlib.h>

const int MaxN = 51;

bool a[MaxN], g[MaxN][MaxN];
int n;

void poisk( int v ) {
  a[v] = true;
  for (int i = 0; i < n; i++)
    if (!a[i] && g[v][i])
      poisk(i);
}

int answer( InStream &f ) {
  int res = f.readInt();
  if (res < 0 || res > n) {
    for (int i = 0; i < res; i++)
      f.readInt();
    quitf(_wa, "answer cannot be %d", res);
  }
  memset(a, 0, sizeof(a));
  int x[res];
  for (int i = 0; i < res; i++)
    x[i] = f.readInt();
  for (int i = 0; i < res; i++) {
    if (x[i] < 1 || x[i] > n)
      quitf(_wa, "server %d cannot be down", x[i]);
    if (a[x[i] - 1])
      quitf(_wa, "server %d id down twice", x[i]);
    a[x[i] - 1] = true;
  }
  if (res == n)
    return res;
  for (int i = 0; i < n; i++)
    if (!a[i]) {
      poisk(i);
      break;
    }
  for (int i = 0; i < n; i++)
    if (!a[i])
      return res;
  quitf(_wa, "Network is still connected");
}

int main( int argc, char **argv ) {
  registerTestlibCmd(argc, argv);
  n = inf.readInt();
  int m = inf.readInt();
  for (int i = 0; i < m; i++) {
    int u = inf.readInt();
    int v = inf.readInt();
    g[u - 1][v - 1] = true;
    g[v - 1][u - 1] = true;
  }
  int ja = answer(ans);
  int pa = answer(ouf);
  if (ja < pa)
    quitf(_wa, " not optimal solution: %d instead of %d", pa, ja);
  else if (ja > pa)
    quitf(_fail, " not optimal solution: %d instead of %d", ja, pa);
  quitf(_ok, "%d servers", ja);
}

