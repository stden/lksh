// suffix automaton

#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:30000000")

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>
#include <memory>
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define cinfile "nenokku.in"
#define coutfile "nenokku.out"

#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define f0(a) memset(a, 0, sizeof(a))
#define ff(a) memset(a, 0xff, sizeof(a))

#define VI vector<int>
#define pb push_back
#define all(a) a.begin(), a.end()

#define ech(a) (a == '\n' || a == '\0')

const int inf = (int)1e+9;
const double eps = (double)1e-9;
const int nmax = 100001;

char s[nmax];
int n = 1, last = 0;
int next[2*nmax][26];
int suf[2*nmax];
int l[2*nmax];

int main()
{
    freopen(cinfile, "rt", stdin);
    freopen(coutfile, "wt", stdout);

    ff(next);
    suf[0] = -1;
    l[0] = 0;
    while (fgets(s, nmax, stdin)) {
        if (s[0] == 'A') {
            for (int i = 2; !ech(s[i]); ++i) {
                char c = (s[i] >= 'a' && s[i] <= 'z') ? (s[i] - 'a') : (s[i] - 'A');
//fprintf(stderr, "add %c\n", c + 'a');
                int p = last;
                last = n++;
                l[last] = l[p] + 1;
                while (p >= 0 && next[p][c] == -1) {
                    next[p][c] = last;
                    p = suf[p];
                }
                if (p == -1) suf[last] = 0;
                else {
                    int q = next[p][c];
                    if (l[q] == l[p] + 1) suf[last] = q;
                    else {
                        int z = n++;
                        memcpy(next[z], next[q], 26*sizeof(int));
                        l[z] = l[p] + 1;
                        suf[z] = suf[q];
                        suf[q] = z;
                        suf[last] = z;
                        while (p >= 0 && next[p][c] == q) {
                            next[p][c] = z;
                            p = suf[p];
                        }
                    }
                }
            }
        } else {
            int cur = 0;
            for (int i = 2; !ech(s[i]) && cur >= 0; ++i) {
                char c = (s[i] >= 'a' && s[i] <= 'z') ? (s[i] - 'a') : (s[i] - 'A');
//fprintf(stderr, "search %c\n", c + 'a');
                cur = next[cur][c];
            }
            if (cur >= 0) printf("YES\n"); else printf("NO\n");
        }
    }

    return 0;
}
