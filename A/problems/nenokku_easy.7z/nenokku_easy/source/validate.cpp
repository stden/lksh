#include <testlib.h>

const int maxlen = 100000;
const int maxsize = 1 << 10;
const int maxq = 50;

int main() {
  registerValidation();
  int size = 0, length = 0, count = 0;
  while (!inf.eof()) {
    char ch = inf.readChar(); size++;
    ensure(ch == '?' || ch == 'A');
    inf.readSpace(), size++;
    ensure(++count <= maxq);
    if (ch == '?')
      size += inf.readToken("[a-zA-Z]{1,50}").length();
    else if (ch == 'A') {
      int temp = inf.readToken("[a-zA-z]{1,100000}").length();
      ensure((size += temp) <= maxsize);
      ensure((length += temp) <= maxlen);
    }
    inf.readEoln();
    ensure(++size <= maxsize);
  }
  return 0;
}

