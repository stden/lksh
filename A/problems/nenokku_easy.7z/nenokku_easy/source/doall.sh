#!/bin/sh

echo "compile.."
echo "stupid suffix “.exe” added for compatibility with outdated operation systems"
#g++ -O2 -Wall -o split.exe split.cpp || exit 1
g++ -O2 -Wall -o gen.exe gen.cpp || exit 1

echo -n "generate tests"
for i in `seq -w 01 02`; do
  echo -n "."
  cp $i.hand $i || exit 1
done
./gen.exe 239    15 2  > 03
./gen.exe 17239  20 3  > 04
./gen.exe 23917  30 5  > 05
./gen.exe 17     30 10 > 06
./gen.exe 239017 30 10 > 07
./gen.exe 170239 30 10 > 08
./gen.exe 1543   30 20 > 09
./gen.exe 19     30 25 > 10
echo ""

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

