#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <cstdlib>
#include "random.h"

using namespace std;

string s, s1;

int main(int argc, char *argv[])
{
	int rn = atoi(argv[1]), kolz = atoi(argv[2]), mx = atoi(argv[3]);
	initrand(rn);
	for (int i = 0; i < kolz; ++i)
	{
		if (R(0, 1) == 0)
		{
			s1 = "";
			int d = R(1, mx);
			for (int i = 0; i < d; ++i)
				s1 += (char)(R(0, 10)+'a');
			cout << "A " << s1 << endl;
			s += s1;
		}
		else
		{
			if ((R(0, 1) == 0) && (s.length() > 0))
			{
				int u, v, p = s.length()-1;
				u = R(0, p);
				v = R(u, min(p, u+mx));
				cout << "? " << s.substr(u, v-u+1) << endl;
			}
			else
			{
				bool yes;
				do {
					s1 = "";
					int d1 = R(1, mx);
					for (int i = 0; i < d1; ++i)
						s1 += (char)(R(0, 10)+'a');
					yes = false;
					for (int i = 0; i+d1-1 < s.length(); ++i)
						if (s.substr(i, d1) == s1)
							yes = true;	
				}while (yes);
				cout << "? " << s1 << endl;
			}
		}
	}

	return 0;
}