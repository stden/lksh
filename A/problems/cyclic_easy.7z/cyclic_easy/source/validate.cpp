#include <testlib.h>

const int maxl = 30;

int main( int argc, char *argv[] ) {
  registerValidation();
  char temp[100];
  sprintf(temp, "[a-z]{1,%d}", maxl);
  inf.readToken(temp);
  inf.readEoln();
  inf.readEof();
  return 0;
}

