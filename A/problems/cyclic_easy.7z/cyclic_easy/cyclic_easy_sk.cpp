#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define maxn 2000100

char s[maxn];
int len, z[maxn];

int main( void )
{
  freopen("cyclic.in", "rt", stdin);
  freopen("cyclic.out", "wt", stdout);
  gets(s), len = strlen(s);
  memcpy(s + len, s, len);

  int i, k, l = -1, r = -1, num = 0;
  z[0] = 0;
  for (i = 1; i < len; i++)
  {
    k = 0;
    if (r > i)
      k = max(k, min(r - i, z[i - l]));
    while (s[k] == s[i + k])
      k++;
    z[i] = k;
    if (i + k > r)
      l = i, r = i + k;
    if (z[i] < len && s[i + k] < s[k])
      num++;
  }
  printf("%d\n", num + 1);
  return 0;
}
