import java.util.*;
import java.io.*;
import java.math.BigInteger;

public class decomposition_hz implements Runnable {
       BufferedReader in;
       StringTokenizer st;
       PrintWriter out;

       public static void main(String[] args) {
               new Thread(new decomposition_hz()).run();
       }

       public void run() {
               try {
                       Locale.setDefault(Locale.US);
                       in = new BufferedReader(new FileReader("decomposition.in"));
                       st = new StringTokenizer("");
                       out = new PrintWriter(new File("decomposition.out"));
                       solve();
               } catch (Exception e) {
                       e.printStackTrace();
               } finally {
                       out.close();
               }
       }

       String nextToken() throws IOException {
               while (st == null || !st.hasMoreElements()) {
                       try {
                               st = new StringTokenizer(in.readLine());
                       } catch (Exception e) {
                               System.exit(1);
                       }
               }
               return st.nextToken();
       }

       int nextInt() throws NumberFormatException, IOException {
               return Integer.parseInt(nextToken());
       }

       long nextLong() throws NumberFormatException, IOException {
               return Long.parseLong(nextToken());
       }

       double nextDouble() throws NumberFormatException, IOException {
               return Double.parseDouble(nextToken());
       }

       BigInteger nextBigInt() throws IOException {
               return new BigInteger(nextToken());
       }

       void solve() throws IOException {
               int n = nextInt();
               int m = nextInt();
               int[][] c = new int[n][n];
               int[][] f = new int[n][n];
               int[][] ednum = new int[n][n];
               int[] val = new int[2 * m];
               int[] head = new int[n];
               int[] next = new int[2 * m];
               for (int i = 0; i < n; ++i) {
                       head[i] = -1;
               }
               int cmax = 0;
               for (int i = 0; i < m; ++i) {
                       int a = nextInt() - 1;
                       int b = nextInt() - 1;
                       c[a][b] = nextInt();
                       ednum[a][b] = i + 1;
                       if (c[a][b] > cmax) {
                               cmax = c[a][b];
                       }

                       next[i] = head[a];
                       head[a] = i;
                       val[i] = b;

                       next[i + m] = head[b];
                       head[b] = i + m;
                       val[i + m] = a;
               }

               int k = 1;
               while (k << 1 <= cmax) {
                       k <<= 1;
               }
               int bits = 0;
               int[] q = new int[n];
               int h = 0;
               int t = 0;
               int[] p = new int[n];
               int[] used = new int[n];
               for (int i = k; i > 0; i >>= 1) {
                       bits += i;
                       boolean fl = true;
                       while (fl) {
                               for (int j = 0; j < n; ++j) {
                                       p[j] = -1;
                                       used[j] = 0;
                               }
                               used[0] = 1;
                               h = 0;
                               t = 0;
                               while (t <= h) {
                                       for (int e = head[q[t]]; e != -1; e = next[e]) {
                                               if ((c[q[t]][val[e]] & bits) > 0 && used[val[e]] == 0) {
                                                       ++h;
                                                       q[h] = val[e];
                                                       p[val[e]] = q[t];
                                                       used[val[e]] = 1;
                                               }
                                       }
                                       ++t;
                               }
                               fl = p[n - 1] != -1;
                               if (fl) {
                                       int cmin = c[p[n - 1]][n - 1];
                                       for (int j = p[n - 1]; j != 0; j = p[j]) {
                                               if (c[p[j]][j] < cmin) {
                                                       cmin = c[p[j]][j];
                                               }
                                       }
                                       for (int j = n - 1; j != 0; j = p[j]) {
                                               f[p[j]][j] += cmin;
                                               f[j][p[j]] -= cmin;
                                               c[p[j]][j] -= cmin;
                                               c[j][p[j]] += cmin;
                                       }
                               }
                       }
               }

               int[][] ans = new int[m / 2 + 1][];
               int anscnt = 0;
               boolean fl = true;
               while (fl) {
                       for (int j = 0; j < n; ++j) {
                               p[j] = -1;
                               used[j] = 0;
                       }
                       used[0] = 1;
                       h = 0;
                       t = 0;
                       while (t <= h) {
                               for (int e = head[q[t]]; e != -1; e = next[e]) {
                                       if (f[q[t]][val[e]] > 0 && used[val[e]] == 0) {
                                               ++h;
                                               q[h] = val[e];
                                               p[val[e]] = q[t];
                                               used[val[e]] = 1;
                                       }
                               }
                               ++t;
                       }
                       fl = p[n - 1] != -1;
                       if (fl) {
                               int fmin = f[p[n - 1]][n - 1];
                               int curcnt = 1;
                               for (int j = p[n - 1]; j != 0; j = p[j]) {
                                       if (f[p[j]][j] < fmin) {
                                               fmin = f[p[j]][j];
                                       }
                                       ++curcnt;
                               }
                               ans[anscnt] = new int[curcnt + 2];
                               ans[anscnt][0] = fmin;
                               ans[anscnt][1] = curcnt;
                               int tmp = curcnt + 1;
                               for (int j = n - 1; j != 0; j = p[j]) {
                                       f[p[j]][j] -= fmin;
                                       ans[anscnt][tmp] = ednum[p[j]][j];
                                       --tmp;
                               }
                               ++anscnt;
                       }
               }

               out.println(anscnt);
               for (int i = 0; i < anscnt; ++i) {
                       for (int j = 0; j < ans[i][1] + 2; ++j) {
                               out.print(ans[i][j] + " ");
                       }
                       out.println();

               }
        }
}