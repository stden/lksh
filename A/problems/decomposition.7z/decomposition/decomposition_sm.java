import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

public class decomposition_sm {

    class Edge {
	int id;
	int from, to;
	Edge rev;
	int flow, cap;

	public Edge(int from, int to, int cap, int id, Edge rev) {
	    this.from = from;
	    this.to = to;
	    this.cap = cap;
	    this.id = id;
	    if (rev == null) {
		this.rev = new Edge(to, from, 0, -id, this);
	    } else {
		this.rev = rev;
	    }
	}

    }

    ArrayList<Edge>[] es;
    int n;
    boolean[] u;

    @SuppressWarnings("unchecked")
    private void solve() {
	n = nextInt();
	int m = nextInt();
	es = new ArrayList[n];
	for (int i = 0; i < es.length; i++) {
	    es[i] = new ArrayList<Edge>();
	}
	for (int i = 0; i < m; i++) {
	    Edge edge = new Edge(nextInt() - 1, nextInt() - 1, nextInt(),
		    i + 1, null);
	    es[edge.from].add(edge);
	    es[edge.rev.from].add(edge.rev);
	}
	u = new boolean[n];
	int ans = 0;
	for (int i = 1 << 20; i > 0; i /= 2) {
	    while (true) {
		Arrays.fill(u, false);
		int flow = dfs(0, Integer.MAX_VALUE, i);
		if (flow == 0) {
		    break;
		}
		ans += flow;
	    }
	}
	ArrayList<ArrayList<Integer>> all = new ArrayList<ArrayList<Integer>>();
	ArrayList<Integer> flows = new ArrayList<Integer>();
	while (true) {
	    al = new ArrayList<Integer>();
	    Arrays.fill(u, false);
	    int r = dfs2(0, Integer.MAX_VALUE);
	    if (r == 0)
		break;
	    Collections.reverse(al);
	    all.add(al);
	    flows.add(r);
	}
	out.println(all.size());
	for (int i = 0; i < all.size(); i++) {
	    ArrayList<Integer> al = all.get(i);
	    int flow = flows.get(i);
	    out.print(flow + " " + al.size());
	    for (int j : al) {
		out.print(" " + j);
	    }
	    out.println();
	}
    }

    int dfs2(int v, int can) {
	if (v == n - 1) {
	    return can;
	}
	u[v] = true;
	for (Edge e : es[v]) {
	    if (e.flow > 0) {
		int r = dfs2(e.to, Math.min(can, e.flow));
		if (r > 0) {
		    e.flow -= r;
		    al.add(e.id);
		    return r;
		}
	    }
	}
	return 0;
    }

    ArrayList<Integer> al;

    int dfs(int v, int can, int min) {
	if (v == n - 1) {
	    return can;
	}
	u[v] = true;
	for (Edge e : es[v]) {
	    if (!u[e.to] && e.cap - e.flow >= min) {
		int r = dfs(e.to, Math.min(can, e.cap - e.flow), min);
		if (r > 0) {
		    e.flow += r;
		    e.rev.flow -= r;
		    return r;
		}
	    }
	}
	return 0;
    }

    PrintWriter out;
    BufferedReader br;
    StringTokenizer st;

    private void run() {
	try {
	    br = new BufferedReader(new FileReader(this.getClass().getName()
		    .substring(0, this.getClass().getName().indexOf("_"))
		    + ".in"));
	    out = new PrintWriter(this.getClass().getName().substring(0,
		    this.getClass().getName().indexOf("_"))
		    + ".out");
	    solve();
	    out.close();
	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	    System.exit(1);
	}
    }

    String nextToken() {
	try {
	    while (st == null || !st.hasMoreTokens()) {
		st = new StringTokenizer(br.readLine());
	    }
	    return st.nextToken();
	} catch (IOException e) {
	    return "";
	}
    }

    int nextInt() {
	return Integer.parseInt(nextToken());
    }

    public static void main(String[] args) {
	new decomposition_sm().run();
    }
}
