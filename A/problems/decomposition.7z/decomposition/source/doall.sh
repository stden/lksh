#!/bin/bash

rm -rf ../tests/
mkdir ../tests/

for i in *.manual; do
  cp "$i" "../tests/${i%.manual}"
done

javac TestsGen.java
java TestsGen
mv ?? ../tests/

