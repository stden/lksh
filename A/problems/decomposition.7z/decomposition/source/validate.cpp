#include <testlib.h>

const int maxn = 500;
const int maxm = 10000;
const int maxc = 1000000000;

int main() {
  registerValidation();
  int n = inf.readInt(2, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxm);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    inf.readInt(1, n);
    inf.readSpace();
    inf.readInt(1, n);
    inf.readSpace();
    inf.readInt(1, maxc);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

