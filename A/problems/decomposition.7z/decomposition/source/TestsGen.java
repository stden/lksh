import java.io.*;
import java.util.*;

public class TestsGen implements Runnable {
	public static void main(String[] args) {
		if (args.length < 1) {
			for (I = 1; (new File(getName(I) + ".manual")).exists(); I++)
				;
		} else {
			I = Integer.parseInt(args[0]);
		}
		new Thread(new TestsGen()).start();
	}

	PrintWriter out;

	Random rand = new Random(6439586L);

	static int I;

	static String getName(int i) {
		return ((i < 10) ? "0" : "") + i;
	}

	void open() {
		try {
			System.out.println("Generating test " + I);
			out = new PrintWriter(getName(I));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	void close() {
		out.close();
		I++;
	}

	final String ALPHA = "abcdefghijklmnopqrstuvwxyz";

	String randString(int len, String alpha) {
		StringBuilder ans = new StringBuilder();
		int k = alpha.length();
		for (int i = 0; i < len; i++) {
			ans.append(alpha.charAt(rand.nextInt(k)));
		}
		return ans.toString();
	}

	long rand(long l, long r) {
		return l + (rand.nextLong() >>> 1) % (r - l + 1);
	}

	int rand(int l, int r) {
		return l + rand.nextInt(r - l + 1);
	}

	
	class Edge {
		int a, b, c;
		
		public Edge(int a, int b, int c) {
			this.a = a;
			this.b = b;
			this.c = c;
		}
	}
	
	int[] randPerm(int n) {
		int[] p = new int[n];
		for (int i = 1; i < n; ++i) {
			int j = rand.nextInt(i);
			p[i] = p[j];
			p[j] = i;
		}
		return p;
	}
	
	void save(ArrayList<Edge> g, int n) {
		int[] p = randPerm(n);
		Collections.shuffle(g);
		open();
		out.println(n + " " + g.size());
		for (Edge e : g) {
			out.println((p[e.a] + 1) + " " + (p[e.b] + 1) + " " + e.c);
		}
		close();
	}
	
	final int MAXC = 1000000000;
	

	void genMaxPaths(int n0, int m) {
		ArrayList<Edge> g = new ArrayList<Edge>();
		
		for (int i = 0; i < n0; ++i) {
			g.add(new Edge(0, i + 1, MAXC));
		}
		
		for (int i = 0; i < n0; ++i) {
			g.add(new Edge(n0 + i + 1, 1 + n0 + n0, MAXC));
		}
		for (int i = 0; i < n0; ++i) {
			g.add(new Edge(1 + n0 + n0 + i, 1 + n0 + n0 + i + 1, MAXC));
		}
		
		for (int i = 0; i < m - 3 * n0; ++i) {
			g.add(new Edge(1 + rand.nextInt(n0), 1 + n0 + rand.nextInt(n0), 1));
		}
		int n = 3 * n0 + 2;
		save(g, n);
	}
	
	
	void genAntiFF(int n, int k, int m) {
		ArrayList<Edge> g = new ArrayList<Edge>();
		
		for (int i = 0; i < n; ++i) {
			g.add(new Edge(0, i + 1, MAXC));
			g.add(new Edge(1 + n * (k - 1) + i, 1 + n * k, MAXC));
		}
		
		m = m - (k + 1) * n;
		
		for (int i = 0; i < k - 1; ++i) {
			for (int j = 0; j < n; ++j) {
				g.add(new Edge(1 + n * i + j, 1 + n * i + n + j, 1));
			}
			int left = m / (k - 1 - i);
			m -= left;
			for (int j = 0; j < left; ++j) {
				g.add(new Edge(1 + n * i + rand.nextInt(n), 1 + n * i + n + rand.nextInt(n), 1));
			}
		}
		save(g, 2 + n * k);
	}
	
	void genRand(int n, int m) {
		ArrayList<Edge> g = new ArrayList<Edge>();
		for (int i = 1; i < n; ++i) {
			g.add(new Edge(rand.nextInt(i), i, rand(1, MAXC)));
		}
		for (int i = n - 2; i >= 0; --i) {
			g.add(new Edge(i, rand(i + 1, n - 1), rand(1, MAXC)));
		}
		
		for (int i = 0; i < m - 2 * (n - 1); ++i) {
			int a = rand(0, n - 1);
			int b = rand(0, n - 2);
			if (b >= a) ++b;
			g.add(new Edge(a, b, rand(1, MAXC)));
		}
		
		save(g, n);
	}
	
	final int MAXN = 500;
	final int MAXM = 10000;
	
	public void solve() throws IOException {
		for (int i = 0; i < 10; ++i) {
			int n = rand(2, 10);
			genRand(n, rand(2 * (n - 1), 30));
		}
		
		for (int i = 0; i < 10; ++i) {
			int n = rand(MAXN / 2, MAXN);
			genRand(n, rand(2 * (n - 1), MAXM));
		}
		
		for (int i = 0; i < 10; ++i) {
			genMaxPaths(rand(MAXN / 4, MAXN / 3), rand(MAXM / 2, MAXM));
		}
		
		for (int i = 0; i < 10; ++i) {
			int n = rand(3, 10);
			genAntiFF(n, (MAXN - 2) / n, rand(MAXM / 2, MAXM));
		}
		genMaxPaths(MAXN / 3, MAXM);
		genAntiFF(20, 24, MAXM);
	}

	void myAssert(boolean e) {
		if (!e) {
			throw new Error("Assertion failed");
		}
	}

	public void run() {
		try {
			solve();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
}
