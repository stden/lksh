import java.io.*;
import java.util.*;

public class system_ft implements Runnable {

    private static final double EPS = 1e-12;
    private Scanner in;
    private PrintWriter out;
    String fname = "lucky";

    private void myAssert(boolean e, String message) {
        if (!e) {
            throw new Error("Assertion failure!!! " + message);
        }
    }

    int calc(int x, int d, int dig) {
        int res = 0;
        while (x % d == dig) {
            x /= d;
            res++;
        }
        return res;
    }

    public void solve() {
        int n = in.nextInt();
        int k = in.nextInt();
        if (k > n) {
            out.println(2 + " " + calc(n, 2, k));
            return;
        }
        int max = -1;
        int best = 2;
        for (int i = 2; i * i <= n - k; i++) {
            if ((n - k) % i == 0) {
                if (calc(n, i, k) > max) {
                    best = i;
                    max = calc(n, i, k);
                }   
                int d = (n - k) / i;
                if ((n - k) % d == 0) {
                    if (calc(n, d, k) > max) {
                        best = d;
                        max = calc(n, d, k);
                    }   
                }
            }
        }
        out.println(best + " " + max);
    }

    public void run() {
        try {
            solve();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        } finally {
            out.close();
        }       
    }

    public system_ft() {
        try {
            in = new Scanner(new File(fname + ".in"));
            out = new PrintWriter(new File(fname + ".out"));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        new Thread(new system_ft()).start();
    }

}                       