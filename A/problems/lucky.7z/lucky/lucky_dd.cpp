#include <iostream>
#include <fstream>
#include <cstdio>
#include <cmath>
using namespace std;

#define int64 long long

int64 n, k;

int Check(int64 d)
{
    if (d <= 1) return -1;
    int cur = 0;
    int64 nn = n;
    while (nn % d == k)
    {
        cur++;
        nn /= d;
    }
    return cur;
}

int64 mans, md;

void Solve()
{
    if (n == k) 
    {
        printf("%I64d %d", n + 1, Check(n + 1));
        return;
    }
    if (n <= k + 1)
    {
        printf("2 %d", Check(2));
        return;
    }
    md = 2;
    mans = Check(2);
    int64 d;
    int cur;
    for (d = 3; d * d * d <= n; d++)
    {
        cur = Check(d);
        if (cur > mans)
        {
            mans = cur;
            md = d;
        }
    }
    if (k != 0)
    {
        cur = Check((n - k) / k);
        if (cur > mans)
        {
            mans = cur;
            md = (n - k) / k;
        }
    }
    cur = Check(n - k);
    if (cur > mans)
    {
        mans = cur;
        md = n - k;
    }
    int64 a;
    for (a = 1; a * a * a <= n; a++)
    {
        long double d = k * k - 4 * a * ((long double)k - n);
        if (d < -1) continue;
        d = sqrt(fabs(d));
        int64 d1 = (-k + (int64)d) / (2 * a);
        cur = Check(d1);
        if (cur > mans)
        {
            mans = cur;
            md = d1;
        }
    }
    printf("%I64d %I64d", md, mans);
}

int main()
{
    freopen("lucky.in", "rt", stdin);
    freopen("lucky.out", "wt", stdout);
    while (scanf("%I64d%I64d", &n, &k) == 2)
    {
        Solve();
        printf("\n");
    }
    return 0;
}