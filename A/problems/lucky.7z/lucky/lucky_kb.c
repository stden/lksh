#include <stdio.h>
#include <stdlib.h>
#include <math.h>

FILE *fi, *fo;
long long n, l, k;
long long ans, best, m;

int
tryit (long long d)
{
  int res = 0;
  if (d < 2) return -1;
  if ((n == 0) && (k == 0)) return 1;
  l = n;
  while ((n > 0) && (n % d == k))
    {
      res++;
      n /= d;
    }
  n = l;
  return res;
}

int
main (void)
{
  long long i, j;
  long long sqrtn;
  fi = fopen ("lucky.in", "rt");
  fo = fopen ("lucky.out", "wt");

  fscanf (fi,"%I64d%I64d", &n, &k);
  ans = -1; best = -1;
  sqrtn = (long long)sqrt ((double)n) + 1;
  for (i = 2; i <= sqrtn; i++)
    {
      m = tryit (i);
      if (m > best)
    {
      ans = i;
      best = m;
    }
    }
  for (i = 1; i <= sqrtn; i++)
    {
      for (j = -10; j <= 10; j++)
    {
      m = tryit (n / i + j);
      if (m > best)
        {
          ans = n / i + j;
          best = m;
        }
    }
    }
  fprintf (fo, "%I64d %I64d", ans, best);

  fclose (fi);
  fclose (fo);
  return 0;
}
