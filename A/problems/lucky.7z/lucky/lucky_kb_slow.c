#include <stdio.h>

FILE *fi, *fo;
long long n, l, k;
long long ans, best, m;

int
tryit (long long d)
{
  int res = 0;
  if ((n == 0) && (k == 0)) return 1;
  l = n;
  while ((n > 0) && (n % d == k))
    {
      res++;
      n /= d;
    }
  n = l;
  return res;
}

int
main (void)
{
  long long i;
  fi = fopen ("lucky.in", "rt");
  fo = fopen ("lucky.out", "wt");

  fscanf (fi,"%I64d%I64d", &n, &k);
  ans = -1; best = -1;
  for (i = 2; i <= n + 1; i++)
    {
      m = tryit (i);
      if (m > best)
    {
      ans = i;
      best = m;
    }
    }
  fprintf (fo, "%I64d %I64d", ans, best);

  fclose (fi);
  fclose (fo);
  return 0;
}
