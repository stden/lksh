#include <cstdio>
#include <cmath>

typedef long long ll;
typedef long double dbl;

ll n, resd;
int k, res;

void Try( ll d )
{
  if (d <= 1)
    return;

  int cnt = 0;
  ll nn = n;
  while (nn % d == k)
    nn /= d, cnt++;
  if (cnt > res)
    res = cnt, resd = d;
}

void Try3( ll A, ll B, ll C)
{
  ll D = (ll)(sqrt((dbl)B * B - 4 * (dbl)A * C) + 0.5);
  Try((-B - D) / (2 * A));
  Try((-B + D) / (2 * A));
}

int main()
{
  freopen("lucky.in", "r", stdin);
  freopen("lucky.out", "w", stdout);

  while (scanf("%lld%d", &n, &k) == 2 && (n || k))
  {
    res = 0, resd = n + 1;
    if (n <= k)
    {
      Try(n + 1);
      printf("%lld %d\n", n + 1, res);
      continue;
    }

    res = 0, resd = n + 1;
    Try(n - k);
    for (ll d = 2; d * d * d <= n; d++)
      Try(d);
    if (k)
    {
      Try(n / k - 1);
      Try3(1, 1, 1 - n / k);
    }
    for (ll a = 1; a * a * a <= n; a++)
      Try3(a, k, k - n);
    printf("%lld %d\n", resd, res);
  }
  return 0;
}
