#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <string>
using namespace std;

#define int64 int

const int64 MAXITER = 200000000ll;

int64 n, k;

void Load()
{
    cin >> n >> k;
}

int64 Check(int64 a)
{
    int64 nn = n;
    int64 cur = 0;
    while (nn % a == k)
    {
        nn /= a;
        cur++;
    }
    return cur;
}

void Solve()
{
    if (n < k) 
    {
        cout << "2 " << Check(2);
        return;
    }
    if (n == k)
    {
        cout << n + 1 << " " << Check(2);
        return;
    }
    if (n == k + 1)
    {
        cout << "2 " << Check(2);
        return;
    }
    int64 i;
    int64 max = Check(n - k);
    int64 md = n - k;
    for (i = 2; i <= min(n, MAXITER); i++)
    {
        int cur = Check(i);
        if (cur > max)
        {
            max = cur;
            md = i;
        }
    }
    cout << md << " " << max;
}

int main()
{
    freopen("lucky.in", "rt", stdin);
    freopen("lucky.out", "wt", stdout);
    Load();
    Solve();
    return 0;
}
