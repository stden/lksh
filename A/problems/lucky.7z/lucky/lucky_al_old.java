import java.io.*;
import java.util.*;

public class system_al_old {


  static ArrayList <Long> p;
  static ArrayList <Integer> d;
  static long n, mi;
  static int k, mx;

  static void rec (int a, long c) {
    if (a == p.size ()) {
      //System.out.println (c);
      if (c > 1) {
        int cnt = 0;
        long x = n;
        while (x % c == k) {
          x /= c;
          ++cnt;
        };
        if (cnt > mx) {
          mx = cnt;
          mi = c;
        };
      };
      return;
    };

    for (int i = 0; i <= d.get (a); i++) {
      rec (a + 1, c);
      c *= p.get (a);
    }; 
  };


  public static void main (String args []) throws Exception {
    Scanner in = new Scanner (new File ("lucky.in"));
    PrintWriter out = new PrintWriter ("lucky.out");
    n = in.nextLong ();
    k = in.nextInt ();
    mx = 0;
    mi = 2;
    if (n < 1 || n > 1e11 || k < 0 || k > 9) throw new Exception ("invalid n or k");
    if (in.hasNext ()) throw new Exception ("EOF expected");
    p = new ArrayList <Long> ();
    d = new ArrayList <Integer> ();
    if (n < k) {
      out.println (2 + " " + mx);
      out.close ();
      return;
    };
    if (n == k) {
      out.println ((n + 1) + " " + mx);
      out.close ();
    };
    long x = n - k;
    for (int i = 2; ((long)i) * i <= x; i++)
      if (x % i == 0) {
        p.add ((long)i);
        int k = 0;
        while (x % i == 0) {
          x /= i;
          ++k;
        };
        d.add (k);
      };
    if (x > 1) {
      p.add (x);
      d.add (1);
    };

    rec (0, 1);

    out.println (mi + " " + mx);
    out.close ();
  };
};