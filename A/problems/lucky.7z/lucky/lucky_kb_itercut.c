#include <stdio.h>

#define MAX_ITER 10000000

FILE *fi, *fo;
long long n, l, k;
long long ans, best, m;

long long min (long long a, long long b) { return (a<b)?a:b; }

int
tryit (long long d)
{
  int res = 0;
  if ((n == 0) && (k == 0)) return 1;
  l = n;
  while ((n > 0) && (n % d == k))
    {
      res++;
      n /= d;
    }
  n = l;
  return res;
}

int
main (void)
{
  long long i, j;
  long long last_iter;
  fi = fopen ("lucky.in", "rt");
  fo = fopen ("lucky.out", "wt");

  fscanf (fi,"%I64d%I64d", &n, &k);
  ans = -1; best = -1;
  last_iter = min (n + 1, MAX_ITER);
  for (i = 2; i <= last_iter; i++)
    {
      m = tryit (i);
      if (m > best)
    {
      ans = i;
      best = m;
    }
  }
  fprintf (fo, "%I64d %I64d", ans, best);

  fclose (fi);
  fclose (fo);
  return 0;
}
