#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <string>
using namespace std;

#define int64 long long

int64 n, k;

int Load()
{
    return scanf("%I64d%I64d", &n, &k) == 2 && (n || k);
}

int64 Check(int64 a)
{
    if (a <= 1)
      return -1;

    int64 nn = n;
    int64 cur = 0;
    while (nn % a == k)
    {
        nn /= a;
        cur++;
    }
    return cur;
}

void Solve()
{
    if (n < k) 
    {
        cout << "2 " << Check(2);
        return;
    }
    if (n == k)
    {
        cout << n + 1 << " " << Check(n + 1);
        return;
    }
    if (n == k + 1)
    {
        cout << "2 " << Check(2);
        return;
    }
    int64 d = 1;
    while (d * d <= n) d++;
    int64 i;
    int64 max = Check(n - k);
    int64 md = n - k;
    for (i = 2; i <= d; i++)
    {
        if ((n - k) % i == 0)
        {
            int cur = Check(i);
            if (cur > max)
            {
                max = cur;
                md = i;
            }
            cur = Check((n - k) / i);
            if (cur > max)
            {
                max = cur;
                md = (n - k) / i;
            }
        }
    }
    printf("%I64d %I64d", md, max);
}

int main()
{
    freopen("lucky.in", "rt", stdin);
    freopen("lucky.out", "wt", stdout);
    while (Load())
    {
        Solve();
        printf("\n");
    }
    return 0;
}
