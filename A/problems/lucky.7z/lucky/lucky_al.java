import java.io.*;
import java.util.*;

public class system_al {


  static ArrayList <Long> p;
  static ArrayList <Integer> d;
  static long n, mi;
  static int k, mx;

  static void tr (long c) {
    if (c > 1) {
      int cnt = 0;
      long x = n;
      while (x % c == k) {
        x /= c;
        ++cnt;
      };
      if (cnt > mx) {
        mx = cnt;
        mi = c;
      };
    };
  };


  public static void main (String args []) throws Exception {
    Scanner in = new Scanner (new File ("lucky.in"));
    PrintWriter out = new PrintWriter ("lucky.out");
    n = in.nextLong ();
    k = in.nextInt ();
    mx = 0;
    mi = 2;
    if (n < 1 || n > 1e11 || k < 0 || k > 9) throw new Exception ("invalid n or k");
    if (in.hasNext ()) throw new Exception ("EOF expected");
    p = new ArrayList <Long> ();
    d = new ArrayList <Integer> ();
    if (n < k) {
      tr(2);
      out.println (2 + " " + mx);
      out.close ();
      return;
    };
    if (n == k) {
      tr(n + 1);
      out.println ((n + 1) + " " + mx);
      out.close ();
    };
    for (int i = 2; ((long)i) * i <= n; i++) tr (i);
    tr (n - k);
    if (k > 0) tr ((n - k) / k);
    out.println (mi + " " + mx);
    out.close ();
  };
};