import java.io.*;
import java.util.*;
public class system_vv{
    
    public static int count(int n, int m, int a){
        int res = 0;
        while (n%a==m){
            res++;
            n/=a;
        }
        return res;
    }
    
    public static void main(String[] args) throws Exception{
        BufferedReader in = new BufferedReader(new FileReader(new File("lucky.in")));
        PrintWriter out = new PrintWriter(new FileWriter(new File("lucky.out")));
        String[] s = in.readLine().split(" ");
        int n = Integer.parseInt(s[0]);
        int m = Integer.parseInt(s[1]);
        if (m>n) out.println("2 " + count(n, m, 2));
        else if (m==n) out.println(n+1 + " " + count(n, n + 1, 2));
        else if (n==m+1) out.println("2 " + count(n, m, 2));
        else {
            int best = -1;
            int bi = -1;
            for(int i = 1;i*i<=(n-m);i++) if ((n-m) % i==0){
                int t = count(n,m,(n-m)/i);
                if (t>best){best = t; bi = (n-m)/i;}
                if (i<=m) continue;
                t = count(n,m,i);
                if (t>best){best = t; bi = i;}
            }
            out.println(bi + " " + best);
        }
        out.close();
    }   
}