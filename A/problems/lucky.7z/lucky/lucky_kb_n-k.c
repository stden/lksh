#include <stdio.h>
#include <stdlib.h>
#include <math.h>

FILE *fi, *fo;
long long n, k;

int
main (void)
{
  fi = fopen ("lucky.in", "rt");
  fo = fopen ("lucky.out", "wt");

  fscanf (fi,"%I64d%I64d", &n, &k);
  fprintf (fo, "%I64d 1", n-k);

  fclose (fi);
  fclose (fo);
  return 0;
}
