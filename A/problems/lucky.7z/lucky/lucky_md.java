import java.io.*;
import java.util.*;

public class system_md implements Runnable {
    private Scanner in;
    private PrintWriter out;
    
    int n, k;
    int best, bsys;

    private void solve() {
        n = in.nextInt();
        k = in.nextInt();
        solve(n, k);
//      out.println(solve(n, k));
//      for (int n = 1; n < 100; n++) {
//          for (int k = 0; k < 10; k++) {
//              solve(n, k);
//              out.println(n + " " + k + " " + best + " " + bsys);
//          }
//      }
    }

    private int solve(int n, int k) {
        this.n = n;
        this.k = k;
        best = -1;
        bsys = -1;
        check(2);
        check(k + 1);
        int nk = n - k;
        if (nk > 0) {
            for (int d = 1; d * d <= nk; d++) {
                if (nk % d == 0) {
                    check(d);
                    check(n / d);
                }
            }
        }
        out.println(bsys + " " + best);
        return bsys;
    }

    private void check(int d) {
        if (d == 1)
            return;
        int last = 0;
        int m = n;
        while (m > 0) {
            int dig = m % d;
            m /= d;
            if (dig != k)
                break;
            last++;
        }
        if (last > best) {
            best = last;
            bsys = d;
        }
    }

    public static void main(String[] args) throws IOException {
        Locale.setDefault(Locale.US);
        new Thread(new system_md()).start();
    }

    public void run() {
        try {
            in = new Scanner(new FileReader("lucky.in"));
            out = new PrintWriter("lucky.out");
            solve();
            in.close();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
