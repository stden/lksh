#include <cstdio>
#include <cstdlib>

int main( int argc, char *argv[] )
{           
  int n = atoi(argv[1]);

  for (int i = 1; i <= n; i++)
    for (int k = 0; k <= 9; k++)
      printf("%d %d\n", i, k);
  return 0;
}
