#include <iostream>
#include <fstream>
#include <cstdio>
using namespace std;

#define int64 long long

int64 atoi64(char *s)
{
	int64 a = 0;
	int i = 0;
	while (s[i] != 0)
	{
		if ((s[i] >= '0') && (s[i] <= '9'))
		{
			a *= 10;
			a += s[i] - '0';
		}
		i++;
	}
	return a;
}

int GetSeed()
{
	asm("rdtsc");
}

int64 GetRand()
{
	int64 a = rand();
	a <<= 16;
	a |= rand();
	a <<= 16;
	a |= rand();
	a <<= 16;
	a |= rand();
	if (a < 0) a = -a;
	return a;
}

int64 IsPrime(int64 a)
{
	int64 i = 2;
	while (i * i <= a)
	{
		if (a % i == 0) return 0;
		i++;
	}
	return 1;
}

int main(int argc, char *argv[])
{
	srand(GetSeed());
	int64 minn, maxn;
	minn = atoi64(argv[1]);
	maxn = atoi64(argv[2]);
	int64 k = GetRand() % 8 + 2;
	int64 n = GetRand() % (maxn - minn + 1) + minn;
	n /= k;
	while (!IsPrime(n)) n--;
	cout << (n + 1) * k << " " << k;
	return 0;
}