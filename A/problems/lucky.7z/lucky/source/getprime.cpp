#include <fstream>
#include <iostream>
#include <cstdio>
using namespace std;

#define int64 long long

int64 atoi64(char *s)
{
	int64 a = 0;
	int i = 0;
	while (s[i] != 0)
	{
		if ((s[i] >= '0') && (s[i] <= '9'))
		{
			a *= 10;
			a += s[i] - '0';
		}
		i++;
	}
	return a;
}

int64 IsPrime(int64 a)
{
	int64 i = 2;
	while (i * i <= a)
	{
		if (a % i == 0) return 0;
		i++;
	}
	return 1;
}

int main(int argc, char *argv[])
{
	int64 n = atoi64(argv[1]);
	while (IsPrime(n) == 0) n--;
	cout << n;
	return 0;
}