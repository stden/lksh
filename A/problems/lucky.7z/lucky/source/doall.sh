#!/bin/bash

gcc -O2 -Wall -o split split.c
for i in *.manual; do
  cp "$i" "${i/\.manual/}"
done
./split < tests.txt

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

