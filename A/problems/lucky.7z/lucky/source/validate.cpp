#include <testlib.h>

const long long maxn = 100000000000ll;

int main() {
  registerValidation();
  inf.readLong(1, maxn);
  inf.readSpace();
  inf.readInt(0, 9);
  inf.readEoln();
  inf.readEof();
  return 0;
}

