#include <stdio.h>

long long N, K, A;
int M, T;
FILE *fo;
char s[16];

int
main (void)
{
  while (scanf ("%d%lld%lld%lld%d", &M, &N, &K, &A, &T) == 5)
    {
      M += 2;
      sprintf (s, "%02d", M);
      fo = fopen (s, "wt");
      if (fo == NULL) continue;
      fprintf (fo, "%lld %lld\n", N, K);
      fclose (fo);
    }
  return 0;
}
