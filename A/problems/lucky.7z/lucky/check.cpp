#include <testlib.h>

long long howmany( long long n, long long k, long long d) {
  long long res = 0;
  while (n % d == k && n > 0) {
    res++;
    n /= d;
  }
  return res;
}

int main( int argc, char **argv) {
  setName("checker for ru.roi.2008.lucky (written 2010-08-06 by burunduk3)");
  registerTestlibCmd(argc, argv);

  long long n = inf.readLong();
  long long k = inf.readInt();
  long long d1 = ans.readLong();
  long long d2 = ouf.readLong();
  int ja = ans.readInt();
  int ca = ouf.readInt();

  long long p = (long long)1e12;

  if (d2 < 2 or d2 > p)
    quit(_wa, "Неверное основание системы счисления");

  long long ans1 = howmany(n, k, d1);
  long long ans2 = howmany(n, k, d2);

  if (ans1 != ja)
    quit(_fail, "Количество цифр в ответе жюри неверное");
  if (ans2 != ca)
    quitf(_wa, "В числе %lld в системе счисления %lld цифр %lld на конце не %d, а %lld", n, d2, k, ca, ans2);
  if (ans1 > ans2)
    quit(_wa, "Существует d с лучшим результатом");
  if (ans1 < ans2)
    quit(_fail, "Решение участника лучше решения жюри");
  quitf(_ok, "n = %lld, k = %lld, d = %lld", n, k, d2);
}

