#include <stdio.h>
#include <stdlib.h>
#include <math.h>

FILE *fi, *fo;
long long ans, best, m;
long long n, k, l;

void
try_and_push (long long d)
{
  if (d < 2) return ;
  m = 0;
  l = n;
  while (n > 0)
    {
      if (n % d == k) m++;
      n /= d;
    }
  n = l;
  if (m > best)
    {
      best = m;
      ans = d;
    }
}

void
solve_eq (long long a, long long b, long long c)
{
  long double d  = (long double) b * b - (long double) 4.0 * a * c;
  long double x1 = ( - (long double)b + sqrt (d)) / (2.0 * a) + 0.1;
  long double x2 = ( - (long double)b - sqrt (d)) / (2.0 * a) + 0.1;
  if (a == 0)
    {
      try_and_push (- c / b);
      return ;
    }
  try_and_push ((long long)x1);
  try_and_push ((long long)x2);
}

int
main (void)
{
  long long sqrt3n;
  long long i;
  fi = fopen ("lucky.in", "rt");
  fo = fopen ("lucky.out", "wt");

  fscanf (fi, "%I64d%I64d", &n, &k);

  try_and_push (n - k);
  try_and_push (n + 1);
  sqrt3n = pow (n, 1.0/3.0) + 1.0;
  for (i = 2; i <= sqrt3n; i++)
    try_and_push (i);
  for (i = 0; i <= sqrt3n; i++)
    solve_eq (i, k, k - n);

  fprintf (fo, "%I64d %d\n", ans, best);

  fclose (fi);
  fclose (fo);
  return 0;
}
