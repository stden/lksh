#include <iostream>

using namespace std;

int ans;
long long ans_base;

void check(long long n, long long base, long long k) {
    int res = 0;
    while (n > 0 && n % base == k) {
        ++res;
        n /= base;
    }
    if (res > ans) {
        ans = res;
        ans_base = base;
    }
}

int main() {

    freopen("lucky.in", "rt", stdin);
    freopen("lucky.out", "wt", stdout);

    long long n, k;
    cin >> n >> k;

    if (k > n) {
        printf("2 0\n");
        return 0;
    }

    if (k == n) {
        cout << n + 1 << " " << 1 << endl;
        return 0;
    }

    long long n2 = n - k;

    ans = 0;
    ans_base = 2;

    for (long long i = 2; i <= n2 / i && i < n2; ++i) {
        if (n2 % i != 0) continue;
        
        if (i > k) check(n, i, k); 
        if (n2 / i > k) check(n, n2 / i, k); 
    }

    check(n, n, k);

    cout << ans_base << " " << ans << endl;

    return 0;
}