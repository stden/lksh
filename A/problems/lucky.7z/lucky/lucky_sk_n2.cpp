#include <cstdio>
#include <cmath>

typedef long long ll;

ll n, resd;
int k, res;

void Try( int d )
{
  if (d <= 1)
    return;

  int cnt = 0;
  ll nn = n;
  while (nn % d == k)
    nn /= d, cnt++;
  if (cnt > res)
    res = cnt, resd = d;
}

int main()
{
  freopen("lucky.in", "r", stdin);
  freopen("lucky.out", "w", stdout);

  while (scanf("%I64d%d", &n, &k) == 2 && (n || k))
  {
    if (n <= k)
    {
      Try(n + 1);
      printf("%I64d %d\n", n + 1, res);
      continue;
    }

    res = 0, resd = n + 1;
    Try(n - k);
    int md = (int)(sqrt((double)n) + 0.5);
    for (int d = 2; d <= md; d++)
      if (n % d == 0)
        Try(d);
    if (k)
      Try(n / k - 1);
    printf("%I64d %d\n", resd, res);
  }
  return 0;
}
