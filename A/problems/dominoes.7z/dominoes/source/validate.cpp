#include <testlib.h>

const int maxn = 100;
const int maxa = 1000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxn);
  inf.readSpace();
  inf.readInt(-maxa, maxa);
  inf.readSpace();
  inf.readInt(-maxa, maxa);
  inf.readEoln();
  char temp[100];
  sprintf(temp, "[.*]{%d}", m);
  for (int i = 0; i < n; i++) {
    inf.readToken(temp);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

