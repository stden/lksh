#include <cstdio>
#include <cstdlib>

int s[100010];

void gen( int len, int cnt )
{
  printf("%d\n", len * cnt);
  
  for (int i = 0; i < len; i++)
    s[i] = rand() % 101;
  for (int j = 0; j < cnt; j++)
    for (int i = 0; i < len; i++)
      printf("%d ", s[i]);
  printf("\n");
}

int main( void )
{
  freopen("tests", "w", stdout);
  
  gen(50, 100);
  gen(25000, 2);
  gen(2, 25000);
  gen(100, 50);
  printf("0\n");
  return 0;
}