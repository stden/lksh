#include <cstdio>

int k = 0;

void split()
{
  int n;
  while (scanf("%d", &n) == 1 && n)
  {
    char buf[99];
    sprintf(buf, "%03d", ++k);

    FILE *F = fopen(buf, "wt");
    fprintf(F, "%d\n", n);
    while (n--)
    {
      int x;
      scanf("%d", &x);
      fprintf(F, "%d%c", x, "\n "[n > 0]);
    }
    fprintf(F, "0\n");
    fclose(F);
  }
}

int main()
{

  freopen("tests.hand", "r", stdin);
  split();
  freopen("tests", "r", stdin);
  split();
  return 0;
}
