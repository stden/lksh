#!/bin/sh

echo "compile..."
echo "stupid suffix “.exe” added for compatibility with outdated operation systems."
g++ -O2 -Wall split.cpp -o split.exe || exit 1
g++ -O2 -Wall gen.cpp -o gen.exe || exit 1

echo "generate tests..."
./gen.exe
./split.exe

rm tests || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ??? ../tests/

