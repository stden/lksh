#include <algorithm>
#include <cstdio>
#include <cstring>
#include <set>
#include <map>
#include <vector>

using namespace std;

#define maxn 200000

int s[maxn];
long long h[maxn], p[maxn], x = 103, n;
int a[maxn];

void init( int *s, long long *h, int n )
{
  h[0] = 0;
  h[1] = s[0];
  for (int i = 1; i < n; i++)
    h[i + 1] = h[i] * x + s[i];
    
}

long long getH( int l, int r )
{
  return h[r + 1] - h[l] * p[r - l + 1];
}

int lcp( int i, int j )
{
  int l = 0, r = n + 1;
  while (l + 1 < r)
{
    int c = (l + r) / 2;
    if (getH(i, i + c - 1) == getH(j, j + c - 1))
      l = c;
    else
      r = c;
}
  return l;
}

bool cmp( int i, int j )
{
  
  int t = lcp(i, j);
  if (t == n)
{
    return i < j;
}
  return s[i + t] < s[j + t];
}

int main( void )
{
  freopen("towers.in", "r", stdin);
  freopen("towers.out", "w", stdout);
  p[0] = 1;
  for (int i = 1; i < maxn; i++)
    p[i] = p[i - 1] * x;
  
  scanf("%d", &n);
  for (int i = 0; i < n; i++)
    scanf("%d", &s[i]);
  for (int i = 0; i < n; i++)
    s[i + n] = s[i];
  
  init(s, h, 2 * n);
    
  for (int i = 0; i < n; i++)
    a[i] = i;
  sort(a, a + n, cmp);
  long long res = 0;
  for (int i = 0; i + 1 < n; i++)
    res += lcp(a[i], a[i + 1]);
  printf("%lld\n", res);
 return 0;
}

