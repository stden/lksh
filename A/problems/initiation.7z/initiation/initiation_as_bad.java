import java.io.*;
import java.util.*;

public class initiation_as_bad {

    public void run() throws IOException {
        Scanner in = new Scanner(new File("initiation.in"));
        int n = in.nextInt();
        int m = in.nextInt();
        int r = in.nextInt();
        ArrayList<Edge>[] edges = new ArrayList[n];
        ArrayList<Edge>[] redges = new ArrayList[m];
        for (int i = 0; i < n; i++) {
            edges[i] = new ArrayList<Edge>();
        }
        for (int i = 0; i < m; i++) {
            redges[i] = new ArrayList<Edge>();
        }
        int[] dga = new int[n];
        int[] dgb = new int[m];
        int totalCost = 0;
        for (int i = 0; i < r; i++) {
            int a = in.nextInt() - 1;
            int b = in.nextInt() - 1;
            int c = in.nextInt();
            dga[a]++;
            dgb[b]++;
            Edge e = new Edge(i + 1, a, b, 1, c, 0);
            edges[a].add(e);
            redges[b].add(e);
            totalCost += c;
        }
        in.close();

        Graph g = new Graph(n + m + 2);
        for (int i = 0; i < n; i++) {
            g.addEdge(0, 0, i + 1, 1, 0);
        }
        for (int i = 0; i < m; i++) {
            g.addEdge(0, i + n + 1, n + m + 1, 1, 0);
        }
        for (int i = 0; i < n; i++) {
            for (Edge e: edges[i]) {
                g.addEdge(e.i, e.s + 1, n + e.d + 1, 1, e.p);
            }
        }

        int cost = g.minCostFlow(0, m + n + 1);

        boolean[] buy = new boolean[r];
        boolean[] sa = new boolean[n];
        boolean[] sb = new boolean[m];
        int nbuy = 0;
        for (int i = 1; i < n + 1; i++) {
            for (Edge e: g.edges[i]) {
                if (e.i != 0 && e.f == 1) {
                    buy[e.i - 1] = true;
                    sa[e.s - 1] = true;
                    sb[e.d - n - 1] = true;
                    nbuy++;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            if (!sa[i]) {
                int min = Integer.MAX_VALUE;
                int minei = -1;
                for (Edge e: edges[i]) {
                    if (e.p < min) {
                        min = e.p;
                        minei = e.i - 1;
                    }
                }
                buy[minei] = true;
                cost += min;
                nbuy++;
            }
        }
        for (int i = 0; i < m; i++) {
            if (!sb[i]) {
                int min = Integer.MAX_VALUE;
                int minei = -1;
                for (Edge e: redges[i]) {
                    if (e.p < min) {
                        min = e.p;
                        minei = e.i - 1;
                    }
                }
                buy[minei] = true;
                cost += min;
                nbuy++;
            }
        }

        PrintWriter out = new PrintWriter(new File("initiation.out"));
        out.println(cost);
        out.println(nbuy);
        for (int i = 0; i < r; i++) {
            if (buy[i]) {
                out.print(i + 1);
                out.print(" ");
            }
        }
        out.println();
        out.close();
    }

    public class Graph {
        int n;
        List<Edge>[] edges;

        public Graph(int n) {
            this.n = n;
            edges = new List[n];
            for (int i = 0; i < n; i++) {
                edges[i] = new ArrayList<Edge>();
            }
        }

        public void addEdge(int i, int s, int d, int c, int p) {
            Edge ef = new Edge(i, s, d, c, p, 0);
            Edge er = new Edge(0, d, s, 0, -p, 0);
            ef.r = er;
            er.r = ef;
            edges[s].add(ef);
            edges[d].add(er);
        }

        int minCostFlow(int s, int t) {
            int[] d = new int[n];
            boolean[] u = new boolean[n];

            // Run Bellman-Ford algorithm
            d[s] = 0;
            u[s] = true;
            boolean changed = true;
            while (changed) {
                changed = false;
                for (int i = 0; i < n; i++) {
                    if (u[i]) {
                        for (Edge e: edges[i]) {
                            if (e.c > 0 && (!u[e.d] || d[e.d] > d[i] + e.p)) {
                                u[e.d] = true;
                                d[e.d] = d[i] + e.p;
                                changed = true;
                            }
                        }
                    }
                }
            }

            // Potentials
            int[] q = new int[n];
            for (int i = 0; i < n; i++) {
                q[i] = d[i];
            }

            int curFlow = 0;
            int cost = 0;

            boolean[] v = new boolean[n];
            int[] c = new int[n];
            Edge[] from = new Edge[n];
            while (u[t]) {
                Arrays.fill(u, false);
                Arrays.fill(v, false);
                Arrays.fill(c, 0);

                // Run Dijkstra
                d[s] = 0;
                v[s] = true;
                c[s] = Integer.MAX_VALUE;

                while (!u[t]) {
                    int k = -1;
                    for (int j = 0; j < n; j++) {
                        if (!u[j] && v[j] && (k == -1 || d[j] < d[k])) {
                            k = j;
                        }
                    }
                    if (k == -1) {
                        break;
                    }

                    u[k] = true;
                    for (Edge e: edges[k]) {
                        if (e.c > e.f) {
                            if (!v[e.d] || d[e.d] > d[k] + e.p + q[e.s] - q[e.d]) {
                                v[e.d] = true;
                                d[e.d] = d[k] + e.p + q[e.s] - q[e.d];
                                c[e.d] = Math.min(c[k], e.c - e.f);
                                from[e.d] = e;
                            }
                        }
                    }
                }

                if (!u[t]) {
                    break;
                }

                for (int i = 0; i < n; i++) {
                    if (!u[i]) {
                        d[i] = d[t];
                    }
                }

                curFlow += c[t];
                cost += (q[t] + d[t]) * c[t];

                int k = t;
                while (k != s) {
                    Edge e = from[k];
                    e.f += c[t];
                    e.r.f -= c[t];
                    k = e.s;
                }

                for (int i = 0; i < n; i++) {
                    q[i] += d[i];
                }
            }

            return cost;
        }
    }

    public class Edge {
        int s;
        int d;
        int c;
        int p;
        int f;
        int i;
        Edge r;

        public Edge(int i, int s, int d, int c, int p, int f) {
            this.i = i;
            this.s = s;
            this.d = d;
            this.c = c;
            this.p = p;
            this.f = f;
        }
    }


    public static void main(String[] arg) throws IOException {
        new inititation_as_bad().run();
    }
}
