#include <testlib.h>

const int maxn = 100;
const int maxm = 1000;
const int maxw = 1000;

int main() {
  registerValidation();
  int n1 = inf.readInt(1, maxn);
  inf.readSpace();
  int n2 = inf.readInt(1, maxn);
  inf.readEoln();
  int m = inf.readInt(1, maxm);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    inf.readInt(1, n1);
    inf.readSpace();
    inf.readInt(1, n2);
    inf.readSpace();
    inf.readInt(1, maxw);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

