#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <algorithm>
#include <utility>
#include <vector>

unsigned long long lcgseed;

unsigned lcgRand( int l, int r ) {
  lcgseed = lcgseed * 239017 + 301703;
  unsigned n = r - l + 1;
  return l + (lcgseed >> 16) % n;
}

long double lcgRand() {
  static const unsigned max = (1 << 30);
  return lcgRand(0, max) * 1.0 / max;
}

int main( int argc, char *argv[] ) {
  using namespace std;
  assert(argc == 5);
  int n = atoi(argv[1]);
  long double pm = atof(argv[2]);
  int climit = atoi(argv[3]);
  lcgseed = atoi(argv[4]) * 17239;

  int c[n][n];
  memset(c, 0, sizeof(c));
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++) {
      if (i == j || lcgRand() > pm)
        continue;
      c[i][j] = lcgRand(1, climit);
    }

  vector <pair<pair<int, int>, int> > edges;
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      if (c[i][j] != 0)
        edges.push_back(make_pair(make_pair(i + 1, j + 1), c[i][j]));
  for (int i = 0; i < (int)edges.size(); i++)
    swap(edges[i], edges[lcgRand(0, i)]);

  printf("%d %d\n", n, (int)edges.size());
  for (int i = 0; i < (int)edges.size(); i++)
    printf("%d %d %d\n", edges[i].first.first, edges[i].first.second, edges[i].second);
  
  return 0;
}

