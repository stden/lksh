#!/bin/bash

TEST=0

function next_test() {
  TEST=$(($TEST + 1))
  $1 > "../tests/$(printf '%02d' $TEST)" || exit 1
}

rm -rf ../tests/
mkdir ../tests/

for i in *.manual; do
  next_test "cat $i"
done

g++ -O2 -Wall -o gen_random{,.cpp} || exit 1

next_test "./gen_random 3 0.5 5 301703"
next_test "./gen_random 10 1.0 100 17239"
for ((i = 0; i < 20; i++)); do
  next_test "./gen_random 10 0.7 100 $TEST"
done

