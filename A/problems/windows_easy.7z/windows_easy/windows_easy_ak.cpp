#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
#include <vector>

#define MAXN 524288
#define MAXC 200000
#define INFINITy 1000000000

struct tseg{
	int miny, maxy, d,x;
	tseg(){}
	tseg(int p, int q, int b, int a){
		miny = p;
		maxy = q;
		d = b;
		x = a;
	}
	friend bool operator <(const tseg &a, const tseg &b){
		if (a.x!=b.x) return a.x<b.x;
		if (a.d!=b.d) return a.d>b.d;
		return false;
	}
};    

int max(int a, int b){
	return (a>b?a:b);
}

struct window{
	int x1,y1,x2,y2;
};

struct tree{
	int a[MAXN*2+2];
	int d[MAXN*2+2];
	tree(){
		for (int i = 0; i < MAXN*2+2; i++){a[i]=0;d[i]=0;}
	}
	void add(int l, int r, int D, int v, int nL, int nR){                              
		if ((nR<l)||(nL>r)) return;
		if ((nL>=l)&&(nR<=r)){
			d[v] += D;
			return;
		}
		d[v*2+1] += d[v];
		d[v*2+2] += d[v];
		d[v] = 0;
		add(l,r,D,v*2+1,nL,((nL+nR)>>1));
		add(l,r,D,v*2+2,((nL+nR)>>1)+1,nR);
		a[v] = max(a[v*2+1]+d[v*2+1],a[v*2+2]+d[v*2+2]);
	}
	pair<int,int> getmax(){
		int v = 0;
		int l = 0;
		int r = MAXC*2+1;
		while (l!=r){
			d[v*2+1] += d[v];
			d[v*2+2] += d[v];
			d[v] = 0;
			a[v] = max(a[v*2+1]+d[v*2+1],a[v*2+2]+d[v*2+2]);
			if (a[v*2+1]+d[v*2+1]>a[v*2+2]+d[v*2+2]){
				v = v*2+1;
				r = (l+r)>>1;
			}else{
				v = v*2+2;
				l = ((l+r)>>1)+1;
			}
		}
		a[v] += d[v];
		d[v] = 0;                
		return make_pair(a[v],l);
	}
};


vector<tseg> v;
tree t;
window w[50000];
int n;

int main(){
	freopen("windows.in", "rt", stdin);
	freopen("windows.out", "wt", stdout);
	scanf("%d", &n);
	for (int i = 0; i < n; i++){
		int x1,y1,x2,y2;
		scanf("%d%d%d%d", &x1,&y1,&x2,&y2);
		w[i].x1=x1;w[i].x2=x2;w[i].y1=y1;w[i].y2=y2;
		x1 += MAXC; y1 += MAXC; x2 += MAXC; y2 += MAXC;
		v.push_back(tseg(y1,y2,1,x1));
		v.push_back(tseg(y1,y2,-1,x2));
	}
	sort(v.begin(),v.end());
	int omax = 0;
	int _x = 0;
	int _y = 0;
	for (int i = 0; i < n*2; i++){
		t.add(v[i].miny, v[i].maxy, v[i].d, 0, 0, MAXC*2+1);
		pair<int, int> tmp = t.getmax();
		if (tmp.first>omax){
			omax = tmp.first;
			_x = v[i].x;
			_y = tmp.second;
		}
	}
	printf("%d\n%d %d", omax, _x-MAXC, _y-MAXC);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
