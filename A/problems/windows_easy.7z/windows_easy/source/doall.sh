#!/bin/sh

./wipe.sh

echo "stupid suffix “.exe” added for compatibility with outdated operation system"
echo "compile..."
g++ -O2 -Wall -o gen.exe gen.cpp || exit 1
g++ -O2 -Wall -o windows_ak.exe ../windows_easy_ak.cpp || exit 1

echo "copy hand-tests..."
for i in `seq -w 01 04`; do
  cp $i.hand $i || exit 1
done

echo -n "generate tests..."
echo "301703" > rand
for i in `seq -w 05 40`; do
  echo -n "[$i]"
  rand=`cat rand`
  ./gen.exe 100 100 $rand 2> rand > $i || exit 1
done
rm --force rand || exit 1
echo ""

echo -n "generate answers..."
for i in `seq -w 01 40`; do
  echo -n "[$i]"
  cp $i "windows.in" || exit 1
  ./windows_ak.exe || exit 1
  cp windows.out $i.a || exit 1
done
echo ""
rm --force windows.{in,out}

rm -rf ../tests/
mkdir ../tests/
mv ??{,.a} ../tests/

