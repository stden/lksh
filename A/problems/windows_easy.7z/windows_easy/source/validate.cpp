#include <testlib.h>

const int maxn = 100;
const int maxc = 200000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readEoln();
  for (int i = 0; i < n; i++) {
    int x1 = inf.readInt(-maxc, maxc);
    inf.readSpace();
    int y1 = inf.readInt(-maxc, maxc);
    inf.readSpace();
    inf.readInt(x1, maxc);
    inf.readSpace();
    inf.readInt(y1, maxc);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

