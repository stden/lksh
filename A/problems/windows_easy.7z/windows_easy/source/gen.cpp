
#include <cstdio>

#include <algorithm>

using std::swap;

int main( int argc, char *argv[] )
{
  srand(atoi(argv[3]));
  int n = rand() % (atoi(argv[1])) + 1;
  int m = atoi(argv[2]);
  printf("%d\n", n);
  for (int i = 0; i < n; i++)
  {
    int x1 = rand() % (2 * m + 1) - m;
    int x2 = rand() % (2 * m + 1) - m;
    int y1 = rand() % (2 * m + 1) - m;
    int y2 = rand() % (2 * m + 1) - m;
    if (x1 > x2)
      swap(x1, x2);
    if (y1 > y2)
      swap(y1, y2);
    if (x1 == x2 || y1 == y2)
    {
      i--;
      continue;
    }
    printf("%d %d %d %d\n", x1, y1, x2, y2);
  }
  fprintf(stderr, "%d\n", rand());
  return 0;
}

