#!/bin/bash

g++ -O2 -Wall gen.cpp -o gen

for i in *.hand; do
  cp "$i" "${i%.hand}"
done

./gen 239    3 30    3 > 02
./gen 17239  4 100   100 > 03

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

