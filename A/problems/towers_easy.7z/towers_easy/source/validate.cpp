#include <testlib.h>

const int maxn = 100;
const int maxk = 200;
const int maxa = 100;

int main() {
  registerValidation();
  int t = 0;
  while (true) {
    int n = inf.readInt(0, maxn);
    inf.readEoln();
    if (n == 0)
      break;
    ensuref(++t <= maxk, "слишком много тестов");
    for (int i = 0; i < n; i++) {
      inf.readInt(0, maxa);
      if (i == n - 1)
        inf.readEoln();
      else
        inf.readSpace();
    }
  }
  inf.readEof();
  return 0;
}

