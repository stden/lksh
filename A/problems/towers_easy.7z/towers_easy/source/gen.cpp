#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include "random.h"

using namespace std;


int main(int argc, char *argv[])
{
	int rn = atoi(argv[1]), k = atoi(argv[2]), maxn = atoi(argv[3]), maxval = atoi(argv[4]);
	initrand(rn);
	for (int i = 0; i < k; ++i)
	{
		int n = R(1, maxn);
		cout << n << endl;
		for (int j = 0; j < n; ++j)	
			cout << (rand()&maxval) << ("\n "[j < n - 1]);
        } 
        cout << 0 << endl;

	return 0;
}
