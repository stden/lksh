#include <iostream>
#include <sstream>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <memory>
#include <cctype>
#include <string>
#include <vector>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <algorithm>
using namespace std;

typedef long long Int;
typedef long double Double;
typedef vector<int> VInt;
typedef vector< vector<int> > VVInt;

#define FOR(i, n, m) for(i = n; i < m; i++)
#define CLEAR(x, y) memset(x, y, sizeof(x))
#define PB push_back
#define MP make_pair

#define min(x, y) (x < y ? x : y)

#define MAX 50000

struct Node
{
	int from;
	int len;
	int res;
	int has;
};

Node C[MAX];

int A[MAX];
int Pos[MAX], Len[MAX], Group[MAX], InvPos[MAX];
int CPos[MAX], CLen[MAX], CGroup[MAX], CInvPos[MAX];
int RPos[MAX], RLen[MAX], RGroup[MAX], RInvPos[MAX];

int N;
int *L, *Gr;
int Offset;

void F(int n)
{
	int i, j, k;
	int max = 0;
	FOR(i, 0, n)
		if(max < C[i].len)
			max = C[i].len;

	memcpy(A, L, sizeof(A));

	for(k = 1; ;k <<= 1)
	{
		for(j = 0; j < n; j++)
		{
			if(C[j].len & k)
			{
				C[j].res = min(C[j].res, A[C[j].has]);
				C[j].has += k;
			}
		}

		
		if((k << 1) > max)
			break;

		int* p = A, *pp = A + k;
		for(j = 0; j < N - (k << 1); j++, p++, pp++)
			*p = min(*p, *pp);
	}
}

void Merge(int* Pos1, int* InvPos1, int* Len1, int* Group1, int offset1, int* Pos2, int* InvPos2, int* Len2, int* Group2, int offset2)
{
	int i, j, k;
	FOR(i, 0, N)
	{
		j = Pos2[i] - offset1;
		if(j < 0)
			j += N;

		j = InvPos1[j];

		k = j + Group1[j];
		Group1[k]++;
		k += Group1[k] - 1;

		if(k != j)
		{
			int temp = Pos1[k];
			Pos1[k] = Pos1[j];
			Pos1[j] = temp;

			InvPos1[ Pos1[j] ] = j;
			InvPos1[ Pos1[k] ] = k;
		}
	}

	i = 0;
	int count = 0;
	while(i < N)
	{
		int jj = Pos1[i] + offset1;
		if(jj >= N)
			jj -= N;

		jj = InvPos2[jj];

		int kk;

		FOR(j, i, i + Group1[i] - 1)
		{
			kk = Pos1[j + 1] + offset1;
			if(kk >= N)
				kk -= N;

			kk = InvPos2[kk];

			int t = kk + Group2[kk] - jj;
			if(t <= 0)
				Len1[j] += offset2;
			else
			{
				C[count].from = jj;
				C[count].len = t;
				C[count].has = jj;
				C[count].res = offset2;
				count++;

				if(count > MAX)
					throw 0;
			}

			jj = kk;
		}

		i += Group1[i];
	}

	L = Len2;
	Gr = Group2;
	Offset = offset2;

	F(count);

	FOR(i, 0, count)
	{
		j = Pos2[ C[i].from ] - offset1;
		if(j < 0)
			j += N;

		j = InvPos1[j];

		Len1[j] += C[i].res;
	}

	i = 0;
	while(i < N)
	{
		Group1[i] = 0;
		j = i;
		while(j < N - 1 && Len1[j] == offset1 + offset2)
		{
			Group1[j + 1] = i - j - 1;
			j++;
		}

		i = j + 1;
	}
}

int Cmp(int i, int j){ return A[i] < A[j]; }

Int Solve()
{
	int i, j;
	FOR(i, 0, N)
		Pos[i] = i;

	sort(Pos, Pos + N, Cmp);

	FOR(i, 0, N)
		InvPos[ Pos[i] ] = i;

	FOR(i, 0, N - 1)
		Len[i] = A[ Pos[i] ] == A[ Pos[i + 1] ] ? 1 : 0;
	
	i = 0;
	while(i < N)
	{
		Group[i] = 0;
		j = i;
		while(j < N - 1 && Len[j] == 1)
		{
			Group[j + 1] = i - j - 1;
			j++;
		}

		i = j + 1;
	}

	FOR(i, 0, N)
	{
		RLen[i] = 0;
		RPos[i] = RInvPos[i] = i;
		RGroup[i] = -i;
	}

	int ROffset = 0;
	for(i = 1; i <= N; i <<= 1)
	{
		if(N & i)
		{
			Merge(RPos, RInvPos, RLen, RGroup, ROffset, Pos, InvPos, Len, Group, i);
			ROffset += i;
		}

		memcpy(CPos, Pos, sizeof(Pos));
		memcpy(CLen, Len, sizeof(Len));
		memcpy(CGroup, Group, sizeof(Group));
		memcpy(CInvPos, InvPos, sizeof(InvPos));

		Merge(Pos, InvPos, Len, Group, i, CPos, CInvPos, CLen, CGroup, i);
	}
	
	Int res = 0;
	FOR(i, 0, N - 1)
		res += RLen[i];

	return res;
}

int main()
{
        freopen("towers.in", "r", stdin);
        freopen("towers.out", "w", stdout);

	while (scanf("%d", &N) == 1 && N)
	{
		assert(1 <= N <= (int)1e5);

		int i;
		FOR(i, 0, N)
		{
			scanf("%d", &A[i]);
			assert(0 <= A[i] && A[i] <= 100);
		}
		cout << Solve() << endl;
	}

	return 0;
}
