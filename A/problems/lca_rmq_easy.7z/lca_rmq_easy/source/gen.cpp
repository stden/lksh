#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

long long Time()
{
  asm("rdtsc");
}

unsigned int R( unsigned int A, unsigned int B )
{
  return A + (((unsigned)rand() << 15) + (unsigned)rand()) % (B - A + 1);
}

#define maxn 100010

int p[maxn], pr[maxn], p2[maxn];

int main( int argc, char *argv[] )
{
  int seed = atoi(argv[1]), n = atoi(argv[2]), m = atoi(argv[3]), c = atoi(argv[4]);

  // seed - base for random (0 means Time())
  // n - number of vertices
  // m - number of queries
  // c - {x, y, z} will be in range [0..c]

  srand(seed ? seed : Time());
  printf("%d %d\n", n, m);
  forn(i, n)
    p[i] = i, pr[i] = i ? (rand() % i) : -1;
  random_shuffle(p + 1, p + n);
  forn(i, n)
    p2[p[i]] = i;
  for (int i = 1; i < n; i++)
    printf("%d%c", p2[pr[p[i]]], i == n - 1 ? '\n' : ' ');

  printf("%d %d\n%d %d %d\n", R(0, n - 1), R(0, n - 1), R(0, c), R(0, c), R(0, c));
  return 0;
}

