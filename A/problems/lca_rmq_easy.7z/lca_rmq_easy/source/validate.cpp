#include <testlib.h>

const int maxn = 100;
const int maxm = 100;
const int maxx = 1000000000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readSpace();
  inf.readInt(1, maxm);
  inf.readEoln();
  int a[n], c[n];
  for (int i = 1; i < n; i++) {
    a[i] = inf.readInt(0, n - 1);
    if (i == n - 1)
      inf.readEoln();
    else
      inf.readSpace();
  }
  memset(c, 0, sizeof(c));
  c[0] = 2;
  for (int i = 1; i < n; i++) {
    if (c[i] == 2)
      continue;
    int x = i;
    while (c[x] == 0)
      c[x] = 1, x = a[x];
    ensuref(c[x] == 2, "что-то не похоже на дерево");
    x = i;
    while (c[x] != 2)
      c[x] = 2, x = a[x];
  }
  inf.readInt(0, n - 1);
  inf.readSpace();
  inf.readInt(0, n - 1);
  inf.readEoln();
  inf.readInt(0, maxx);
  inf.readSpace();
  inf.readInt(0, maxx);
  inf.readSpace();
  inf.readInt(0, maxx);
  inf.readEoln();
  inf.readEof();
  return 0;
}

