#!/bin/sh

echo "compile.."
echo "stupid suffix “.exe” added for compatibility with outdated operation systems"
g++ -O2 -Wall -o gen.exe gen.cpp || exit 1

cp 01.hand 01
cp 02.hand 02

echo "generate tests..."
./gen.exe 1000001 10  100 100 > 03
./gen.exe 1000002 50  70  100 > 04
./gen.exe 1000003 80  80  100 > 05
./gen.exe 1000004 60  20  100 > 06
./gen.exe 1000005 50  97  100 > 07
./gen.exe 1000006 29  31  100 > 08
./gen.exe 1000007 99  99  100 > 09
./gen.exe 1000008 100 100 100 > 10

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

