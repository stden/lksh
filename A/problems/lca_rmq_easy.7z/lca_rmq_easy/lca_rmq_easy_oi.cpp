#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <ctime>


using namespace std;

const int maxn = 202;

long long aa[maxn], p[maxn], n, m, a[maxn][maxn];

int main()
{
	freopen("lca_rmq.in", "r", stdin);
	freopen("lca_rmq.out", "w", stdout);

	cin >> n >> m;
	for (int i = 1; i < n; ++i)
		cin >> p[i];
	
	memset(a, 0, sizeof(a));
	p[0] = -1;
	for (int i = 0; i < n; ++i)
	{
		int cur = i;
		while (cur >= 0)
		{
			a[cur][i] = 1;
			cur = p[cur];
		}
	}
	
	long long x, y, z;
	cin >> aa[1] >> aa[2] >> x >> y >> z;

	for (int i = 3; i <= 2*m; ++i)
		aa[i] = (x*aa[i-2] + y*aa[i-1] + z) % n;
	
	long long ans = 0;
	
	int v1 = aa[1], v2 = aa[2];
	for (int i = 1; i <= m; ++i)	
	{
		int cur = v1;
		while (!a[cur][v2])
			cur = p[cur]; 
		ans += cur;
		v2 = aa[2*(i+1)];
		v1 = (aa[2*(i+1)-1]+cur) % n;
	}
	
	cout << ans << endl;
	
	return 0;
} 

