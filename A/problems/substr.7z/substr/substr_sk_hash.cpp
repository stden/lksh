#include <cstdio>
#include <cstring>

#define forn(i, n) for (int i = 0; i < n; i++)

typedef unsigned long long ull;

const int mlen = 20000;
const int maxh = 30011;
const int P = (int)1e9 + 7;

char s[mlen + 1];
ull pow[mlen + 1];
int n, ans = 0;

int cc = 0, hu[maxh + 30];
ull ha[maxh + 30];

void Add( ull h )
{
  int i = h % maxh;
  while (hu[i] == cc && ha[i] != h)
    i++;
  if (hu[i] != cc)
    ans++, hu[i] = cc, ha[i] = h;
}

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  forn(i, n)
    s[i] = s[i] - 'a' + 1;

  pow[0] = 1;
  forn(j, n)
    pow[j + 1] = pow[j] * P;

  for (int len = 1; len <= n; len++)
  {
    ++cc;

    ull h = 0;
    forn(j, len)
      h = h * P + s[j];
    forn(i, n - len + 1)
    {
      Add(h);
      h = h * P + s[i + len] - s[i] * pow[len];
    }
  }
  printf("%d\n", ans);
  return 0;
}
