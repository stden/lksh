#include <cassert>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <set>
#include <string>
#include <iostream>

using namespace std;

#define maxn 40010

char s[maxn] = "abacaba";
 
int ne[maxn][27], suff[maxn], len[maxn], mn, st, en, end[maxn], strN;

int p[maxn], ec[maxn], ei[maxn], nev[maxn][27], nel[maxn][27], ner[maxn][27], tmn, was[maxn], el[maxn][27], er[maxn][27], ev[maxn][27];

void addC( int c )
{
  int v = en; en = mn++;
  len[en] = len[v] + 1;

  while (!ne[v][c])
    ne[v][c] = en, v = suff[v];

  int z = ne[v][c];
  suff[en] = z == en ? 0 : z;
  if (z == en) return;
  if (len[z] == len[v] + 1) return;
  int nz = mn++;
  for (int i = 0; i < 27; i++) ne[nz][i] = ne[z][i];

  suff[nz] = suff[z], suff[z] = nz, suff[en] = nz;
  len[nz] = len[v] + 1;

  while (ne[v][c] == z)
    ne[v][c] = nz, v = suff[v];
}

void buildSuffAv( char * s )
{
  int n = strlen(s);
  memset(ne, 0, sizeof(ne));
  mn = 1;
  st = 0, en = 0;

  for (int i = 0; i < n; i++)
   addC(s[i] - 'a');

  strN = n;
}

void dfs1( int v )
{
  was[v] = 1;
  if (end[v])
    ei[v] = 0;
  for (int i = 0, u; i < 27; i++)
    if (u = ne[v][i])
    {
      p[v]++;
      ec[v] = i;
      if (!was[u])
        dfs1(u);

      ei[v]    = ei[u] + 1;
      el[v][i] = ei[u] + 1;
      er[v][i] = p[u] == 1 ? er[u][ec[u]] : ei[u];
      ev[v][i] = p[u] == 1 ? ev[u][ec[u]] : u;
    }
}

void buildTree( int v, int tv = 0)
{
  for (int i = 0; i < 27; i++) 
    if (ne[v][i])
    {
      nel[tv][i] = el[v][i];
      ner[tv][i] = er[v][i];
      nev[tv][i] = tmn++;
      buildTree(ev[v][i], tmn - 1);
    }
}

long long res = 0;
void dfst( int v, int d = 0 )
{
  
  for (int i = 0; i < 27; i++)
    if (nev[v][i])
    {
      dfst(nev[v][i], d + nel[v][i] - ner[v][i]);
      res += (long long)(nel[v][i] - ner[v][i]);
    }
}

int main( void )
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  scanf("%s", s);            

  int sn = strlen(s);
  buildSuffAv(s);

// begin 

  int v = en;
  while (v)
    end[v] = 1, v = suff[v];

  memset(was, 0, sizeof(int) * mn);
  dfs1(st); // calc p, ec, ei, edges

  tmn = 1;
  buildTree(st);

// end

  dfst(0);
  cout << res;

  return 0;
}