#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

const int mlen = 20001;
const int M = 27;

char s[2 * mlen];
int n, mem[2][mlen], *p = mem[0], *p2 = mem[1];
int cnt[M], pos[M];

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  forn(i, n)
    s[i] = s[i] - 'a' + 1;
  n++;
  memcpy(s + n, s, n);
  forn(i, n)
    p[i] = i;

  memset(cnt, 0, sizeof(cnt));
  forn(j, n)
    cnt[(int)s[j]]++;

  for (int i = n - 1; i >= 0; i--)
  {
    pos[0] = 0;
    forn(j, M - 1)
      pos[j + 1] = pos[j] + cnt[j];
    forn(j, n)
      p2[pos[(int)s[p[j] + i]]++] = p[j];
    swap(p, p2);
  }

  int ans = n - p[0];
  forn(i, n - 1)
  {
    int k = 0;
    char *s1 = s + p[i], *s2 = s + p[i + 1];
    while (*s1++ == *s2++)
      k++;
    ans += n - p[i + 1] - k;  
  }
  printf("%d\n", ans - n);
  return 0;
}
