#include <cstdio>
#include <cstring>

#include <algorithm>
#include <vector>

using namespace std;

typedef unsigned long long ull;

#define maxlen 20010
#define P 239017

char str[maxlen];
ull pp[maxlen];

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  pp[0] = 1;
  for (int i = 1; i < maxlen; i++)
    pp[i] = pp[i - 1] * P;

  fgets(str, maxlen - 1, stdin);
  int n = strlen(str);
  str[--n] = '\0';

  int ans = 0;
  for (int len = 1; len <= n; len++)
  {
    ull hash = 0, power = pp[len];
    for (int i = 0; i < len; i++)
      hash = hash * P + str[i];
    vector <ull> hashes;
    for (int st = 0; st + len <= n; st++)
    {
      hashes.push_back(hash);
      hash = hash * P - str[st] * power + str[st + len];
    }
    sort(hashes.begin(), hashes.end());
    for (int i = 0; i < (int)hashes.size(); i++)
      if (i == 0 || hashes[i] != hashes[i - 1])
        ans++;
  }
  printf("%d\n", ans);

  return 0;
}

