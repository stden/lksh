#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

const int mlen = 20000;

char s[mlen + 1];
int n, p[mlen];

bool pless( int i, int j )
{
  return strcmp(s + i, s + j) < 0;
}

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  forn(i, n)
    p[i] = i;
  sort(p, p + n, pless);

  int ans = n - p[0];
  forn(i, n - 1)
  {
    int k = 0;
    while (s[p[i] + k] == s[p[i + 1] + k])
      k++;
    ans += n - p[i + 1] - k;  
  }
  printf("%d\n", ans);
  return 0;
}
