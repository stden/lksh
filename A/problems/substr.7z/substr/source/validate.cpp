#include <testlib.h>

//const int maxl = 20000;

int main() {
  registerValidation();
  inf.readToken("[a-z]{1,20000}");
  inf.readEoln();
  inf.readEof();
  return 0;
}

