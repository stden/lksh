#!/bin/sh

# Suffix “.exe” for binary files added for comaptibility with old operation systems.
echo "compile.."
g++ -O2 -Wall -o split.exe split.cpp || exit 1
g++ -O2 -Wall -o gen.exe gen.cpp || exit 1

echo "generate tests..."
./gen.exe > tests.gen || exit 1

echo "split tests..."
./split.exe tests.hand tests.gen || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/
rm tests.gen

