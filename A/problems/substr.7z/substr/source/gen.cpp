#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <string>
#include "random.h"

using namespace std;

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

void outputTest( string test )
{
  printf("%s\n\n", test.c_str());
}

string randomTest( int length, int limit )
{
  string s = "";
  for (int i = 0; i < length; i++)
    s += 'a' + R(0, limit - 1);
  return s;
}

string randomTest2( int length, long double prob )
{
  string s = "";
  for (int i = 0; i < length; i++)
    s += 'a' + (rndDouble() < prob);
  return s;
}

string abacabaTest( int length )
{
  string res = "";
  char ch = 'a';
  while ((int)res.length() < length)
    res = res + (ch++) + res;
  return res.substr(0, length);
}

string cyclicTest( int t, int n, int tail )
{
  string period, ans;
  forn(i, t)
    period += 'a' + i;
  forn(i, n)
    ans += period;
  forn(i, tail)
    ans += R('a', 'b');
  return ans;
}

string p4Test( string s, int limit )
{
  string g = s;
  for (int i = 0; i < 3; i++)
    g[R(0, g.length() - 1)] = 'a' + R(0, limit - 1);
  return s + g;
}

void testPack( int length )
{
  outputTest(randomTest(length, 2));
  outputTest(randomTest2(length, 0.89));
  outputTest(randomTest2(length, 0.00));
  outputTest(randomTest(length, 26));
  outputTest(abacabaTest(length));
  length = min(length, 10000);
  outputTest(p4Test(randomTest(length, 2), 2));
  outputTest(p4Test(randomTest2(length, 0.93), 2));
  outputTest(p4Test(randomTest2(length, 0.77), 26));
  outputTest(p4Test(randomTest2(length, 0.00), 16));
  outputTest(p4Test(randomTest(length, 2), 26));
  outputTest(p4Test(randomTest(length, 26), 26));
  outputTest(p4Test(abacabaTest(length), 26));
}

int main()
{
  initrand(301703);

  for (int length = 5; length <= 20000; length = (int)(length * 7.3))
    testPack(length);
  testPack(20000);

  outputTest(cyclicTest(1, 20000, 0));
  outputTest(cyclicTest(1, 19990, 10));
  outputTest(cyclicTest(2, 10000, 0));
  outputTest(cyclicTest(2, 9990, 20));
  outputTest(cyclicTest(10, 2000, 0));
  outputTest(cyclicTest(10, 1999, 10));
  
  return 0;
}

