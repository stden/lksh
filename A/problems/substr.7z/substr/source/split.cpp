/*
 *  split.cpp written by burunduk3 (Oleg Davydov)
 *  38-223 (2008-08-11) 21:27 UTC
 *  It splits all files given by command line parameter into tests using blank lines as test separators.
 *  Block of blank lines is processed with following: all but last lines are appened to previous test.
 *  Remember: line consist of only space characters is NOT a blank line!
 *  tests: 01 02 03 etc
 */

#include <cstdio>
#include <cstdlib>

int counter = 1;

FILE* openNextOutput()
{
  char fileName[200];
  sprintf(fileName, "%02d", counter++);
  FILE *file = fopen(fileName, "wt");
  if (file == NULL)
  {
    perror(fileName);
    return NULL;
  }
  return file;
}

void splitFile( char *fileName )
{
  FILE *input = fopen(fileName, "rt");
  FILE *output = NULL;
  if (input == NULL)
    return perror(fileName);
  int c;
  bool startLine = true, endTest = false;
  while ((c = fgetc(input)) != -1)
  {
    if (c != '\n')
    {
      if (endTest && output != NULL)
        fclose(output), output = NULL, endTest = false;
      if (output == NULL && (output = openNextOutput()) == NULL)
        return;
      fputc(c, output);
      startLine = false;
    }
    else if (startLine)
    {
      if (endTest)
        fputc(c, output);
      endTest = true;
    }
    else
    {
      fputc(c, output);
      startLine = true;
    }
  }
  if (output != NULL)
    fclose(output);
  fclose(input);
}

int main( int argc, char *argv[] )
{
  for (int i = 1; i < argc; i++)
    splitFile(argv[i]);
  return 0;
}
