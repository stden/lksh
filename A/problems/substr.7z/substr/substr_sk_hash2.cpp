#include <cstdio>
#include <cstring>

#define forn(i, n) for (int i = 0; i < n; i++)

typedef unsigned ull;

const int mlen = 20000;
const int maxh = 30011;
const int P1 = 103;
const int P2 = 239;

char s[mlen + 1];
ull pow1[mlen + 1];
ull pow2[mlen + 1];
int n, ans = 0;

int cc = 0, hu[maxh + 30];
ull ha1[maxh + 30];
ull ha2[maxh + 30];

void Add( ull h1, ull h2 )
{
  int i = h1 % maxh;
  while (hu[i] == cc && (ha1[i] != h1 || ha2[i] != h2))
    i++;
  if (hu[i] != cc)
    ans++, hu[i] = cc, ha1[i] = h1, ha2[i] = h2;
}

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  forn(i, n)
    s[i] = s[i] - 'a' + 1;

  pow1[0] = 1;
  forn(j, n)
    pow1[j + 1] = pow1[j] * P1;

  pow2[0] = 1;
  forn(j, n)
    pow2[j + 1] = pow2[j] * P2; 

  ull fi1 = 0, fi2 = 0;
  for (int len = 1; len <= n; len++)
  {
    ++cc;

    ull h1 = fi1 = fi1 * P1 + s[len - 1];
    ull h2 = fi2 = fi2 * P2 + s[len - 1];

    forn(i, n - len + 1)
    {
      Add(h1, h2);
      h1 = h1 * P1 + s[i + len] - s[i] * pow1[len];
      h2 = h2 * P2 + s[i + len] - s[i] * pow2[len];
    }
  }
  printf("%d\n", ans);
  return 0;
}
