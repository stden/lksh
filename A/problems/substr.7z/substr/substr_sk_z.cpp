#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

const int mlen = 20000;

char s[mlen + 1];
int n, ans = 0, z[mlen];

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  forn(st, n)
  {
    int l = 0, r = 0, tn = n - st, ma = 0;
    char *t = s + st;

    z[0] = 0;
    for (int i = 1; i < tn; i++)
    {
      int k = (r > i ? min(r - i, z[i - l]) : 0);
      while (t[i + k] == t[k])
        k++;
      z[i] = k;
      ma = max(ma, k);
      if (i + k > r)
        l = i, r = i + k;
    }
    ans += tn - ma;
  }
  printf("%d\n", ans);
  return 0;
}
