#include <cstdio>
#include <cstring>

#include <algorithm>
#include <vector>

using namespace std;

typedef unsigned long long ull;

#define maxlen 20010
#define P 239017

char str[maxlen];

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  fgets(str, maxlen - 1, stdin);
  int n = strlen(str);
  str[--n] = '\0';

  vector <ull> hashes;
  for (int i = 0; i < n; i++)
  {
    ull hash = 0;
    for (int j = i; j < n; j++)
    {
      hash = hash * P + str[j];
      hashes.push_back(hash);
    }
  }
  sort(hashes.begin(), hashes.end());

  int cnt = 0;
  for (int i = 0; i < (int)hashes.size(); i++)
    if (i == 0 || hashes[i] != hashes[i - 1])
      cnt++;
  printf("%d\n", cnt);

  return 0;
}

