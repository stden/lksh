#include <cstdio>
#include <cstring>
#include <cassert>

#define forn(i, n) for (int i = 0; i < n; i++)

const int mlen = 20000;
const int maxv = 2 * mlen;

struct edge
{
  int to, l, r;

  edge() {}
  edge( int _to, int _l, int _r ) : to(_to), l(_l), r(_r) { }
};

char s[mlen + 1];
edge next[maxv][26];
int n, vn = 1, ans = 0;

void add( int l, int r )
{
  int v = 0;

  while (l < r)
  {
    edge &e = next[v][(int)s[l]];
    if (e.to == 0)
    {
      e = edge(vn++, l, r);
      ans += r - l;
      return;
    }
    else
    {
      int i = e.l;
      while (l < r && i < e.r && s[l] == s[i])
        l++, i++;
      if (l == r)
        return;
      if (i == e.r)
        v = e.to;
      else
      {
        int cur = vn++;
        next[cur][(int)s[i]] = edge(e.to, i, e.r);
        next[cur][(int)s[l]] = edge(vn++, l, r);
        ans += r - l;
        e.r = i;
        e.to = cur;
        return;
      }
    }
  }
}

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  assert(1 <= n && n <= mlen);
  forn(i, n)
    assert('a' <= s[i] && s[i] <= 'z');
  
  forn(i, n)
    s[i] -= 'a';
  forn(i, n)
    add(i, n);
  printf("%d\n", ans);
  return 0;
}
