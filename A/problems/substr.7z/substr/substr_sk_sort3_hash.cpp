#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

typedef unsigned long long ull;

const int mlen = 20001;
const int P = 23917;

char s[mlen + 1];
int n, p[mlen], p2[mlen];
ull h[mlen], pow[mlen];

bool pless( int i, int j )
{
  if (i == j)
    return 0;

  int l = 0, r = min(n - i, n - j);
  ull C = h[i] - h[j];
  while (l < r)
  {
    int m = (l + r + 1) >> 1;
    if (h[i + m] - h[j + m] == C * pow[m])
      l = m;
    else
      r = m - 1;
  }
  return s[i + l] < s[j + l];
}

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  forn(i, n)
    p[i] = i;
  h[0] = 0;
  pow[0] = 1;
  forn(i, n)
  {
    pow[i + 1] = pow[i] * P;
    h[i + 1] = h[i] * P + s[i];
  }
  
  sort(p, p + n, pless);
  forn(i, n)
    p2[p[i]] = i;

  int ans = n * (n + 1) / 2, k = 0;
  for (int i = n; i >= 1; i--)
  {
    if (k > 0)
      k--;
    int x = p2[n - i];
    if (x != n - 1)
      while (s[p[x] + k] == s[p[x + 1] + k])
        k++;
    ans -= k;
  }
  printf("%d\n", ans);
  return 0;
}
