#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

const int mlen = 20001;
const int P1 = 1003;
const int P2 = 17239;

char s[mlen + 1];
int n, p[mlen], p2[mlen];
int h1[mlen], pow1[mlen];
int h2[mlen], pow2[mlen];

bool pless( int i, int j )
{
  if (i == j)
    return 0;

  int l = 0, r = min(n - i, n - j);
  int C1 = h1[i] - h1[j];
  int C2 = h2[i] - h2[j];
  while (l < r)
  {
    int m = (l + r + 1) >> 1;
    if (h1[i + m] - h1[j + m] == C1 * pow1[m] &&
        h2[i + m] - h2[j + m] == C2 * pow2[m])
      l = m;
    else
      r = m - 1;
  }
  return s[i + l] < s[j + l];
}

void MSort( int l, int r )
{
  if (r <= l + 1)
    return;

  int m = (l + r) / 2;
  MSort(l, m);
  MSort(m, r);

  int i = l, j = m, k = l;
  while (i < m && j < r)
    if (pless(p[i], p[j]))
      p2[k++] = p[i++];
    else
      p2[k++] = p[j++];
  while (i < m)
    p2[k++] = p[i++];
  while (j < r)
    p2[k++] = p[j++];

  for (int k = l; k < r; k++)
    p[k] = p2[k];
}

int main()
{
  freopen("substr.in", "r", stdin);
  freopen("substr.out", "w", stdout);

  gets(s);
  n = strlen(s);
  forn(i, n)
    p[i] = i;
  h1[0] = h2[0] = 0;
  pow1[0] = pow2[0] = 1;
  forn(i, n)
  {
    pow1[i + 1] = pow1[i] * P1;
    pow2[i + 1] = pow2[i] * P2;
    h1[i + 1] = h1[i] * P1 + s[i];
    h2[i + 1] = h2[i] * P2 + s[i];
  }
  
  MSort(0, n);
  forn(i, n)
    p2[p[i]] = i;

  int ans = n * (n + 1) / 2, k = 0;
  for (int i = n; i >= 1; i--)
  {
    if (k > 0)
      k--;
    int x = p2[n - i];
    if (x != n - 1)
      while (s[p[x] + k] == s[p[x + 1] + k])
        k++;
    ans -= k;
  }
  printf("%d\n", ans);
  return 0;
}
