#include <iostream>
#include "random.h"

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)

char ans[1000][1000];

int main(int argc, char** argv) {
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);
  int k = atoi(argv[3]);
  initrand(atoi(argv[4]));
  forn (i, n) {
    forn (j, m) {
      ans[i][j] = rndvalue(26) + 'a';
    }
  }
  forn (i, k) {
    int x1 = rndvalue(n - 1);
    int y1 = rndvalue(m - 1);
    int x2 = x1 + rndvalue(n - x1);
    int y2 = y1 + rndvalue(m - y1);

    for (int p = 0; p < x2 - x1; ++p)
      for (int q = 0; q < y2 - y1; ++q) {
        ans[x1 + p][y2 - q] = ans[x1 + p][y1 + q];
        ans[x2 - p][y2 - q] = ans[x1 + p][y1 + q];
        ans[x2 - p][x1 + q] = ans[x1 + p][y1 + q];  
      }
  }
  printf("%d %d\n", n, m);
  forn (i, n) {
    forn (j, m) printf("%c", ans[i][j]);
    printf("\n");
  }  
  return 0;
}