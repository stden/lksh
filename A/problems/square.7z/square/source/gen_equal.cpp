#include <iostream>
#include "random.h"

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)

int main(int argc, char** argv) {
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);
  int k = atoi(argv[3]);
  initrand(atoi(argv[4]));
  printf("%d %d\n", n, m);
  forn (i, n) {
    forn (j, m) {
      if (nextrand() % 100 <= 90) 
        printf("%c", 'a');
      else
        printf("%c", rndvalue(k) + 'a');
    }
    printf("\n");
  }
    
  return 0;
}