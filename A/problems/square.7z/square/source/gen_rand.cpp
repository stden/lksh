#include <iostream>
#include "random.h"

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)

int main(int argc, char** argv) {
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);
  initrand(atoi(argv[3]));
  printf("%d %d\n", n, m);
  forn (i, n) {
    forn (j, m) printf("%c", rndvalue(2) + 'a');
    printf("\n");
  }
    
  return 0;
}