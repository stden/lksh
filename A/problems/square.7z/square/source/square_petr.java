import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class square_petr implements Runnable {
    public static void main(String[] args) {
        new Thread(new square_petr()).start();
    }

    class Hasher {
        long[][] rchash;

        Hasher(String[] board) {
            long[][] rhash = new long[h][w];
            for (int i = 0; i < h; ++i) {
                long hash = 0;
                for (int j = 0; j < w; ++j) {
                    hash = hash * phash[1] + (board[i].charAt(j) - 'a' + 1);
                    rhash[i][j] = hash;
                }
            }
            rchash = new long[h][w];
            for (int j = 0; j < w; ++j) {
                long hash = 0;
                for (int i = 0; i < h; ++i) {
                    hash = hash * phash[w] + rhash[i][j];
                    rchash[i][j] = hash;
                }
            }
        }

        long getHash(int r1, int c1, int r2, int c2) {
            return getOne(r2, c2)
                    - getOne(r1 - 1, c2) * phash[(r2 - r1 + 1) * w]
                    - getOne(r2, c1 - 1) * phash[(c2 - c1 + 1)]
                    + getOne(r1 - 1, c1 - 1) * phash[(r2 - r1 + 1) * w + c2 - c1 + 1];
        }

        private long getOne(int r, int c) {
            if (r < 0 || c < 0)
                return 0;
            else
                return rchash[r][c];
        }
    }

    long[] phash;
    int h;
    int w;

    public void run() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("square.in"));
            String[] parts = reader.readLine().split(" ", -1);
            if (parts.length != 2)
                throw new Exception();
            h = Integer.parseInt(parts[0]);
            w = Integer.parseInt(parts[1]);
            String[] board = new String[h];
            for (int i = 0; i < h; ++i) {
                board[i] = reader.readLine().trim();
            }
            phash = new long[(h + 1) * (w + 1) + 1];
            phash[0] = 1;
            for (int i = 1; i < phash.length; ++i)
                phash[i] = 3137 * phash[i - 1];
            Hasher plain = new Hasher(board);
            List<String> reversed = new ArrayList<String>(Arrays.asList(board));
            Collections.reverse(reversed);
            Hasher revByRow = new Hasher(reversed.toArray(new String[0]));
            String[] reversed2 = new String[h];
            for (int i = 0; i < h; ++i) {
                StringBuilder b = new StringBuilder(board[i]);
                b.reverse();
                reversed2[i] = b.toString();
            }
            Hasher revByCol = new Hasher(reversed2);

            int res = 0;
            int resr1 = 0;
            int resc1 = 0;
            int resr2 = 0;
            int resc2 = 0;

            for (int r1 = 0; r1 < h; ++r1)
                for (int c1 = 0; c1 < w; ++c1)
                    for (int r2 = r1; r2 <= r1 + 1 && r2 < h; ++r2)
                        for (int c2 = c1; c2 <= c1 + 1 && c2 < w; ++c2) {
                            if (r2 == r1 ^ c2 == c1)
                                continue;
                            int l = (res - (r2 - r1 + 1) + 10) / 2 - 5;
                            int r = Math.min(r1, Math.min(c1, Math.min(h - 1 - r2, w - 1 - c2))) + 1;
                            while (r - l > 1) {
                                int m = l + 1;
                                if (verifyPalindrome(h, w, r1 - m, c1 - m, r2 + m, c2 + m, plain, revByRow, revByCol))
                                    l = m;
                                else
                                    r = m;
                            }
                            if (r2 - r1 + 1 + 2 * l > res) {
                                res = r2 - r1 + 1 + 2 * l;
                                resr1 = r1 - l + 1;
                                resr2 = r2 + l + 1;
                                resc1 = c1 - l + 1;
                                resc2 = c2 + l + 1;
                            }
                        }

            PrintWriter writer = new PrintWriter("square.out");
            writer.println(resr1 + " " + resc1 + " " + resr2 + " " + resc2);
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private boolean verifyPalindrome(int h, int w, int r1, int c1, int r2, int c2, Hasher plain, Hasher revByRow, Hasher revByCol) {
        long h1 = plain.getHash(r1, c1, r2, c2);
        long h2 = revByRow.getHash(h - 1 - r2, c1, h - 1 - r1, c2);
        long h3 = revByCol.getHash(r1, w - 1 - c2, r2, w - 1 - c1);
        return (h1 == h2 && h1 == h3);
    }
}
