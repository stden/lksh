#include <testlib.h>

const int maxr = 700;

int main() {
  registerValidation();
  int h = inf.readInt(1, maxr);
  inf.readSpace();
  int w = inf.readInt(1, maxr);
  inf.readEoln();
  char temp[100];
  sprintf(temp, "[a-z]{1,%d}", w);
  for (int i = 0; i < h; i++) {
    inf.readToken(temp);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

