#!/bin/bash
cp 01.t 01
cp 02.t 02
cp 03.t 03
cp 04.t 04
cp 05.t 05
cp 06.t 06
cp 07.t 07
cp 08.t 08
cp 09.t 09
cp 10.t 10
for i in gen_{rand{,_pal{,2}},equal{,2}}.cpp; do
  g++ -O2 -Wall "$i" -o "${i%.cpp}"
done

./gen_rand 10 10 12312 > 11; echo -n '.'
./gen_rand 10 20 63512 > 12; echo -n '.'
./gen_rand 2 50 12476 > 13; echo -n '.'
./gen_rand 100 2 12345 > 14; echo -n '.'
./gen_rand 300 1 13452 > 15; echo -n '.'
./gen_rand 1 500 87612 > 16; echo -n '.'
./gen_rand 200 200 22212 > 17; echo -n '.'
./gen_rand 150 300 76332 > 18; echo -n '.'
./gen_rand 400 600 13445 > 19; echo -n '.'
./gen_rand 600 700 87612 > 20; echo -n '.'
./gen_rand 700 700 13452 > 21; echo -n '.'

./gen_equal 700 700 1 12452 > 21; echo -n '.'
./gen_equal 600 700 2 87542 > 22; echo -n '.'
./gen_equal 700 600 3 83443 > 23; echo -n '.'
./gen_equal 699 700 3 12265 > 24; echo -n '.'
./gen_equal 700 699 2 74552 > 25; echo -n '.'

./gen_equal2 700 700 1 12452 > 26; echo -n '.'
./gen_equal2 600 700 2 87542 > 27; echo -n '.'
./gen_equal2 700 600 3 83443 > 28; echo -n '.'
./gen_equal2 699 700 3 12265 > 29; echo -n '.'
./gen_equal2 700 699 2 74552 > 30; echo -n '.'

./gen_rand_pal 700 700 50 23746 > 31; echo -n '.'
./gen_rand_pal 700 700 10 23746 > 32; echo -n '.'
./gen_rand_pal 700 700 20 23746 > 33; echo -n '.'
./gen_rand_pal 700 700 30 23746 > 34; echo -n '.'
./gen_rand_pal 700 700 40 23746 > 35; echo -n '.'

./gen_rand_pal2 700 700 50 23746 > 36; echo -n '.'
./gen_rand_pal2 700 700 10 23746 > 37; echo -n '.'
./gen_rand_pal2 700 700 20 23746 > 38; echo -n '.'
./gen_rand_pal2 700 700 200 23746 > 39; echo -n '.'
./gen_rand_pal2 700 700 100 23746 > 40; echo -n '.'

echo

if [ ! -d ../tests ]; then
  mkdir ../tests
fi
mv ?? ../tests

