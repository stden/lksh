#include "testlib.h"
#include <string>
#include <vector>

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)

char data[1000][1000];

int main(int argc, char * argv[])
{
    registerTestlibCmd(argc, argv);

    int n = inf.readInt();
    int m = inf.readInt();

    forn (i, n)
      forn (j, m) {
        int c = inf.readChar();
        while (c <= ' ') c = inf.readChar();
        data[i][j] = c;
      }

    int x1 = ans.readInt();
    int y1 = ans.readInt();
    int x2 = ans.readInt();
    int y2 = ans.readInt();
    int juryAns = (x2 - x1 + 1) * (y2 - y1 + 1);

    x1 = ouf.readInt();
    y1 = ouf.readInt();
    x2 = ouf.readInt();
    y2 = ouf.readInt();

    if (x1 > x2) quitf(_wa, "First row is greater than the second row.");
    if (y1 > y2) quitf(_wa, "First column is greater than the second column.");
    int dx = x2 - x1 + 1;
    int dy = y2 - y1 + 1;
    if (dx != dy) quitf(_wa, "Output is not a square.");

    if (x1 < 1 || x1 > n) quitf(_wa, "First row is not in range [%d, %d].", 1, n);    
    if (y1 < 1 || y1 > m) quitf(_wa, "First column is not in range [%d, %d].", 1, m);    
    if (x2 < 1 || x2 > n) quitf(_wa, "Second row is not in range [%d, %d].", 1, n);    
    if (y2 < 1 || y2 > m) quitf(_wa, "Second column is not in range [%d, %d].", 1, m);    

    int userAns = dx * dy; 

    if (userAns < juryAns) quitf(_wa, "Jury has better palindrome square %d vs %d.", juryAns, userAns);

    bool pal = true;

    --x1; --y1; --x2; --y2;

    forn (i, dx)
      forn (j, dy) {
        pal &= (data[x1 + i][y1 + j] == data[x1 + i][y2 - j]);
        pal &= (data[x1 + i][y1 + j] == data[x2 - i][y1 + j]);
        pal &= (data[x1 + i][y1 + j] == data[x2 - i][y2 - j]);
      }
    if (!pal) quitf(_wa, "Output is not a palindrome.");
    if (userAns > juryAns) quitf(_fail, "Participant has better palindrome square %d vs %d.", userAns, juryAns);
    quitf(_ok, "Square: %d", userAns);
}
