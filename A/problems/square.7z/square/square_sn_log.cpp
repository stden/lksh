#include <cstdio>
#include <cstring>
#include <iostream>
#include <cassert>

using namespace std;

#define NMAX 700

#define BASE1 19
#define BASE2 23

#define forn(i, n) for (int i = 0; i < int(n); ++i)

typedef int ht[NMAX + 5][NMAX + 5];

int n, m;

char buf[NMAX + 5][NMAX + 5];
int h1[NMAX + 5][NMAX + 5];
int h2[NMAX + 5][NMAX + 5];
int h3[NMAX + 5][NMAX + 5];

int st1[2 * NMAX], st2[2 * NMAX];

int get_h(int x1, int y1, int x2, int y2, ht& h) {
  return h[x2][y2] - h[x2][y1 - 1] - h[x1 - 1][y2] + h[x1 - 1][y1 - 1];
}

bool is_palin(int x1, int y1, int x2, int y2) {
  int r1 = get_h(x1, y1, x2, y2, h1);
  int r2 = get_h(n - x2 + 1, y1, n - x1 + 1, y2, h2);   
  int r3 = get_h(x1, m - y2 + 1, x2, m - y1 + 1, h3);
  int max_x = max(x1, n - x2 + 1);
  int max_y = max(y1, m - y2 + 1);
  r1 *= st1[max_x - x1] * st2[max_y - y1];
  r2 *= st1[max_x - (n - x2 + 1)] * st2[max_y - y1];
  r3 *= st1[max_x - x1] * st2[max_y - (m - y2 + 1)];
  return (r1 == r2) && (r2 == r3);
}

int main() {

  freopen("square.in", "rt", stdin);
  freopen("square.out", "wt", stdout);

  scanf("%d %d", &n, &m);
  assert(1 <= n && n <= NMAX);
  assert(1 <= m && m <= NMAX);

  st1[0] = 1;
  st2[0] = 1;
  forn (i, n + m) if (i > 0) st1[i] = st1[i - 1] * BASE1;
  forn (i, n + m) if (i > 0) st2[i] = st2[i - 1] * BASE2;

  forn (i, n)
    forn (j, m) {
      int c = getchar();
      while (c <= ' ') c = getchar();
      buf[i][j] = char(c - 'a');
    }

  memset(h1, 0, sizeof(h1));
  memset(h2, 0, sizeof(h2));
  memset(h3, 0, sizeof(h3));

  forn (i, n + 1) if (i > 0) {
    int c = 0;
    forn(j, m + 1) if (j > 0) {
      c += buf[i - 1][j - 1] * st1[i] * st2[j];
      h1[i][j] = h1[i - 1][j] + c;
    }
  }
  forn (i, n + 1) if (i > 0) {
    int c = 0;
    forn(j, m + 1) if (j > 0) {
      c += buf[n - i][j - 1] * st1[i] * st2[j];
      h2[i][j] = h2[i - 1][j] + c;
    }
  }
  forn (i, n + 1) if (i > 0) {
    int c = 0;
    forn(j, m + 1) if (j > 0) {
      c += buf[i - 1][m - j] * st1[i] * st2[j];
      h3[i][j] = h3[i - 1][j] + c;
    }
  }

       
  int ans = 0;
  int rx1, ry1, rx2, ry2;

  for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= m; ++j) {
      int l = 1, r = min(i, n - i + 1);
      r = min(r, min(j, m - j + 1));
      while (l < r) {
        int mid = (l + r + 1) >> 1;
        int x1 = i - mid + 1;
        int y1 = j - mid + 1;
        int x2 = i + mid - 1;
        int y2 = j + mid - 1;
        if (is_palin(x1, y1, x2, y2))
          l = mid;
        else
          r = mid - 1;
      }
      int x1 = i - l + 1;
      int y1 = j - l + 1;
      int x2 = i + l - 1;
      int y2 = j + l - 1;
      int sz = (x2 - x1 + 1) * (y2 - y1 + 1);
      if (sz > ans) {
        ans = sz;
        rx1 = x1; ry1 = y1;
        rx2 = x2; ry2 = y2;
      }

      l = 0, r = min(i - 1, n - i + 1);
      r = min(r, min(j - 1, m - j + 1));
      while (l < r) {
        int mid = (l + r + 1) >> 1;
        int x1 = i - mid;
        int y1 = j - mid;
        int x2 = i + mid - 1;
        int y2 = j + mid - 1;
        if (is_palin(x1, y1, x2, y2))
          l = mid;
        else
          r = mid - 1;
      }
      if (r == 0) continue;
      x1 = i - l;
      y1 = j - l;
      x2 = i + l - 1;
      y2 = j + l - 1;
      sz = int(x2 - x1 + 1) * (y2 - y1 + 1);
      if (sz > ans) {
        ans = sz;
        rx1 = x1; ry1 = y1;
        rx2 = x2; ry2 = y2;
      }
   }
   printf("%d %d %d %d\n", rx1, ry1, rx2, ry2);
   return 0;
}
