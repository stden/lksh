#!/bin/sh

echo "unzip tests..."
7z x tests.7z || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

