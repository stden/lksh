#include <cstdio>

const int SIZE_LIMIT = 4000;

int main() {
  int ch, size = 0;
  while ((ch = fgetc(stdin)) != -1) {
    if (!((32 <= ch && ch <= 126) || ch == 10 || ch == 13))
      return 1 + printf("bad character (code %d)\n", ch) * 0;
    if (++size > SIZE_LIMIT)
      return 1 + puts("input too big");
  }
  return 0;
}

