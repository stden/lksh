import java.util.*;
import java.io.*;

class kina_gk {
    static class Abbr implements Comparable<Abbr> {
        final String word;
        final int effect;

        Abbr(String word, int effect) {
            this.word = word;
            this.effect = effect;
        }

        public int compareTo(Abbr that) {
            return this.effect - that.effect;
        }
    }

    Queue<Abbr> abbrs = new PriorityQueue<Abbr>();
    int count;

    static class Node {
        final Node[] next = new Node[26];
        String word;

        Node next(char ch) {
            int index = ch - 'a';
            if (next[index] == null) {
                next[index] = new Node();
            }
            return next[index];
        }
    }

    Node next(Node node, int index) {
        if (node == null) {
            return null;
        }
        return node.next[index];
    }

    Node root = new Node();

    static class Chunk {
        final List<String> words;
        int pos = 0;
        int hash = 0;
        int length = 0;
        int start;

        Chunk(int start, List<String> words) {
            this.words = words;
            this.start = start;
            int hash = 0;
        }

        char advance() {
            String word = pos < words.size() ? words.get(pos) : "____";
            pos++;
            length += word.length();
            hash = hash * 31 + word.hashCode();
            return word.charAt(0);
        }

        List<String> getWitness() {
            return words.subList(0, pos);
        }
    }

    class Basket {
        final List<Chunk> chunks = new ArrayList<Chunk>();
        final Node node;

        public Basket(Node node) {
            this.node = node;
        }
    }

    List<Basket> next;

    void processChunks(Basket chunks) {        
        if (chunks.chunks.size() < 2) {
            return;
        }

        Chunk first = chunks.chunks.get(0);
        boolean sameHash = true;
        int count = 0;
        int last = Integer.MIN_VALUE;
        for (Chunk chunk : chunks.chunks) {
            sameHash &= first.hash == chunk.hash;
            if (last + first.pos <= chunk.start) {
                count++;
                last = chunk.start;
            }
        }
        if (sameHash && (chunks.node == null || chunks.node.word == null)) {
            int length = first.length;
            int value = count * length - (count * first.pos + length);
            if (value > 1200) {
                StringBuilder word = new StringBuilder();
                for (String w : first.getWitness()) {
                    word.append(w.charAt(0));
                }

                //System.out.println(value + " " + word + " " + first.getWitness());
                
                abbrs.add(new Abbr(word.toString(), value));
                while (abbrs.size() > this.count) {
                    Abbr abbr2 = abbrs.poll();
                    //System.out.println(abbr2.effect + " -> " + abbr2.word);
                }
            }
        }

        Basket[] baskets = new Basket[26];
        for (int i = 0; i < baskets.length; i++) {
            baskets[i] = new Basket(next(chunks.node, i));
        }

        for (Chunk chunk : chunks.chunks) {
            int basket = chunk.advance() - 'a';
            if (basket >= 0) {
                baskets[basket].chunks.add(chunk);
            }
        }

        for (Basket basket : baskets) {
            if (basket.chunks.size() >= 2) {
                next.add(basket);
            }
        }
    }

    List<String> run(List<String> words2, int count) {
        this.count = count;

        List<String> words = new ArrayList<String>();
        for (String word : words2) {
            words.add(word.toLowerCase());
        }

        for (String word : words) {
            Node node = root;
            for (char ch : word.toCharArray()) {
                node = node.next(ch);
            }
            node.word = word;
        }

        Basket chunks = new Basket(root);
        for (int i = 0; i < words.size(); i++) {
            chunks.chunks.add(new Chunk(i, words.subList(i, words.size())));
        }

        List<Basket> prev = new ArrayList<Basket>();
        prev.add(chunks);

        while (!prev.isEmpty()) {
            next = new ArrayList<Basket>();
            for (Basket basket : prev) {
                processChunks(basket);
            }
            prev = next;
        }

        List<Abbr> abbrs = new ArrayList<Abbr>(this.abbrs);
        Collections.sort(abbrs);
        Collections.reverse(abbrs);
        
        List<String> result = new ArrayList<String>();
        for (Abbr abbr : abbrs) {
            result.add(abbr.word);               
            System.out.println(abbr.effect + " " + abbr.word);
        }
        return result;
    }
}

public class TestGenerator {
    static final int MAX_L = 3998;

    static final int APPENDIX = 20;
    static final String LETTERS = "ABCDEFGHIJLKMNOPQRSTUVWXYZabcdefghijlkmnopqrstuvwxyz";
    static final String PUNCTUATION;
    static {
        StringBuilder sb = new StringBuilder();
        for (char ch = ' '; ch < 127; ch++) {
            if (LETTERS.indexOf(ch) < 0) {
                sb.append(ch);
            }
        }
        PUNCTUATION = sb.toString();
        //PUNCTUATION = " ";
    }

    static long seed = 8433164542775380748L;
    Random random = new Random(++seed);

   

    int gauss(int mean, int number) {
        float sum = 0;
        for (int i = 0; i < number; i++) {
            sum += random.nextFloat();
        }
        return Math.round(sum * 2 * mean / number);
    }

    String word(int length, String letters) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(letters.charAt(random.nextInt(letters.length())));
        }
        return sb.toString();
    }

    String word(int length) {
        return word(length, LETTERS);
    }

    String gaussWord(int length, int average) {
        return word(gauss(length, average));
    }

    List<String> gaussWords(int number, int length, int average) {
        List<String> words = new ArrayList<String>(number);
        for (int i = 0; i < number; i++) {
            words.add(gaussWord(length, average));
        }
        return words;
    }

    List<String> text(int length, List<String> words) {
        List<String> text = new ArrayList<String>();
        int textLength = -1;
        int i = 0;
        while (textLength != length && i++ <= 100000) {
            String word = words.get(random.nextInt(words.size()));
            if (textLength + 1 + word.length() <= length) {
                text.add(word);
                textLength += 1 + word.length();
            }
        }
        return text;
    }

    List<String> smartText(double coeff, int length, List<String> words) {
        Map<String, List<String>> lists = new HashMap<String, List<String>>();
        for (String word : words) {
            List<String> list = new ArrayList<String>(words);
            Collections.shuffle(list, random);
            list.remove(word);
            list.add(word);
            lists.put(word, list);
        }

        List<String> text = new ArrayList<String>();
        int textLength = -1;
        String prevWord = words.get(0);
        int i = 0;
        while (textLength != length && i++ <= 100000) {
            String word = lists.get(prevWord).get(0);
            int j = 0;
            for (String w : lists.get(word)) {
                j++;
                if (random.nextFloat() > coeff) {
                    word = w;
                    //System.out.println(j);
                    break;
                }
            }
            if (textLength + 1 + word.length() <= length) {
                prevWord = word;
                text.add(word);
                textLength += 1 + word.length();
            }
        }
        return text;
    }

    int textLength(List<String> text) {
        int length = -1;
        for (String word : text) {
            length += 1 + word.length();
        }
        return length;
    }

    String punctuation(int length, List<String> text, String punctuation) {
        length -= textLength(text);
        assert (length >= 0);

        int[] spaces = new int[text.size() + 1];
        Arrays.fill(spaces, 1);
        spaces[0] = 0;
        spaces[text.size()] = 0;
        for (int i = 0; i < length; i++) {
            spaces[random.nextInt(spaces.length)]++;
        }

        StringBuilder sb = new StringBuilder();
        int index = 0;
        for (String word : text) {
            sb.append(word(spaces[index++], punctuation));
            sb.append(word);
        }
        sb.append(word(spaces[index++], punctuation));

        return sb.toString();
    }

    String punctuation(int length, List<String> text) {
        return punctuation(length, text, PUNCTUATION);
    }

    String simple(int textLength, int letterLength, int words, int wordLength, int average) {
        List<String> text = text(letterLength, gaussWords(words, wordLength, average));
        return punctuation(textLength, text);
    }

    String smart(double coeff, int textLength, int letterLength, int wordsCount, int wordLength, int average, int featuresCount) {        
        List<String> text;
        List<String> features;
        do {
            List<String> words = gaussWords(wordsCount, wordLength, average);
            text = smartText(coeff, letterLength, words);
            features = new kina_gk().run(text, featuresCount);
        } while (features.size() <= 10);

        features.remove(features.size() - 1);
        int length = textLength(text);
        for (String fiature : features) {
            if (length + 1 + fiature.length() < textLength) {
                text.add(fiature);
                length += 1 + fiature.length();
            }
        }
        //System.out.println(punctuation(textLength, text));
        System.out.println("!!!" + features);
        return punctuation(textLength, text);
    }

    String chunks(double coeff, int textLength, int letterLength, int chunksCount, int chunkLength, int wordsCount, int wordLength, int average) {
        List<String> words = gaussWords(wordsCount, wordLength, average);
        List<String> chunks = new ArrayList<String>();
        for (int i = 0; i < chunksCount; i++) {
            String chunk = punctuation(chunkLength, smartText(coeff, chunkLength, words), " ");
            chunks.add(chunk);
            System.out.println(chunk);
        }

        List<String> text = text(letterLength, chunks);

        return punctuation(textLength, text);
    }

    static void write(int test, String text) throws IOException {
        assert (text.length() <= MAX_L);
        System.out.format("--------------- %02d ---------------\n\n", test, text);
        PrintWriter out = new PrintWriter(String.format("../tests/%02d", test));
        out.println(text);
        out.close();
    }

    static String appendix() {
        return new TestGenerator().chunks(0.5, APPENDIX, APPENDIX, 1, 6, 2, 2, 1000);
    }

    public static void main(String[] args) throws IOException {
        int test = 21;
        for (int ZL : new int[]{2000, MAX_L}) {
            // 10 medium chunks, small words
            write(++test, new TestGenerator().chunks(0.5, ZL, ZL * 39 / 100, 10, 98, 1000, 3, 6));
            // 3 x One big chunk, small words
            write(++test, new TestGenerator().chunks(0.5, ZL, ZL * 49 / 100, 1, ZL / 3 - 10, 1000, 3, 6));
            // 10 medium chunks, medium words
            write(++test, new TestGenerator().chunks(0.5, ZL, ZL * 59 / 100, 10, 98, 1000, 20, 2));
            // 3 x One big chunk, medium words
            write(++test, new TestGenerator().chunks(0.5, ZL, ZL * 69 / 100, 1, ZL / 3 - 10, 1000, 20, 2));
            // 10 medium chunks, big words
            write(++test, new TestGenerator().chunks(0.5, ZL, ZL * 89 / 100, 10, 98, 1000, 150, 2));
            // 3 x One big chunk, big words
            write(++test, new TestGenerator().chunks(0.5, ZL, ZL * 99 / 100, 1, ZL / 3 - 10, 1000, 170, 2));

            // Almost Markov's text, high correlation
            write(++test, new TestGenerator().smart(0.005, ZL, ZL * 90 / 100, 100, 5, 6, 100));
            // Almost Markov's text, low correlation
            write(++test, new TestGenerator().smart(0.01, ZL, ZL * 90 / 100, 20, 10, 6, 100));
            // Almost Markov's text, low correlation
            write(++test, new TestGenerator().smart(0.02, ZL, ZL * 99 / 100, 20, 10, 6, 100));

            // Max test with single-letter words
            write(++test, new TestGenerator().simple(ZL - APPENDIX - 1, ZL - APPENDIX - 1, 1, 1, 100000) + " " + appendix());
            // Max test with three-letter words
            write(++test, new TestGenerator().simple(ZL - APPENDIX - 1, ZL - APPENDIX - 1, 1, 3, 100000) + " " + appendix());
            // Max test with three-letter words
            write(++test, new TestGenerator().chunks(0.5, ZL - APPENDIX - 1, ZL - APPENDIX - 1, 20, ZL / 20, 1000, 3, 100000) + " " + appendix());

            // One big word
            write(++test, new TestGenerator().simple(ZL, ZL, 1, ZL - 50, 1000000));
            // Two same big words
            write(++test, new TestGenerator().simple(ZL, ZL, 1, ZL / 2 - 20, 100000));
            // Two different big words
            write(++test, new TestGenerator().simple(ZL, ZL, 2, ZL / 2 - 20, 100000));
        }
        //seed = 8433164542775380750L;
        // Almost Markov's text, low correlation
        //write(++test, new TestGenerator().smart(0.01, MAX_L, MAX_L * 50 / 100, 8, 4, 6, 100000));
    }
}

