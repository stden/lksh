import java.io.*;
import java.util.*;
import java.util.regex.*;

public class kina_gk_wa {
    static Scanner in;
    static PrintWriter out;

    static List<String> bestWitness;
    static int bestValue = 0;

    class Chunk {
        final List<String> words;
        int pos = 0;
        int hash = 0;
        int length = 0;
        int start;

        Chunk(int start, List<String> words) {
            this.words = words;
            this.start = start;
            int hash = 0;
        }

        char advance() {
            String word = pos < words.size() ? words.get(pos) : "____";
            pos++;
            length += word.length();
            hash = hash * 31 + word.hashCode();
            return word.charAt(0);
        }

        List<String> getWitness() {
            return words.subList(0, pos);
        }
    }

    int ops = 0;
    List<List<Chunk>> processChunks(List<Chunk> chunks) {        
        if (chunks.size() < 2) {
            return Collections.emptyList();
        }

        Chunk first = chunks.get(0);
        boolean sameHash = true;
        int count = 0;
        int last = Integer.MIN_VALUE;
        for (Chunk chunk : chunks) {
            ops++;
            sameHash &= first.hash == chunk.hash;
            if (last + first.pos < chunk.start) {
                count++;
                last = chunk.start;
            }
        }
        if (sameHash) {
            //int count = chunks.size();
            int length = first.length;
            int value = count * length - (count * first.pos + length);
            if (bestValue < value) {
                bestValue = value;
                bestWitness = first.getWitness();
            }
            
            //System.out.println(first.getWitness() + " # " + count + " " + value + " ! " + length);
        }

        @SuppressWarnings("unchecked")
        List<Chunk>[] baskets = new List[26];
        for (int i = 0; i < baskets.length; i++) {
            baskets[i] = new ArrayList<Chunk>();
        }

        for (Chunk chunk : chunks) {
            int basket = chunk.advance() - 'a';
            if (basket >= 0) {
                baskets[basket].add(chunk);
            }
        }

        return Arrays.asList(baskets);
    }

    void run() {
        in.useDelimiter("[^a-zA-Z]");
        List<String> words = new ArrayList<String>();
        while (in.hasNext()) {
            String word = in.next();
            if (!word.isEmpty()) {
                words.add(word.toLowerCase());
            }
        }

        assert (!words.isEmpty());

        List<Chunk> chunks = new ArrayList<Chunk>();
        for (int i = 0; i < words.size(); i++) {
            chunks.add(new Chunk(i, words.subList(i, words.size())));
        }

        List<List<Chunk>> prev = new ArrayList<List<Chunk>>();
        prev.add(chunks);

        System.out.println("process");
        while (!prev.isEmpty()) {
            List<List<Chunk>> next = new ArrayList<List<Chunk>>(words.size());
            for (List<Chunk> basket : prev) {
                next.addAll(processChunks(basket));
            }
            prev = next;
        }

        //processChunks(chunks);

        out.println(bestValue);
        if (bestWitness != null) {
            for (String word : bestWitness) {
                out.print(word.toUpperCase().charAt(0));
            }
        }

        System.out.println(ops);
    }

    public static void main(String[] args) throws IOException {
        in = new Scanner(new File("kina.in"));
        out = new PrintWriter(new File("kina.out"));

        new kina_gk_wa().run();

        in.close();
        out.close();
    }
}
