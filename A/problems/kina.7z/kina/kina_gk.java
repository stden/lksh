import java.io.*;
import java.util.*;
import java.util.regex.*;

public class kina_gk {
    static Scanner in;
    static PrintWriter out;

    List<String> bestWitness;
    int bestValue = 0;

    static class Node {
        final Node[] next = new Node[26];
        String word;

        Node next(char ch) {
            int index = ch - 'a';
            if (next[index] == null) {
                next[index] = new Node();
            }
            return next[index];
        }
    }

    Node next(Node node, int index) {
        if (node == null) {
            return null;
        }
        return node.next[index];
    }

    Node root = new Node();

    static class Chunk {
        final List<String> words;
        int pos = 0;
        int hash = 0;
        int length = 0;
        int start;

        Chunk(int start, List<String> words) {
            this.words = words;
            this.start = start;
            int hash = 0;
        }

        char advance() {
            String word = pos < words.size() ? words.get(pos) : "____";
            pos++;
            length += word.length();
            hash = hash * 31 + word.hashCode();
            return word.charAt(0);
        }

        List<String> getWitness() {
            return words.subList(0, pos);
        }
    }

    class Basket {
        final List<Chunk> chunks = new ArrayList<Chunk>();
        final Node node;

        public Basket(Node node) {
            this.node = node;
        }
    }

    List<Basket> next;

    void processChunks(Basket chunks) {        
        if (chunks.chunks.size() < 2) {
            return;
        }

        Chunk first = chunks.chunks.get(0);
        boolean sameHash = true;
        int count = 0;
        int last = Integer.MIN_VALUE;
        for (Chunk chunk : chunks.chunks) {
            sameHash &= first.hash == chunk.hash;
            if (last + first.pos <= chunk.start) {
                count++;
                last = chunk.start;
            }
        }
        if (sameHash && (chunks.node == null || chunks.node.word == null)) {
            //System.out.println(first.getWitn);
            //int count = chunks.size();
            int length = first.length;
            int value = count * length - (count * first.pos + length);
            if (bestValue < value) {
                bestValue = value;
                bestWitness = first.getWitness();
            }
            
            //System.out.println(first.getWitness() + " # " + count + " " + value + " ! " + length);
        }

        Basket[] baskets = new Basket[26];
        for (int i = 0; i < baskets.length; i++) {
            baskets[i] = new Basket(next(chunks.node, i));
        }

        for (Chunk chunk : chunks.chunks) {
            int basket = chunk.advance() - 'a';
            if (basket >= 0) {
                baskets[basket].chunks.add(chunk);
            }
        }

        for (Basket basket : baskets) {
            if (basket.chunks.size() >= 2) {
                next.add(basket);
            }
        }
    }

    void run() {
        in.useDelimiter("[^a-zA-Z]");
        List<String> words = new ArrayList<String>();
        while (in.hasNext()) {
            String word = in.next();
            if (!word.isEmpty()) {
                words.add(word.toLowerCase());
            }
        }

        assert (!words.isEmpty());

        for (String word : words) {
            Node node = root;
            for (char ch : word.toCharArray()) {
                node = node.next(ch);
            }
            node.word = word;
        }

        Basket chunks = new Basket(root);
        for (int i = 0; i < words.size(); i++) {
            chunks.chunks.add(new Chunk(i, words.subList(i, words.size())));
        }

        List<Basket> prev = new ArrayList<Basket>();
        prev.add(chunks);

        while (!prev.isEmpty()) {
            next = new ArrayList<Basket>();
            for (Basket basket : prev) {
                processChunks(basket);
            }
            prev = next;
        }

        out.println(bestValue);
        if (bestWitness != null) {
            for (String word : bestWitness) {
                out.print(word.toUpperCase().charAt(0));
            }
            System.out.println(bestWitness);
        }
    }

    public static void main(String[] args) throws IOException {
        in = new Scanner(new File("kina.in"));
        out = new PrintWriter(new File("kina.out"));

        new kina_gk().run();

        in.close();
        out.close();
    }
}
