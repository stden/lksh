import java.io.*;
import java.util.*;
import java.util.regex.*;

public class kina_gk_ml_hash {
    static Scanner in;
    static PrintWriter out;

    static List<String> bestWitness;
    static int bestValue = 0;

    static class Node {
        Node[] next = new Node[26];
        int count;
        boolean hetero;
        int hash;
        List<String> witness;
        int prev;

        Node get(String word) {
            int ch = word.charAt(0) -'a';
            if (next[ch] == null) {
                next[ch] = new Node();
            }
            return next[ch];
        }

        void traverse() {
            if (count > 1 && !hetero) {
                int length = 0;
                for (String word : witness) {
                    length += word.length();
                }
                int value = count * length - (count * witness.size() + length);
                if (bestValue < value) {
                    bestValue = value;
                    bestWitness = witness;
                }
                System.out.println(witness + " # " + count + " " + value + " ! " + length + " " + witness.size());
            }
            for (int ch = 0; ch < next.length; ch++) {
                Node node = next[ch];
                if (node != null) {
                    node.traverse();
                }
            }
        }
    }

    void run() {
        in.useDelimiter("[^a-zA-Z]");
        List<String> words = new ArrayList<String>();
        while (in.hasNext()) {
            String word = in.next();
            if (!word.isEmpty()) {
                words.add(word.toLowerCase());
            }
        }

        Node root = new Node();

        for (int i = 0; i < words.size(); i++) {
            //System.out.println(i + " " + words.size());
            Node node = root;
            int hash = 0;
            for (int j = i; j < words.size(); j++) {
                String word = words.get(j);
                node = node.get(word);
                hash = hash * 31 + word.hashCode();
                if (node.prev == 0 || node.prev + node.witness.size() <= i) {
                    node.prev = i;
                    if (node.count == 0) {
                        node.hash = hash;
                        node.witness = words.subList(i, j + 1);
                    }
                    node.count++;
                }
                node.hetero |= node.hash != hash;
            }
        }
        root.traverse();

        out.println(bestValue);
        if (bestWitness != null) {
            for (String word : bestWitness) {
                out.print(word.toUpperCase().charAt(0));
            }
            /*
            out.println();
        
            for (String word : bestWitness) {
                out.print(word);
                out.print(" ");
            }
            out.println();
            */
        }
    }

    public static void main(String[] args) throws IOException {
        in = new Scanner(new File("kina.in"));
        out = new PrintWriter(new File("kina.out"));

        new kina_gk_ml_hash().run();

        in.close();
        out.close();
    }
}
