import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Scanner;

public class kina_dg_wa_same implements Runnable {
	
	class Trie {
		char parent;
		Trie child, next;
		short left;
		boolean unambiguous;
		
		public Trie(char p, Trie n) {
			child = null;
			next = n;
			left = -1;
			parent = p;
			unambiguous = true;
		}
		
		Trie next(char c) {
			Trie current = child;
			while (current != null) {
				if (current.parent == c) {
					return current;
				}
				current = current.next;
			}
			child = new Trie(c, child);
			return child;
		}
	}
	
	private void solve() throws IOException {
		Scanner sc = new Scanner(new File("kina.in"));
		PrintWriter pw = new PrintWriter("kina.out");
		sc.useDelimiter("[^a-zA-Z]");
		
		HashMap<String, Integer> words = new HashMap<String, Integer>();
		ArrayList<String> input = new ArrayList<String>();
		while (sc.hasNext()) {
			String word = sc.next().toUpperCase();
			if (word.length() == 0) {
				continue;
			}
			input.add(word);
			if (!words.containsKey(word)) {
				words.put(word, words.size());
			}
		}
		
		int n = input.size();
		int[] list = new int[n];
		char[] letters = new char[n];
		int[] len = new int[n];
		for (int i = 0; i < n; i++) {
			list[i] = words.get(input.get(i));
			letters[i] = input.get(i).charAt(0);
			len[i] = input.get(i).length();
		}
		
		Trie root = new Trie('A', null);
		
		//put all words in trie, such abbreviations are ambiguous
		for (String word : words.keySet()) {
			char[] c = word.toCharArray();
			Trie current = root;
			for (char ch : c) {
				current = current.next(ch);
			}
			current.unambiguous = false;
		}
		
		//release unusing memory
		words = null;
		input = null;
		
		//r[i][j] is the maximum common prefix of suffix [i..n-1] and suffix [j..n-1]
		short[][] r = new short[n + 1][n + 1];
		for (int i = n - 1; i >= 0; i--) {
			for (int j = n - 1; j >= 0; j--) {
				r[i][j] = (short) (list[i] == list[j] ? r[i + 1][j + 1] + 1 : 0);
			}
		}
		
		//check that abbreviation has no other coreesponding sequence of words
		for (short i = 0; i < n; i++) {
			Trie current = root;
			for (short j = i; j < n; j++) {
				current = current.next(letters[j]);
				if (current.left == -1) {
					current.left = i;
				} else {
					//current.unambiguous &= (r[i][current.left] >= j - i + 1);
				}
			}
		}
		
		//for any subsequence [i..j] find r[i][j], the count of repeats this subsequence to the right
		for (int left = n - 1; left >= 0; left--) {
			int[] s = new int[n];
			Arrays.fill(s, n);
			for (int right = n - 1; right > left; right--) {
				if (r[left][right] > 0) {
					int v = Math.min(right - 1, left + r[left][right] - 1);
					s[v] = Math.min(s[v], right);
				}
			}
			for (int right = n - 1; right >= left; right--) {
				if (right < n - 1) {
					s[right] = Math.min(s[right], s[right + 1]);
				}
				if (s[right] < n) {
					r[left][right] = (short) (1 + r[s[right]][s[right] + right - left]);
				} else {
					r[left][right] = 0;
				}
			}
		}
		
		//find the best effectiveness
		int best = 0;
		int bestLeft = -1;
		int bestRight = -1;
		for (int left = 0; left < n; left++) {
			int total = 0;
			Trie current = root;
			for (int right = left; right < n; right++) {
				current = current.next(letters[right]);
				total += len[right];
				int effectiveness = (total - (right - left + 1)) * r[left][right] - (right - left + 1);
				if (effectiveness > best && current.unambiguous) {
					best = effectiveness;
					bestLeft = left;
					bestRight = right;
				}
			}
		}
		
		pw.println(best);
		if (bestLeft != -1) {
			for (int i = bestLeft; i <= bestRight; i++) {
				pw.print(letters[i]);
			}
			pw.println();
		}
		
		sc.close();
		pw.close();
	}

	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		new Thread(new kina_dg_wa_same()).start();
	}

	public void run() {
		try {
			solve();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
