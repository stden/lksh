/*
    Solution for NEERC'2008 Problem K: KINA Is Not Abbreviation
    (C) Roman Elizarov
    Note: this solution attempts to check correctness of the input
*/

import java.io.*;
import java.util.*;

public class kina_re {
	private static final int MAX_LENGTH = 4000;

	public static void main(String[] args) throws Exception {
		new kina_re().go();
	}

	static class Trie {
		Trie next;
		Trie down;
		char c;
		int whash; // -1 if ambig
		int wss;
		int lastidx = -1;
		int cnt;
	}

	Map<String, Integer> wmap;
	Trie root = new Trie();

	void go() throws Exception {
		// read input
		Reader in = new FileReader(new File("kina.in"));
		char[] chars = new char[MAX_LENGTH + 1];
		int len = in.read(chars);
		assert len <= MAX_LENGTH;
		in.close();

		// solve
		List<String> words = new ArrayList<String>();
		for (int i = 0; i < len; i++) {
			char c = chars[i];
			assert c >= 32 && c <= 126 || c == 13 || c == 10;
			if (isLetter(c)) {
				StringBuilder sb = new StringBuilder();
				while (i < len && isLetter(chars[i]))
					sb.append(Character.toLowerCase(chars[i++]));
				words.add(sb.toString());
			}
		}
		int n = words.size();
		wmap = new HashMap<String, Integer>();
		for (String w : words) {
			if (!wmap.containsKey(w))
				wmap.put(w, wmap.size());
		}
		int[] wnum = new int[n];
		for (int i = 0; i < n; i++) {
			wnum[i] = wmap.get(words.get(i));
		}

		for (int i = 0; i < n; i++) {
			Trie node = root;
			int whash = 1;
			int wss = 0;
			for (int j = i; j < n; j++) {
				String w = words.get(j);
				char c = w.charAt(0);
				whash = whash * 31 + wnum[j];
				wss += w.length(); 
				Trie prev = null;
				while (node != null && node.c != c) {
					prev = node;
					node = node.next;
				}
				if (node == null) {
					node = new Trie();
					node.c = c;
					prev.next = node;
				}
				if (node.cnt == 0) {
					node.whash = whash;
					node.wss = wss;
				} else if (node.whash != whash || node.wss != wss)
					node.whash = -1;
				if (node.lastidx < i) {
					node.cnt++;
					node.lastidx = j;
				}
				if (node.down == null)
					node.down = new Trie();
				node = node.down;
			}
		}

		findBest(root, 0);

		// write output
		PrintWriter out = new PrintWriter("kina.out");
		out.println(besteffect);
		if (besteffect > 0)
			out.println(best);
		out.close();
	}

	char[] curchars = new char[MAX_LENGTH];
	String best = null;
	int besteffect = 0;

	private void findBest(Trie node, int i) {
		int len = i + 1;
		for (; node != null; node = node.next) {
			if (node.c == 0)
				continue;
			curchars[i] = node.c;
			if (node.whash != -1 && node.cnt > 0) {
				int effect = (node.cnt - 1) * (node.wss - len) - len;
				if (effect > besteffect) {
					String s = new String(curchars, 0, len);
					if (!wmap.containsKey(s)) {
						besteffect = effect;
						best = s;
					}
				}
			}
			findBest(node.down, i + 1);
		}
	}

	private boolean isLetter(char c) {
		return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z';
	}
}
