import java.util.*;
import java.io.*;
import java.math.*;

public class prosto_al {
  public static void main (String args []) throws Exception {
    BufferedReader in = new BufferedReader (new FileReader (new File ("prosto.in")));
    PrintWriter out = new PrintWriter ("prosto.out");

    StringTokenizer t = new StringTokenizer (in.readLine ());
    long a = Long.parseLong (t.nextToken ());
    long b = Long.parseLong (t.nextToken ());
    if (t.hasMoreTokens ()) throw new Exception ("too many parameters in line 1");
    if (a < 1 || a > b || b > (long)(1e9)*(long)(1e9)) throw new Exception ("Invalid a or b");

    t = new StringTokenizer (in.readLine ());
    int n = Integer.parseInt (t.nextToken ());
    if (t.hasMoreTokens ()) throw new Exception ("too many parameters in line 2");
    if (n < 1 || n > 9) throw new Exception ("Invalid n");

    long [] p = new long [n];

    t = new StringTokenizer (in.readLine ());
    for (int i = 0; i < n; i++) {
      p[i] = Long.parseLong (t.nextToken ());
      if (p[i] < 2 || p[i] > 100) throw new Exception ("invalid prime");
      for (int j = 0; j < i; j++)
        if (p[i] == p[j]) throw new Exception ("equal primes");
      if (!BigInteger.valueOf (p[i]).isProbablePrime (100))
        throw new Exception ("is not prime");
    };
    if (t.hasMoreTokens ()) throw new Exception ("too many parameters in line 2");

    long sum = 0;

    for (int i = 0; i < (1 << n); i++) {
      int f = 1;
      long q = 1;
      for (int j = 0; j < n; j++) 
        if ((i & (1 << j)) > 0) {
          f *= -1;
          q *= p[j];
        };

      sum += f * (b / q - (a - 1) / q);
    };

    out.println (sum);

    out.close ();
  };
};