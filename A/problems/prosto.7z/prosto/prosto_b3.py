#!/usr/bin/python
# -*- coding: utf8 -*-

input = open('prosto.in', 'r')
output = open('prosto.out', 'w')

a, b = [int(i) for i in input.readline().split()]
n = int(input.readline())
p = [int(i) for i in input.readline().split()]

ans = 0
for pr in range(1 << n):
  koef, m = 1, 1
  for i in range(n):
    if ((1 << i) & pr) != 0:
      koef *= -1; m *= p[i]
  res = b // m - (a - 1) // m;
  ans += res * koef

output.write(str(ans) + '\n')

