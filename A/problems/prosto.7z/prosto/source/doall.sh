#!/bin/bash

unrar x -o+ tests.rar

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

