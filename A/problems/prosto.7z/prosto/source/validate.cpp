#include <testlib.h>
#include <set>

const long long maxx = 1000000000000000000ll;
const int maxn = 9;
const int maxp = 100;

bool isPrime( int p ) {
  if (p < 2)
    return false;
  for (int i = 2; i * i <= p; i++)
    if (p % i == 0)
      return false;
  return true;
}

int main() {
  registerValidation();
  long long a = inf.readLong(1, maxx);
  inf.readSpace();
  inf.readLong(a, maxx);
  inf.readEoln();
  int n = inf.readInt(1, maxn);
  inf.readEoln();
  std::set <int> s;
  for (int i = 0; i < n; i++) {
    int p = inf.readInt(1, maxp);
    if (i == n - 1)
      inf.readEoln();
    else
      inf.readSpace();
    ensuref(isPrime(p), "число %d не просто", p);
    ensuref(s.count(p) == 0, "простое число %d повторяется", p);
    s.insert(p);
  }
  inf.readEof();
  return 0;
}

