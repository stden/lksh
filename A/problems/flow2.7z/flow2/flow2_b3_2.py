#!/usr/bin/python3
# -*- coding: utf8 -*-

input = open('flow.in', 'r')
output = open('flow.out', 'w')

n, m = [int(x) for x in input.readline().split()]
source, sink = 0, n - 1
head = [None for i in range(n)]
edges = []
for i in range(m):
  a, b, c = [int(x) for x in input.readline().split()]
  a -= 1; b -= 1
  edges.append([b, c, 0, head[a], i * 2 + 1])
  edges.append([a, 0, 0, head[b], i * 2])
  head[a], head[b] = i * 2, i * 2 + 1

def bfs():
  global distance, color, limit, edges, head
  distance, color = [None] * n, [0] * n
  distance[source] = 0
  queue = [source]
  color[source] = 1
  for vertex in queue:
    edge = head[vertex]
    while edge is not None:
      target = edges[edge][0]
      if edges[edge][1] - edges[edge][2] >= limit and color[target] == 0:
        color[target] = 1
        distance[target] = distance[vertex] + 1
        queue.append(target)
      edge = edges[edge][3]

def dfs( vertex ):
  if vertex == sink:
    return True
  while pointer[vertex] is not None:
    edge = pointer[vertex]
    if edges[edge][1] - edges[edge][2] >= limit and distance[edges[edge][0]] == distance[vertex] + 1 and dfs(edges[edge][0]):
      edges[edge][2] += limit
      edges[edges[edge][4]][2] -= limit
      return True
    pointer[vertex] = edges[edge][3]
  return False
  
distance = []
limit = 1 << 30
answer = 0
while limit > 0:
  while True:
    bfs()
    if distance[sink] is None:
      break
    pointer = [x for x in head]
    while dfs(source):
      answer += limit
  limit //= 2

output.write('%d\n' % answer)

