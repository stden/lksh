#define _CRT_SECURE_NO_WARNINGS

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>
#include <iostream>
#include <sstream>
#include <cstdio>
#include <cassert>
#include <utility>

using namespace std;

#define C_IN_FILE "flow.in"
#define C_OUT_FILE "flow.out"

class BoolTable
{
public:
    BoolTable(int n):mark(n, -1), cur_mark(0) {}
    void clear() {
        ++cur_mark;
    }
    
    bool operator[] (int idx) {
        return mark[idx] == cur_mark;
    }

    void setValue(int idx, bool res) {
        if (res) {
            mark[idx] = cur_mark;
        } else {
            mark[idx] = -1;
        }
    }
private:
    vector<int> mark;
    int cur_mark;
};

class DinnicaNetwork
{
public:
    DinnicaNetwork(int n):n(n), used(n) {
        head.resize(n, -1);
    }
    void addEdge(int f, int t, int w);
    long long getMaxFlow(int s, int t);
    void outMaxFlow(int s, int t);
private:
    struct Edge {
        int id;
        int a, b, c, f;
        int next;
        int reverseId() {
            return id ^ 1;
        }
        bool pass() {
            return f < c;
        }
        int rest() {
            return c - f;
        }
        Edge(int id, int a, int b, int c): id(id), a(a), b(b), c(c), f(0) {}
    };

    bool bfs(int s, int t);
    bool dfs(int s, int t);
    int pushFlow();
    long long ans;
    int n;
    vector<Edge> e;
    vector<int> head;
    vector<int> cur;
    vector<int> d;
    vector<int> path;
    BoolTable used;
};

void DinnicaNetwork::addEdge(int f, int t, int w) {
    int id1 = (int)e.size();
    Edge e1(id1, f, t, w);
    e1.next = head[f];
    head[f] = id1;

    int id2 = id1 + 1;
    Edge e2(id2, t, f, 0);
    e2.next = head[t];
    head[t] = id2;

    e.push_back(e1);
    e.push_back(e2);
}

long long DinnicaNetwork::getMaxFlow(int s, int t) {
    d.resize(n);
    ans = 0;
    while (bfs(s, t)) {
        cur = head;
        do {
            ans += pushFlow();
            used.clear();
            path.clear();
        } while (dfs(s, t));
    }
    return ans;
}

void DinnicaNetwork::outMaxFlow(int s, int t) {
    printf("%lld\n", getMaxFlow(s, t));
    /*for(size_t i = 0; i < e.size(); ++i) {
        if (i % 2 == 0) {
            printf("%d\n", e[i].f);
        }
    }*/
}

bool DinnicaNetwork::bfs(int s, int t)
{
    used.clear();
    d[s] = 0;
    queue<int> q;
    q.push(s);
    used.setValue(s, true);
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for(int i = head[v]; i != -1; i = e[i].next) {
            if (e[i].pass()) {
                int u = e[i].b;
                if (!used[u]) {
                    used.setValue(u, true);
                    d[u] = d[v] + 1;
                    q.push(u);
                }
            }
        }
    }

    return used[t];
}

bool DinnicaNetwork::dfs(int s, int t)
{
    if (used[s]) {
        return false;
    }
    used.setValue(s, true);
    if (s == t) {
        return true;
    }
    for(int i = cur[s]; i != -1; i = e[i].next) {
        int u = e[i].b;
        if (e[i].pass() && d[u] == d[s] + 1 && dfs(u, t)) {
            path.push_back(i);
            return true;
        } else {
            cur[s] = e[i].next;
        }
    }
    return false;
}

int DinnicaNetwork::pushFlow() {
    if (path.empty()) {
        return 0;
    }
    int add = e[path[0]].rest();
    for(size_t i = 1; i < path.size(); ++i) {
        add = min(add, e[path[i]].rest());
    }
    for(size_t i = 0; i < path.size(); ++i) {
        int num = path[i];
        e[num].f += add;
        e[e[num].reverseId()].f -= add;
    }
    return add;
}

DinnicaNetwork* network;
int ans;
int s, t;

void outdata() {
}

void solve() {
    network->outMaxFlow(s, t);
    delete network;
}

void readdata() {
    int n, m;
    scanf("%d%d", &n, &m);
    network = new DinnicaNetwork(n);
    for(int i = 0; i < m; ++i) {
        int a, b, w;
        scanf("%d%d%d", &a, &b, &w);
        network->addEdge(a - 1, b - 1, w);    
    }
//    scanf("%d%d", &s, &t);
    s = 1;
    t = n;
	--s, --t;
}

int main() {
    freopen(C_IN_FILE, "rt", stdin);
    freopen(C_OUT_FILE, "wt", stdout);
	readdata();
	solve();
	outdata();
	return 0;
}
