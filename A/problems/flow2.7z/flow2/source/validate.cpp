#include <testlib.h>
#include <set>

const int maxn = 500;
const int maxm = 10000;
const int maxc = 1000000000;

int main() {
  using namespace std;
  registerValidation();
  int n = inf.readInt(2, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxm);
  inf.readEoln();
  set< pair<int, int> > s;
  for (int i = 0; i < m; i++) {
    int a = inf.readInt(1, n);
    inf.readSpace();
    int b = inf.readInt(1, n);
    if (a == b)
      quitf(_fail, "loop at vertex %d", a);
    inf.readSpace();
    inf.readInt(1, maxc);
    inf.readEoln();
    pair <int, int> p = make_pair(a, b);
    if (s.count(p) != 0)
      quitf(_fail, "duplicate edge %d -> %d\n", a, b);
  }
  inf.readEof();
  return 0;
}

