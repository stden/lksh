#include <cstdio>
#include <cstdlib>

#include "random.h"

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

int R( int c )
{
  return R(c, c);
}

const int maxn = 500;

int is[maxn][maxn];

int main( int argc, char *argv[] )
{
  int n = atoi(argv[1]);
  int c = (1 << atoi(argv[2])) - 1;
  int p = atoi(argv[3]);

  int cnt = 0;
  initrand(0);
  forn(i, n)
    forn(j, n)
      cnt += (is[i][j] = (rndInt(100) < p));

  int st = 1;
  int en = 2 * n + 2;
  int last = 2 * n + 3;

  initrand(0);

  int v = 2 * n + 3, e = 2 * n + cnt + 1;
  fprintf(stderr, "v=%d e=%d\n", v, e);
  printf("%d %d\n", v, e);
  forn(i, n)
    forn(j, n)
      if (is[i][j])
        printf("%d %d %d\n", i + 2, j + n + 2, R(c));
  forn(i, n)
    printf("%d %d %d\n", st, i + 2, R(c * n));
  forn(j, n)
    printf("%d %d %d\n", j + n + 2, en, R(c * n));
  printf("%d %d %d\n", en, last, R((int)(0.01 * c * n * n * p)));
  return 0;
}
