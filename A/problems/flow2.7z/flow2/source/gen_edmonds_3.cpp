#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <cmath>

#define forn(i, n) for (int i = 0; i < (int)(n); i++)
  
const int maxn = (int)1e4;
const int maxm = (int)1e5;
const int inf = (int)1e9;

int v = 0, e = 0, a[maxm], b[maxm], c[maxm];
int st, en = -1, p1[maxn], p2[maxn], logv[maxn];

void AddE( int x, int y, int z )
{
  assert(e < maxm);
  a[e] = x, b[e] = y, c[e++] = z;
}

int NewV()
{
  return ++v;
}

int Cor( int v )
{
  return v == -1 ? en : v;
}

// First edge = [a,x,first?c:inf]
// Last  edge = [p,b,first?inf:c]

int AddChain( int a, int b, int len, int c, int first )
{
  int p, q, x = NewV();
  AddE(a, x, first ? c : inf);

  p = x;
  forn(i, len - 2)
    AddE(p, q = NewV(), inf), p = q;

  AddE(p, b, first ? inf : c);
  return first ? x : p;
}

int main( int argc, char *argv[] )
{
  int n = atoi(argv[1]);
  int k = atoi(argv[2]);
  int m = atoi(argv[3]);

  st = NewV();
  int st1 = NewV();
  int st2 = NewV();
  forn(i, n) 
  {
    p1[i] = NewV();
    p2[i] = NewV();
  }
  int en1 = NewV();
  int en2 = NewV();

  forn(i, n)
    forn(j, n)
      AddE(p1[i], p2[j], 1);
  forn(i, n)
  {
    AddE(st1, p1[i], inf);
    AddE(st2, p2[i], inf);
    AddE(p1[i], en2, inf);
    AddE(p2[i], en1, inf);
  }

  int C = n * n;
  AddE(st, st1, C);
  AddE(en1, en, C);

  forn(t, k)
  {
    st2 = AddChain(st, st2, t ? 5 : 3, C, 1);
    en2 = AddChain(en2, en, t ? 5 : 3, C, 0);

    st1 = AddChain(st, st1, 5, C, 1);
    en1 = AddChain(en1, en, 5, C, 0);
  }
  
  if (e < m)
  {
    int x = (int)sqrt(m - e);
    while (x * (x + 1) + e + 1 <= m)
      x++;
    if (x > 0)
      fprintf(stderr, "Add %d vertices and %d edges\n", x, x * (x - 1) + 1);

    int tmp = NewV();
    AddE(st, tmp, inf);
    forn(i, x - 1)
      NewV();
    forn(i, x)
      forn(j, x)
        if (i != j)
          AddE(tmp + j, tmp + i, inf);
  }

  en = NewV();
  fprintf(stderr, "v=%d e=%d\n", v, e);
  printf("%d %d\n", v, e);
  forn(i, e)
    printf("%d %d %d\n", Cor(a[i]), Cor(b[i]), c[i]);
  return 0;
}
