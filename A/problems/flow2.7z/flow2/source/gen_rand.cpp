#include <cstdio>
#include <cstdlib>

#include "random.h"

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

int main( int argc, char *argv[] )
{
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);
  int c = atoi(argv[3]);

  fprintf(stderr, "n = %d, m = %d, c = %d\n", n, m, c);

  initrand(0);
  printf("%d %d\n", n, m);
  forn(i, m) {
    int a, b, x;
    do
      a = R(1, n), b = R(1, n), x = R(1, c);
    while (a == b);
    printf("%d %d %d\n", a, b, x);
  }
  return 0;
}

