#!/bin/bash

for i in *.hand; do
  cp "$i" "${i%.hand}" || exit 1
done

for i in gen_rand gen_bipartite{,2} gen_edmonds_{1,2,3}; do
  g++ -O2 -Wall -o "$i" "$i.cpp" || exit 1
done

for i in do??.dpr; do
  fpc -Mdelphi "$i" || exit 1
  name="${i%.dpr}"
  "./$name" > ${name#do} || exit 1
done

./gen_rand 500 10000 1000000000 > 25 || exit 1

./gen_bipartite 100 50 95 > 26 || exit 1
./gen_bipartite 248 50 15 > 27 || exit 1
./gen_bipartite2 100 10 95 > 28 || exit 1
./gen_bipartite2 248 16 15 > 29 || exit 1

./gen_edmonds_1 98 > 30 || exit 1
./gen_edmonds_2 20 5 > 31 || exit 1
./gen_edmonds_2 40 5 > 32 || exit 1
./gen_edmonds_2 50 10 > 33 || exit 1
./gen_edmonds_2 96 19 > 34 || exit 1
./gen_edmonds_3 50 10 10000 > 35 || exit 1
./gen_edmonds_3 90 10 10000 > 36 || exit 1
./gen_edmonds_3 70 18 10000 > 37 || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

