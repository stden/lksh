#include <cstdio>
#include <cstdlib>

#define forn(i, n) for (int i = 0; i < (int)(n); i++)
  
int main( int argc, char *argv[] )
{
  int n = atoi(argv[1]);

  int st = 1;
  int en = 2 * n + 6;
  int last = 2 * n + 1;

  int v = 2 * n + 6, e = n * n + 4 * n + 4;
  fprintf(stderr, "v=%d e=%d\n", v, e);
  printf("%d %d\n", v, e);

  forn(i, n)
    forn(j, n)
      printf("%d %d %d\n", i + 2, j + n + 2, 1);
  forn(i, n)
    printf("%d %d %d\n", st, i + 2, n);
  forn(j, n)
    printf("%d %d %d\n", j + n + 2, en, n);

  printf("%d %d %d\n", st, ++last, n * n), v = last;
  printf("%d %d %d\n", v, ++last, n * n), v = last;
  forn(j, n)
    printf("%d %d %d\n", v, j + n + 2, n);

  printf("%d %d %d\n", ++last, en, n * n), v = last;
  printf("%d %d %d\n", ++last, v, n * n), v = last;
  forn(i, n)
    printf("%d %d %d\n", i + 2, v, n);

  return 0;
}
