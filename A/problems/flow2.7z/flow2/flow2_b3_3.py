#!/usr/bin/python3
# -*- coding: utf8 -*-

input = open('flow.in', 'r')
output = open('flow.out', 'w')

class Edge:
  def __init__( self, target, capacity, next ):
    self.target, self.capacity, self.flow, self.next, self.reverse = target, capacity, 0, next, None

def bfs():
  global distance
  distance, color = [None] * n, [0] * n
  distance[source] = 0
  queue = [source]
  color[source] = 1
  for vertex in queue:
    edge = head[vertex]
    while edge is not None:
      target = edge.target
      if edge.capacity - edge.flow >= limit and color[target] == 0:
        color[target], distance[target] = 1, distance[vertex] + 1
        queue.append(target)
      edge = edge.next

def dfs( vertex ):
  global pointer
  if vertex == sink:
    return True
  while pointer[vertex] is not None:
    edge = pointer[vertex]
    if edge.capacity - edge.flow >= limit and distance[edge.target] == distance[vertex] + 1 and dfs(edge.target):
      edge.flow += limit
      edge.reverse.flow -= limit
      return True
    pointer[vertex] = edge.next
  return False

n, m = [int(x) for x in input.readline().split()]
source, sink = 0, n - 1
head = [None for i in range(n)]
edges = []
for i in range(m):
  a, b, c = [int(x) for x in input.readline().split()]
  a -= 1; b -= 1
  edges.append(Edge(b, c, head[a]))
  edges.append(Edge(a, 0, head[b]))
  edges[-2].reverse = edges[-1]
  edges[-1].reverse = edges[-2]
  head[a], head[b] = edges[-2], edges[-1]

distance = []
limit = max([x.capacity for x in edges])
answer = 0
while limit > 0:
  while True:
    bfs()
    if distance[sink] is None:
      break
    pointer = [x for x in head]
    while dfs(source):
      answer += limit
  limit //= 2

output.write('%d\n' % answer)

