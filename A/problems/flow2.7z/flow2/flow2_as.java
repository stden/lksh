import java.util.*;
import java.io.*;

public class flow_as implements Runnable {
    class Edge {
        int s;
        int t;
        int f;
        int c;
        Edge r;

        Edge(int s, int t, int f, int c) {
            this.s = s;
            this.t = t;
            this.f = f;
            this.c = c;
        }
    }

    class Graph {
        int n;
        ArrayList<Edge>[] edges;

        Graph(int n) {
            this.n = n;
            edges = new ArrayList[n];
            for (int i = 0; i < n; i++) {
                edges[i] = new ArrayList<Edge>();
            }
        }

        void addEdge(int s, int t, int c) {
            Edge e1 = new Edge(s, t, 0, c);
            Edge e2 = new Edge(t, s, 0, 0);
            e1.r = e2;
            e2.r = e1;
            edges[s].add(e1);
            edges[t].add(e2);
        }


        boolean[] u;
        int a;

        int dfs(int x, int t, int curc) {
            u[x] = true;
            if (x == t) {
                return curc;
            }
            for (Edge e : edges[x]) {
                if (!u[e.t] && e.f < (e.c & a)) {
                    int cc = dfs(e.t, t, Math.min(curc, (e.c - e.f) & a));
                    if (cc > 0) {
                        e.f += cc;
                        e.r.f -= cc;
                        return cc;
                    }
                }
            }

            return 0;
        }

        long maxFlow(int s, int t) {
            u = new boolean[n];
            a = 1 << 30;
            long flow = 0;
            while (true) {
                Arrays.fill(u, false);
                long df = dfs(s, t, Integer.MAX_VALUE);
                if (df > 0) {
                    flow += df;
                } else {
                    if ((a & 1) == 1) {
                        break;
                    }
                    a |= (a >> 1);
                }
            }
            return flow;
        }
    }

    public void solve() throws IOException {
        Scanner in = new Scanner(new File("flow.in"));
        PrintWriter out = new PrintWriter("flow.out");

        int n = in.nextInt();
        Graph g = new Graph(n);
        int m = in.nextInt();
        for (int i = 0; i < m; i++) {
            int a = in.nextInt() - 1;
            int b = in.nextInt() - 1;
            int c = in.nextInt();
            g.addEdge(a, b, c);
        }
        long v = g.maxFlow(0, n - 1);
        
        out.println(v);
        
        in.close();
        out.close();
    }

    public void run() {
        try {
            solve();
        } catch (IOException e) {
        }
    }

    public static void main(String[] arg) {
        new Thread(new flow_as()).start();
    }
}
