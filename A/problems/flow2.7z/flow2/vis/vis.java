// Version 3.0

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.color.*;

import java.util.concurrent.Semaphore;
import static java.lang.Math.*;

public class vis
{
  final Semaphore sem = new Semaphore(1);
  Frame fr;
  Scanner in;
  MyCanvas C;
  boolean read = false;

  final int inf = (int)1e9;

  int xmin = inf, xmax = -inf;
  int ymin = inf, ymax = -inf;

  int W, H;
  double cx, cy, kx, ky;

  int w, h;
  int n, m, x[], y[], a[], b[], c[];

  int R( double x )
  {
    return (int)round(x);
  }

  int X( int x )
  {
    return R(W / 2.0 + (x - cx) * kx);
  }

  int Y( int y )
  {
    return R(H / 2.0 - (y - cy) * ky);
  }

  void AddP( int x, int y )
  {
    xmin = min(xmin, x);
    ymin = min(ymin, y);
    xmax = max(xmax, x);
    ymax = max(ymax, y);
  }

  boolean run = true;

  void nextSample()
  {
    while (!sem.tryAcquire())
      ;
    
    xmin = inf; xmax = -inf;
    ymin = inf; ymax = -inf;

    if (!in.hasNextInt())
      System.exit(0);

    n = in.nextInt();
    m = in.nextInt();

    x = new int[n];
    y = new int[n];

    a = new int[m];
    b = new int[m];
    c = new int[m];

    for (int i = 0; i < m; i++)
    {
      a[i] = in.nextInt() - 1;
      b[i] = in.nextInt() - 1;
      c[i] = in.nextInt();
    }
    for (int i = 0; i < n; i++)
    {
      x[i] = in.nextInt();
      y[i] = in.nextInt();
      AddP(x[i], y[i]);
    }
    xmin--; xmax++;
    ymin--; ymax++;

    read = true;
    sem.release();
    C.repaint();
  }

  public class Pnt
  {
    double x, y;

    Pnt( double _x, double _y )
    {
      x = _x;
      y = _y;
    }

    Pnt rot( double a )
    {
      return new Pnt(x * cos(a) - y * sin(a), x * sin(a) + y * cos(a));
    }

    Pnt add( Pnt p )
    {
      return new Pnt(x + p.x, y + p.y);
    }

    Pnt sub( Pnt p )
    {
      return new Pnt(x - p.x, y - p.y);
    }

    Pnt mul( double k )
    {
      return new Pnt(x * k, y * k);
    }

    Pnt div( double k )
    {
      return mul(1.0 / k);
    }

    double smul( Pnt p )
    {
      return x * p.x + y * p.y;
    }

    double len()
    {
      return sqrt(x * x + y * y);
    }

    Pnt norm()
    {
      return this.div(len());
    }
  }

  public void DrawArrow( Graphics g, int x1, int y1, int x2, int y2 )
  {
    Pnt p1 = new Pnt(x1, y1);
    Pnt p2 = new Pnt(x2, y2);

    Pnt v = p2.sub(p1).norm().mul(15);
    double A = 0.2;

    int xx[] = new int[3];
    int yy[] = new int[3];

    xx[0] = x2;
    xx[1] = R(p2.sub(v.rot(A)).x);
    xx[2] = R(p2.sub(v.rot(-A)).x);
    yy[0] = y2;
    yy[1] = R(p2.sub(v.rot(A)).y);
    yy[2] = R(p2.sub(v.rot(-A)).y);

    g.drawLine(x1, y1, x2, y2);
    g.fillPolygon(xx, yy, 3);
  }

  public void CreateFrame( String[] args ) throws Exception
  {
    fr = new Frame("Visualizer");

    fr.setSize(fr.getMaximumSize());
    fr.addKeyListener(new KeyAdapter() {
      public void keyPressed( KeyEvent e ) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE)
          nextSample();
      }
    });
    fr.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    
    in = new Scanner(new File(args[0]));
    fr.add(C = new MyCanvas());
    fr.doLayout();
    fr.show();

    nextSample();

    while (true)
    {
//      C.repaint();
    }
  }

  public class MyCanvas extends Canvas
  {
    @Override
    public void paint( Graphics g )
    {
      W = getWidth();
      H = getHeight();

      if (!read)
        return;
      while (!sem.tryAcquire())
        ;

      cx = (xmin + xmax) * 0.5;
      cy = (ymin + ymax) * 0.5;
      kx = (double)W / (xmax - xmin) * 0.8;
      ky = (double)H / (ymax - ymin) * 0.8;
      kx = ky = min(kx, ky);

      int R = 5;
      g.setColor(Color.RED);
      for (int i = 0; i < m; i++)
        DrawArrow(g, X(x[a[i]]), Y(y[a[i]]), X(x[b[i]]), Y(y[b[i]]));
      
      g.setColor(new Color(0, 150, 0));
      g.setFont(new Font("Courier New", Font.BOLD, 16));
      for (int i = 0; i < m; i++)
      {
        int h = 12;
        int len = String.valueOf(c[i]).length();
        int w = 8 + 9 * (len - 1);
 
        g.setColor(new Color(0, 150, 0));

        int curx = (X(x[a[i]]) + X(x[b[i]])) / 2 - w / 2;
        int cury = (Y(y[a[i]]) + Y(y[b[i]])) / 2 + h / 2;
        g.drawString(String.valueOf(c[i]), curx, cury);

        g.setColor(Color.BLUE);
        g.drawRect(curx - 1, cury - h - 1, w + 2, h + 2);
      }

      g.setColor(Color.BLUE);
      for (int i = 0; i < n; i++)
        g.fillOval(X(x[i]) - R, Y(y[i]) - R, 2 * R, 2 * R);

      g.setColor(Color.BLACK);
      g.drawString("Press space to view the next test...", 10, 20);

      sem.release();
    }
  }

  public void run( String[] args ) throws Exception
  {
    if (args.length < 1)
    {
      System.out.println("Usage: parametrs = <file to visualize>");
      System.exit(0);
    }
    CreateFrame(args);
  }

  static public void main( String[] args ) throws Exception
  {
    new vis().run(args);
  }
}
