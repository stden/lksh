#include <cassert>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

typedef long long ll;

#define maxv 503
#define maxe 20010

int e = 0, n, m, he[maxv], ne[maxe], to[maxe], c[maxe];
int cc, u[maxv], d[maxv], che[maxv];
int plen, pa[maxv];
int qst, qen, q[maxv], pr[maxv];

ll res = 0;
int gmi;

int dfs( int v, int cmi )
{
  if (v == n)
  {
    gmi = cmi;
    return 1;
  }
  u[v] = cc;
  while (che[v] != -1)
  {
    int x, i = che[v];
    if (d[x = to[i]] == d[v] + 1 && c[i] > 0)
      if (u[x] != cc && dfs(x, min(cmi, c[i])))
      { 
        pa[plen++] = i;
        c[i] -= gmi, c[i ^ 1] += gmi;
        return 1;       
      }
    che[v] = ne[che[v]];
  }
  return 0;
}

int Phase()
{
  cc++;
  qst = qen = 0;
  q[qen++] = 1, u[1] = cc, d[1] = 0;
  while (qst < qen)
  {
    int x, v = q[qst++];
    for (int i = he[v]; i != -1; i = ne[i])
      if (c[i] > 0 && u[x = to[i]] != cc)
      {
        u[x] = cc, d[x] = d[v] + 1;
        pr[x] = i, q[qen++] = x;
      }
  }
  if (u[n] != cc)
    return 0;

  memcpy(che, he, sizeof(he));
  plen = 0, cc++;
  while (dfs(1, (int)1e9))
    res += gmi, plen = 0, cc++;
  return 1;
}

int main()
{
  freopen("flow.in", "r", stdin);
  freopen("flow.out", "w", stdout);

  memset(he, -1, sizeof(he));
  assert(scanf("%d%d", &n, &m) == 2);
  assert(1 <= n && n <= 500);
  assert(1 <= m && m <= 10000);
  while (m--)
  {
    int a, b, _c;
    assert(scanf("%d%d%d", &a, &b, &_c) == 3);
    assert(1 <= a && a <= n);
    assert(1 <= b && b <= n);
    assert(1 <= _c && _c <= (int)1e9);
    ne[e] = he[a], to[e] = b, c[e] = _c, he[a] = e++;
    ne[e] = he[b], to[e] = a, c[e] = 0, he[b] = e++;
  }

  memset(u, 0, sizeof(u)), cc = 1;
  while (Phase())
    ;

  printf("%Ld", res);
  return 0;
}
