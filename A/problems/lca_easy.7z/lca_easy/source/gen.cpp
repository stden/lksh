#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

#define R(A, B) ((A) + rand() % ((B) - (A) + 1))

int main( int argc, char *argv[] )
{
  int N = 1, K = atoi(argv[2]), P = atoi(argv[3]);

  srand(atoi(argv[1]));
  printf("%d\n", K);
  while (K--)
    if (rand() & 1)
      printf("ADD %d %d\n", R(1, max(1, N * P / 1000)), N + 1), N++;
    else
      printf("GET %d %d\n", R(1, N), R(1, N));
  return 0;
}
