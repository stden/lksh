#!/bin/sh

problemName=lca

echo "compile.."
g++ -O2 -Wall -o gen gen.cpp || exit 1
g++ -O2 -Wall -o gen2 gen2.cpp || exit 1

echo -n "generate tests"
cp 01{.manual,} || exit 1
./gen 301703 100 100 > 02 || exit 1
./gen 401703 100 500 > 03 || exit 1
./gen 501703 100 900 > 04 || exit 1
./gen2 301703 100 100 > 05 || exit 1
./gen2 401703 100 500 > 06 || exit 1
./gen2 501703 100 900 > 07 || exit 1
./gen2 239017 450 500 > 08 || exit 1
./gen2 339017 450 100 > 09 || exit 1
./gen2 439017 450 10 > 10 || exit 1
./gen2 539017 1000 1 > 11 || exit 1
echo ""

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

