#include <testlib.h>
#include <set>

const int maxk = 1000;
const int maxq = 1000;
const int n = 1000;

int main() {
  using std::set;
  using std::string;
  registerValidation();
  int k = inf.readInt(1, maxk);
  inf.readEoln();
  set <int> was;
  was.insert(1);
  int cnt1 = 0, cnt2 = 0;
  for (int i = 0; i < k; i++) {
    string s = inf.readToken();
    ensuref(s == "ADD" || s == "GET", "неизвестный запрос: «%s»", s.c_str());
    inf.readSpace();
    int a = inf.readInt(1, n);
    inf.readSpace();
    int b = inf.readInt(1, n);
    inf.readEoln();
    if (s == "ADD") {
      ensuref(++cnt1 <= maxq, "слишком много запросов ADD");
      ensuref(was.count(a) == 1 && was.count(b) == 0, "неправильный запрос ADD(%d, %d)", a, b);
      was.insert(b);
    } else if (s == "GET") {
      ensuref(++cnt2 <= maxq, "слишком много запросов GET");
      ensuref(was.count(a) == 1 && was.count(b) == 1, "неправильный запрос GET(%d, %d)", a, b);
    }
  }
  inf.readEof();
  return 0;
}

