#include <stdio.h>
#include <string.h>
#include <algorithm>

using namespace std;

//#pragma comment (linker, "/STACK:20000000")

#define MAX 520010
#define MAXT 524288

int K, E = 0, He[MAX], Ne[MAX], Y[MAX];
int N = 0, A[MAX], B[MAX], T = 0, P[MAX], F[MAX], V[MAX];
int TrN = 0, Tr[MAXT * 2];

void dfs( int v  )
{
  int e;
  F[v] = T, V[T++] = v;
  P[v] = TrN, Tr[MAXT + TrN++] = F[v];
  for (e = He[v]; e != -1; e = Ne[e]) 
    dfs(Y[e]), Tr[MAXT + TrN++] = F[v];
}

int Get( int a, int b )
{
  int res = (int)1e9;
  a += MAXT, b += MAXT;
  while (a <= b)
  {
    if (a & 1)    res = min(res, Tr[a++]);
    if (!(b & 1)) res = min(res, Tr[b--]);
    if (a > b)
      break;
    a >>= 1, b >>= 1;
  }
  return res;
}

int Lca( int a, int b )
{
  return V[Get(min(P[a], P[b]), max(P[a], P[b]))];
}

int main( void )
{
  char s[9];
  int i, a, b;

  freopen("lca.in", "rt", stdin);
  freopen("lca.out", "wt", stdout);
  scanf("%d", &K);
  memset(He, -1, sizeof(He));
  for (i = 0; i < K; i++)
  {
    scanf("%s%d%d", s, &a, &b);
    if (strcmp(s, "ADD") == 0)
      Ne[E] = He[a], Y[E] = b, He[a] = E++;
    else
      A[N] = a, B[N++] = b;
  }
  dfs(1);
  for (i = MAXT - 1; i > 0; i--)
    Tr[i] = min(Tr[i + i], Tr[i + i + 1]);
  for (i = 0; i < N; i++)
    printf("%d\n", Lca(A[i], B[i]));
  return 0;
}
