#include <stdio.h>
#include <string.h>

#define MAX 520010

int K, E = 0, Pr[MAX];
int N = 0, A[MAX], B[MAX];
int PAN, PA[MAX], PBN, PB[MAX];

int countx = 0;

int Lca( int a, int b )
{
  int i;

  PAN = PBN = 0;
  PA[PAN++] = -1, PB[PBN++] = -2;
  for (i = a; i != -1; i = Pr[i])
    PA[PAN++] = i, countx++;
  for (i = b; i != -1; i = Pr[i])
    PB[PBN++] = i, countx++;
  while (PA[PAN - 2] == PB[PBN - 2])
    PAN--, PBN--;
  return PA[PAN - 1];
}

int main( void )
{
  char s[9];
  int i, a, b;

  freopen("lca.in", "rt", stdin);
  freopen("lca2.out", "wt", stdout);
  scanf("%d", &K);
  Pr[1] = -1;
  for (i = 0; i < K; i++)
  {
    scanf("%s%d%d", s, &a, &b);
    if (strcmp(s, "ADD") == 0)
      Pr[b] = a;
    else
      A[N] = a, B[N++] = b;
  }
  for (i = 0; i < N; i++)
    printf("%d\n", Lca(A[i], B[i]));
  fprintf(stderr, "%d\n", countx);
  return 0;
}
