#include <testlib.h>

const int maxn = 100;
const int maxc = 1000;
const int maxv = 1000;
const int maxd = 10000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxn);
  inf.readEoln();
  int x1[n], y1[n], c[n];
  int x2[m], y2[m], d[n];
  int e[n][m];
  for (int i = 0; i < n; i++) {
    x1[i] = inf.readInt(-maxc, maxc);
    inf.readSpace();
    y1[i] = inf.readInt(-maxc, maxc);
    inf.readSpace();
    c[i] = inf.readInt(1, maxv);
    inf.readEoln();
  }
  for (int i = 0; i < m; i++) {
    x2[i] = inf.readInt(-maxc, maxc);
    inf.readSpace();
    y2[i] = inf.readInt(-maxc, maxc);
    inf.readSpace();
    d[i] = inf.readInt(1, maxv);
    inf.readEoln();
  }
  for (int i = 0; i < n; i++)
    for (int j = 0; j < m; j++) {
      e[i][j] = inf.readInt(0, maxd);
      if (j == m - 1)
        inf.readEoln();
      else
        inf.readSpace();
      c[i] -= e[i][j];
      d[j] -= e[i][j];
    }
  inf.readEof();
  for (int i = 0; i < n; i++)
    ensuref(c[i] == 0, "из здания №%d эвакуировали не всех", i + 1);
  for (int j = 0; j < m; j++)
  ensuref(d[j] >= 0, "бомбоубежище №%d переполнено", j + 1);
  return 0;
}

