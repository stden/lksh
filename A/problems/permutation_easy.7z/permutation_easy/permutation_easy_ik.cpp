#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define TASKNAME "permutation"

const int MaxN = 100006, LogK = 9, MaxK = 1 << LogK, AndK = MaxK - 1;

int a [MaxK + 1] [MaxK + 1];
int p [MaxN], q [MaxN];
int m, n;

int main (void)
{
 int i, j, k, l, x, y, cur;
 freopen (TASKNAME ".in", "rt", stdin);
 freopen (TASKNAME ".out", "wt", stdout);
 while (scanf (" %d %d", &n, &m) == 2)
 {
  assert (1 <= n && n <= 100);
  assert (1 <= m && m <= 100);
  for (i = 0; i < n; i++)
   if (scanf (" %d", &p[i]) != 1) assert (false);
  for (i = 0; i < n; i++)
   p[i]--;
  for (i = 0; i < n; i++)
   assert (0 <= p[i] && p[i] < n);
  memset (q, -1, sizeof (q));
  for (i = 0; i < n; i++)
   q[p[i]] = i;
  for (i = 0; i < n; i++)
   assert (q[i] != -1);

  memset (a, 0, sizeof (a));
  for (i = 0; i < n; i++)
  {
   k = i >> LogK;
   l = p[i] >> LogK;
   for (j = 0; j <= l; j++)
    a[k][j]++;
  }

  for (i = 0; i < m; i++)
  {
   if (scanf (" %d %d %d %d", &x, &y, &k, &l) != 4) assert (false);
   x--; k--;
   assert (0 <= x && x < y && y <= n);
   assert (0 <= k && k < l && l <= n);

   cur = 0;
   while (x < y && (x & AndK))
   {
    cur += (k <= p[x] && p[x] < l);
    x++;
   }
   while (x < y && (y & AndK))
   {
    y--;
    cur += (k <= p[y] && p[y] < l);
   }
   while (k < l && (k & AndK))
   {
    cur += (x <= q[k] && q[k] < y);
    k++;
   }
   while (k < l && (l & AndK))
   {
    l--;
    cur += (x <= q[l] && q[l] < y);
   }

   k >>= LogK; l >>= LogK;
   for (x >>= LogK, y >>= LogK; x < y; x++)
   {
    cur += a[x][k] - a[x][l];
   }
   printf ("%d\n", cur);
  }
 }
 return 0;
}
