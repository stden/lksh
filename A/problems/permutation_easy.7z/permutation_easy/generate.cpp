#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace std;

int seed;

int main()
{
	freopen("seed.txt", "r", stdin);
	scanf("%d", &seed);
	srand(seed);
	freopen("permutation.in", "w", stdout);
	printf("1000 1000\n");
	vector<int> a;
	for (int i = 0; i < 1000; i++)
		a.push_back(i + 1);
	random_shuffle(a.begin(), a.end());
	for (int i = 0; i < 1000; i++)
		printf("%d ", a[i]);
	printf("\n");
	for (int i = 0; i < 1000; i++)
	{
		int a, b, c, d;
		do
		{
			a = rand() % 1000 + 1;
			b = rand() % 1000 + 1;
			c = rand() % 1000 + 1;
			d = rand() % 1000 + 1;
		}
		while (a > b || c > d);
		printf("%d %d %d %d\n", a, b, c, d);
	}
	freopen("seed.txt", "w", stdout);
	printf("%d\n", rand());
	return 0;
}
