#include <testlib.h>

const int maxn = 100;
const int maxk = 100;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxn);
  inf.readSpace();
  int k = inf.readInt(1, maxn);
  inf.readEoln();
  int a[n];
  memset(a, 0, sizeof(a));
  for (int i = 0; i < n; i++) {
    int t = inf.readInt(1, n);
    ensuref(a[t - 1]++ == 0, "число %d повторяется дважды", t);
    if (i == n - 1)
      inf.readEoln();
    else
      inf.readSpace();
  }
  for (int i = 0; i < k; i++) {
    int x = inf.readInt(1, n);
    inf.readSpace();
    inf.readInt(x, n);
    inf.readSpace();
    int a = inf.readInt(1, n);
    inf.readSpace();
    inf.readInt(a, n);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

