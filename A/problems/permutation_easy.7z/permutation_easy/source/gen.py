#!/usr/bin/python

import random
random.seed (11238)

MinN = 1
MaxN = 100
MinM = 1
MaxM = 100
test = 3

def genrandom (n, m):
	p = range (n)
	random.shuffle (p)
	for i in range (n):
		p[i] += 1
	q = []
	for i in range (m):
		x = random.randrange (1, n)
		y = random.randrange (1, n)
		if x > y:
			x, y = y, x
		k = random.randrange (1, n)
		l = random.randrange (1, n)
		if k > l:
			k, l = l, k
		q.append ([x, y, k, l])
	return p, q

def genmax (n, m, d):
	p = range (n)
	random.shuffle (p)
	for i in range (n):
		p[i] += 1
	q = []
	for i in range (m):
		x = random.randrange (1, d)
		y = random.randrange (n - d + 1, n)
		k = random.randrange (1, d)
		l = random.randrange (n - d + 1, n)
		q.append ([x, y, k, l])
	return p, q

def tilt (z, k):
	p, q = z
	n = len (p)
	p = range (n)
	for i in range (k):
		x = random.randrange (1, n - 1)
		y = random.randrange (1, n - x)
		if y >= x:
			y += 1
		p[x], p[y] = p[y], p[x]
	for i in range (n):
		p[i] += 1
	return p[::-1], q
		

def invert (z):
	p, q = z
	n = len (p)
	return p, q

def out (z):
	p, q = z
	n = len (p)
	assert (MinN <= n <= MaxN)
	m = len (q)
	assert (MinM <= m <= MaxM)
	for i in range (m):
		assert (1 <= q[i][0] <= q[i][1] <= n)
		assert (1 <= q[i][2] <= q[i][3] <= n)

	s = '%d %d\n' % (n, m)
	for i in range (n):
		s += '%d' % p[i]
		if i + 1 < n:
			s += ' '
	s += '\n'
	for i in range (m):
		s += '%d %d %d %d\n' % (q[i][0], q[i][1], q[i][2], q[i][3])

	global test
	test += 1
	print 'Generating test %02d' % test
	f = open ('%02d' % test, 'wt')
	f.write (s)
	f.close ()

out (genrandom (10, 10))
out (genrandom (10, 10))
out (genrandom (10, 100))
out (genrandom (10, 100))
out (genrandom (100, 100))
out (genrandom (100, 100))
out (genmax (100, 100, 50))
