#!/bin/bash

for i in *.hnd; do
  cp "$i" "${i/\.hnd/}"
done

./gen.py

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

