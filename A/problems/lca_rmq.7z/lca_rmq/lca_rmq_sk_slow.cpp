#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>

using namespace std;

#if (defined(WIN32) || !defined(__GNUC__))
#  define I64 "%I64d"
#else
#  define I64 "%Ld"
#endif

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

typedef vector <int> vi;
typedef long long ll;

#define maxn 100010

int n, m, pr[maxn];
int x, y, z, a1, a2;

int ans = 0;
ll sum = 0;

void GetP( vi &v, int x )
{
  while (x != -1)
    v.push_back(x), x = pr[x];
}

void Solve( int v, int u )
{
  vi p1, p2;
  GetP(p1, v), GetP(p2, u);

  int i = p1.size() - 1, j = p2.size() - 1;
  while (i >= 1 && j >= 1 && p1[i - 1] == p2[j - 1])
    i--, j--;

  sum += (ans = p1[i]);
//  fprintf(stderr, "%d,%d --> %d\n", v, u, ans);
}

int main()
{
  freopen("lca_rmq.in", "r", stdin);
  freopen("lca_rmq.out", "w", stdout);

  scanf("%d%d", &n, &m);
  pr[0] = -1;
  for (int i = 1; i < n; i++)
    scanf("%d", &pr[i]);

  scanf("%d%d%d%d%d", &a2, &a1, &x, &y, &z);
  while (m--)
  {
    Solve((ans + a2) % n, a1);
    forn(w, 2)
    {
      int a0 = ((ll)x * a2 + (ll)y * a1 + z) % n;
      a2 = a1, a1 = a0;
    }
  }

  printf(I64 "\n", sum);
  return 0;
}
