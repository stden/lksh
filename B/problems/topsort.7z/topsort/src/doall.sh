#!/bin/bash

g++ -o gen_line gen_line.cpp
g++ -o gen_good gen_good.cpp
g++ -o gen_random gen_random.cpp

./gen_random 123     15      20      > 10
./gen_random 321     20      40      > 11
./gen_random 233     30      60      > 12
./gen_random 517     100     200     > 13
./gen_random 1676    1000    2000    > 14
./gen_random 8163    1000    5000    > 15
./gen_random 6817    5000    20000   > 16
./gen_random 5433    10000   50000   > 17
./gen_random 2345    50000   100000  > 18
./gen_line           9999            > 19
./gen_good   6146    100000  100000  > 20

mv ?? ../tests
for i in ??.manual 
do
	cp $i ../tests/${i/\.manual/}
done
