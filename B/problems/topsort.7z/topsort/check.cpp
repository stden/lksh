#include "testlib.h"

struct edge {
  int a, b;
};

const int maxE = 100000;
const int maxV = 100000;

int n, k;
edge e[maxE];
int o[maxV];

bool check( InStream &in, TResult err ) {
  for (int i = 0; i < n; i++) {
    o[i] = -1;
  }
  int t = in.readInt();
  if (t == -1) {
    return false;
  }
  if (t < 1 || t > n) {
    quitf(err, "Vertex index %d out of bounds [1..n=%d]", t, n);
  }
  o[t - 1] = 0;
  for (int i = 1; i < n; i++) {
    t = in.readInt(1, n);
    if (o[t - 1] != -1) {
      quitf(err, "Duplicate vertex %d", t);
    }
    o[t - 1] = i;
  }
  for (int i = 0; i < k; i++) {
    if (o[e[i].a - 1] >= o[e[i].b - 1]) {
      quitf(err, "Backward edge %d->%d", e[i].a, e[i].b);
    }
  }
  return true;
}

int main( int argc, char *argv[] ) {
  registerTestlibCmd(argc, argv);
  n = inf.readInt();
  k = inf.readInt();
  for (int i = 0; i < k; i++) {
    e[i].a = inf.readInt();
    e[i].b = inf.readInt();
  }
  bool ja = check(ans, _fail);
  bool pa = check(ouf, _wa);
  if (ja && !pa) {
    quitf(_wa, "n=%d k=%d Ordering exists but not found", n, k);
  } else if (ja && pa) {
    quitf(_ok, "n=%d k=%d Ordering exists", n, k);
  } else if (!ja && pa) {
    quitf(_fail, "n=%d k=%d Ordering was not found by jury", n, k);
  } else {
    quitf(_ok, "n=%d k=%d Ordering does not exist", n, k);
  }
  return -1;
}
