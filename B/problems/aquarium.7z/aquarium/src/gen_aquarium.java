import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class gen_aquarium {

	public static void main(String[] args) throws IOException {
		Random rand = new Random(97324873);
		for (int test = 0; test < 50; test++) {
			PrintWriter out = new PrintWriter(((test + 1) < 10 ? "0" : "")
					+ (test + 1));
			switch (test) {
			case 0:
				out.println("5");
				out.println("0 183 163 173 181");
				out.println("183 0 165 172 171");
				out.println("163 165 0 189 302");
				out.println("173 172 189 0 167");
				out.println("181 171 302 167 0");
				break;

			default:
				int n = test % 13 + 1;
				int[][] a = new int[n][n];
				for (int i = 0; i < a.length; i++) {
					for (int j = 0; j < i; j++) {
						a[i][j] = test > 23 ? rand.nextInt(1000001) : rand
								.nextInt(99);
						a[j][i] = a[i][j];
					}
				}
				out.println(n);
				for (int i = 0; i < a.length; i++) {
					for (int j = 0; j < a[i].length; j++) {
						if (j > 0) {
							out.print(" ");
						}
						out.print(a[i][j]);
					}
					out.println();
				}
				break;
			}
			out.close();
		}
	}

}
