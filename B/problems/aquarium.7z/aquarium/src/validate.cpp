#include "testlib.h"
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <iostream>

using namespace std;

int main()
{
  registerValidation();
  int n = inf.readInt(1, 13);
  inf.readEoln();

  for(int i = 0; i < n; i ++)
  {
    for(int j = 0; j < n; j ++)
    {
      int val = inf.readInt(0, 1000000);
      if (i == j)
        ensure(val == 0);
      if (j < n - 1) 
      {
        inf.readSpace();
      }
    }
    inf.readEoln();
  }
  inf.readEof();
}
