#include <cstdio>

int main() {
  int n = 13;
  int a[n][n];
  int cnt = n * n;
  for (int i = 0; i < n; i++) {
    a[i][i] = 0;
    for (int j = i + 1; j < n; j++) {
      a[i][j] = a[j][i] = cnt--;
    }
  }
  printf("%d\n", n);
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      printf("%d%c", a[i][j], " \n"[j + 1 == n]);
    }
  }
  return 0;
}
