#! /bin/bash

mkdir ../tests
javac gen_aquarium.java
mv gen_aquarium.class ../tests/
g++ -O2 -Wall -o ../tests/gen gen.cpp
cd ../tests
./gen > 51
java gen_aquarium
rm *.class
rm gen
cd ../src
