import java.io.*;
import java.util.*;
import java.math.*;

public class aquarium_aa implements Runnable {

	public static void main(String[] args) {
		new Thread(new aquarium_aa()).start();
	}

	BufferedReader br;

	StringTokenizer st;

	PrintWriter out;

	boolean eof = false;

	Random rand = new Random(this.hashCode());

	public void run() {
		try {
			br = new BufferedReader(new FileReader(FNAME + ".in"));
			out = new PrintWriter(FNAME + ".out");
			solve();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(566);
		}
		out.close();
	}

	String nextToken() {
		while (st == null || !st.hasMoreTokens()) {
			try {
				st = new StringTokenizer(br.readLine());
			} catch (Exception e) {
				eof = true;
				return "0";
			}
		}
		return st.nextToken();
	}

	int nextInt() {
		return Integer.parseInt(nextToken());
	}

	long nextLong() {
		return Long.parseLong(nextToken());
	}

	double nextDouble() {
		return Double.parseDouble(nextToken());
	}

	BigInteger nextBigInteger() {
		return new BigInteger(nextToken());
	}

	void MyAssert(boolean u, String message) {
		if (!u) {
			throw new Error("Assertion failed!!! " + message);
		}
	}

	int inBounds(int x, int l, int r, String name) {
		MyAssert(l <= x && x <= r, name + " is not in bounds!!! " + x
				+ " not in [" + l + ".." + r + "]");
		return x;
	}

	String FNAME = "aquarium_aa".substring(0, "aquarium_aa".indexOf("_"));

	private void solve() throws IOException {
		int n = nextInt();
		int[][] a = new int[n][n];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				a[i][j] = nextInt();
			}
		}
		int[][] b = new int[1 << n][n];
		int[][] p = new int[1 << n][n];
		for (int i = 0; i < b.length; i++) {
			Arrays.fill(b[i], Integer.MAX_VALUE / 2);
			Arrays.fill(p[i], -1);
		}
		for (int i = 0; i < n; i++) {
			b[1 << i][i] = 0;
		}
		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b[i].length; j++) {
				if ((i & (1 << j)) != 0) {
					for (int k = 0; k < b[i].length; k++) {
						if ((i & (1 << k)) == 0) {
							if (b[i | (1 << k)][k] > b[i][j] + a[j][k]) {
								b[i | (1 << k)][k] = b[i][j] + a[j][k];
								p[i | (1 << k)][k] = j;
							}
						}
					}
				}
			}
		}
		int ansi = 0;
		int prof = (1 << n) - 1;
		for (int i = 0; i < b[prof].length; i++) {
			if (b[prof][i] < b[prof][ansi]) {
				ansi = i;
			}
		}
		ArrayList<Integer> ans = new ArrayList<Integer>();
		out.println(b[prof][ansi]);
		while (ansi >= 0) {
			ans.add(ansi);
			int nprof = prof ^ (1 << ansi);
			ansi = p[prof][ansi];
			prof = nprof;
		}
		Collections.reverse(ans);
		for (int i : ans) {
			out.print((i + 1) + " ");
		}
	}
}
