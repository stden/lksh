#include "testlib.h"
#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
//  freopen("log", "w", stderr);
  
  registerValidation();
  
  int n = inf.readInt(1, 30);
  inf.readEoln();
  int bal = 0;
  
  for(int i = 0; i < n * 2; i ++)
  {
    char c = inf.readChar();
    ensure(c == '(' || c == ')');
    if (c == '(') 
      bal ++;
    else
      bal --;
    ensure(bal >= 0);
  }
  
//  cerr << "OK" << endl;
  ensure(bal == 0);
  inf.readEoln();
  inf.readEof();
}
