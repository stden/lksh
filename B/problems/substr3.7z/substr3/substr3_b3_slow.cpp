#include <cstdio>
#include <cstring>

#define maxn 15
#define maxl 10010

int n, len[maxn];
char s[maxn][maxl], t[maxl];

int main()
{
  freopen("substr3.in", "r", stdin);
  freopen("substr3.out", "w", stdout);

  scanf("%d", &n);
  for (int i = 0; i < n; i++)
    scanf("%s", s[i]), len[i] = strlen(s[i]);
  int start = 0, length = 0;
  for (int ll = 1; ll <= len[0]; ll++)
    for (int st = 0; st + ll <= len[0]; st++)
    {
      for (int i = 0; i < ll; i++)
        t[i] = s[0][st + i];
      t[ll] = '\0';
      bool good = true;
      for (int i = 0; i < n; i++)
      {
        good = false;
        for (int j = 0; j + ll <= len[i]; j++)
        {
          good = true;
          for (int k = 0; k < ll; k++)
            if (s[i][j + k] != t[k])
              good = false, k = ll;
          if (good)
            break;
        }
        if (!good)
          break;
      }
      if (good)
      {
        start = st, length = ll;
        break;
      }
    }
  s[0][start + length] = '\0';
  puts(s[0] + start);

  return 0;
}

