#include <cstdio>
#include <cstring>

#include <algorithm>

using namespace std;

typedef unsigned long long ull;

#define maxk 11
#define maxl 10010
#define maxh 300000
#define P 239017

int k;
char s[maxk][maxl];
int len[maxk];
ull p[maxk][maxl], pp[maxl];
int col, c[maxh], st[maxh], cnt[maxh], start;
ull hh[maxh];

bool test( int length )
{
  ++col;
  for (int i = 0; i < k; i++)
  {
    for (int j = 0; j + length <= len[i]; j++)
    {
      ull hash = p[i][j + length] - p[i][j] * pp[length];
      int hpos = (unsigned int)hash % maxh;
      while (c[hpos] == col && hh[hpos] != hash)
        if (++hpos == maxh)
          hpos = 0;
      if (c[hpos] != col)
        c[hpos] = col, hh[hpos] = hash, cnt[hpos] = 0, st[hpos] = j;
      cnt[hpos] |= (1 << i);
    }
  }
  start = -1;
  for (int i = 0; i < maxh; i++)
    if (c[i] == col && cnt[i] == (1 << k) - 1)
      start = st[i];
  return start != -1;
}

int main()
{
  freopen("substr3.in", "r", stdin);
  freopen("substr3.out", "w", stdout);

  memset(c, 0, sizeof(c));
  scanf("%d", &k);
  for (int i = 0; i < k; i++)
    scanf("%s", s[i]), len[i] = strlen(s[i]);
  int minLen = maxl;
  for (int i = 0; i < k; i++)
  {
    p[i][0] = 0;
    minLen = min(minLen, len[i]);
    for (int j = 0; j < len[i]; j++)
      p[i][j + 1] = p[i][j] * P + s[i][j];
  }
  pp[0] = 1;
  for (int i = 1; i < maxl; i++)
    pp[i] = pp[i - 1] * P;

  int lmin = 0, lmax = minLen;
  while (lmin < lmax)
  {
    int lave = (lmin + lmax + 1) / 2;
    if (test(lave))
      lmin = lave;
    else
      lmax = lave - 1;
  }
  test(lmin);
//  fprintf(stderr, "[debug] lmin = %d\n", lmin);
  s[0][start + lmin] = 0;
  puts(s[0] + start);
  
  return 0;
}

