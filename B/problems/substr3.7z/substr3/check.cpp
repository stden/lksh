#include "testlib.h"

int n;
std::string s[10];

bool check( std::string g )
{
  for (int i = 0; i < n; i++)
    if (s[i].find(g) >= s[i].length())
      return false;
  return true;
}

int main(int argc, char * argv[])
{
    setName("checker for problem “substr3”");
    registerTestlibCmd(argc, argv);

    std::string ja = ans.readWord();
    std::string pa = ouf.readWord();

    n = inf.readInt();
    for (int i = 0; i < n; i++)
      s[i] = inf.readWord();

    if (!check(ja))
      quitf(_fail, "Jury answer is incorrect.");
    if (!check(pa))
      quitf(_wa, "Contestant answer is incorrect.");
    if (pa.length() > ja.length())
      quitf(_fail, "Jury answer is not optimal.");
    if (pa.length() < ja.length())
      quitf(_wa, "Contestant answer is not optimal.");
    if (pa.length() <= 10)
      quitf(_ok, "answer is “%s”", pa.c_str());
    else
      quitf(_ok, "answer is “%s...” (%d characters)", pa.substr(0, 8).c_str(), pa.length());
}
