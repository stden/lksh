#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define m 30100
#define mk 11

char s[mk][m];
int z[m], l[mk], n;

void calcZ( char *s, int len, int *z )
{
  z[0] = 0;
  int l = 0, r = 0;
  for (int i = 1; i < len; i++)
  {
    z[i] = 0;
    if (r >= i)
      z[i] = min(r - i + 1, z[i - l]);
    while (i + z[i] < len && s[z[i]] == s[i + z[i]])
      z[i]++;
    if (i + z[i] - 1 > r)
      r = i + z[i] - 1, l = i;
  }
/*  for (int i = 0; i < len; i++)
    printf("%c|", s[i] ? s[i] : '$');
  puts("");
  for (int i = 0; i < len; i++)
    printf("%d|", z[i]);
  puts("");*/
}

int main()
{
  freopen("substr3.in", "r", stdin);
  freopen("substr3.out", "w", stdout);

  scanf("%d", &n);
  gets(s[0]);
  for (int i = 0; i < n; i++)
    gets(s[i]), l[i] = strlen(s[i]);
  int ans = 0, pos = 0;
  for (int st = 0; st < l[0]; st++)
  {
    s[0][l[0]] = 0;
    int mi = l[0] - st;
    for (int i = 1; i < n; i++)
    {
      int ma = 0;
      strcpy(s[0] + l[0] + 1, s[i]);
      calcZ(s[0] + st, l[0] + 1 + l[i] - st, z);
      for (int j = 0; j < l[i]; j++)
        ma = max(ma, z[l[0] - st + 1 + j]);
      if (ma < mi)
        mi = ma;
    }
    if (mi > ans)
      ans = mi, pos = st;
  }
  s[0][pos + ans] = 0;
  printf("%s\n", s[0] + pos);

  return 0;
}
