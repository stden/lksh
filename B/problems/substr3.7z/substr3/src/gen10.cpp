#include <cstdio>
#include <cstdlib>

#include "random.h"

#define m 10100

char a[m];

int main( int argc, char **argv )
{
  int n = 9;
  int ml = 2390;
  int al = 1111;
  initrand(239010);
  for (int i = 0; i < al; i++)
    a[i] = nextrand() % 26 + 'a';
  a[al] = 0;
  printf("%d\n", n);
  for (int i = 0; i < n; i++)
  {
    int left = nextrand() % (ml - 2 * al + 1);
    int b1 = nextrand() % (left + 1);
    left -= b1;
    int b2 = nextrand() % (left + 1);
    left -= b2;
    while (b1--)
      putc('a' + nextrand() % 26, stdout);
    if (i == 0)
      printf("%s", a);
    while (b2--)
      putc('a' + nextrand() % 26, stdout);
    if (i != n - 1)
      printf("%s", a);
    while (left--)
      putc('a' + nextrand() % 26, stdout);
    puts("");
  }
  return 0;
}
