#!/bin/sh

# template script for generating tests
# author: burunduk3 (Oleg Davydov)
# *** change log (please notice all changes here) ***
#  2009-08-18 changelog added

problemName=substr3
solutionRun=./solution.exe
# useful variants
# solutionRun=./key_as
# solutionRun=java -cp "../" key_as

./wipe.sh || exit 1
echo "stupid suffix “.exe” added for compatibility with outdated operation systems"
echo -n "compile.."
g++ -O2 -Wall -o validate.exe validate.cpp || exit 1
#g++ -O2 -Wall -o split.exe split.cpp || exit 1
#g++ -O2 -Wall -o gen.exe gen.cpp || exit 1
g++ -O2 -Wall -o solution.exe ../${problemName}_b3.cpp || exit 1
for i in `seq -w 02 15`; do
  echo -n "."
  g++ -O2 -Wall -o gen$i.exe gen$i.cpp || exit 1
done
echo ""
#...

echo -n "generate tests."
cp 01.manual 01 || exit 1
for i in `seq -w 02 15`; do
  echo -n "[$i]"
  ./gen$i.exe > $i || exit 1
done
echo ""

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

echo "done"

