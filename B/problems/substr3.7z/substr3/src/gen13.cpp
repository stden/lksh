#include <cstdio>
#include <cstdlib>

#include "random.h"

#define m 10100

int main( int argc, char **argv )
{
  int n = 10;
  int ml = 10000;
  initrand(3);
  printf("%d\n", n);
  for (int i = 0; i < n; i++)
  {
    int len = nextrand() % ml;
    while (len--)
      putc('a' + nextrand() % 26, stdout);
    puts("");
  }
  return 0;
}
