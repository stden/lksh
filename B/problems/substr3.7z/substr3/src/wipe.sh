#!/bin/sh

# template script for wiping after generating tests
# author: burunduk3 (Oleg Davydov)
# *** change log (please notice all changes here) ***
#  2009-08-18 changelog added

echo -n "wipe"

rm --force ?? ??? # TODO: regexp or something to rm only digits
# stupid suffix “.exe” added for compatibility with outdated operation systems.
rm --force *.{exe,o,a,in,out}

echo "!"

