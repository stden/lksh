#include <cstdio>
#include <cstdlib>

#include "random.h"

#define m 10100

char a[m];

int main( int argc, char **argv )
{
  int n = atoi(argv[1]);
  int ml = atoi(argv[2]);
  int al = atoi(argv[3]);
  initrand(atoi(argv[4]));
  for (int i = 0; i < al; i++)
    a[i] = nextrand() % 26 + 'a';
  printf("%d\n", n);
  for (int i = 0; i < n; i++)
  {
    int left = nextrand() % (ml - al);
    int bef = nextrand() % (left + 1);
    left -= bef;
    while (bef--)
      putc('a' + nextrand() % 26, stdout);
    for (int j = 0; j < al; j++)
      putc(a[j], stdout);
    while (left--)
      putc('a' + nextrand() % 26, stdout);
    puts("");
  }
  return 0;
}
