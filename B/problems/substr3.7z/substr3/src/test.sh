#!/bin/sh

solution=$1
checker=../check
problemName=substr3

echo "testing..."
for i in ??; do
  echo -n "[$i]"
  cp $i "$problemName.in" || exit 1
  $solution || exit 1
  $checker "$problemName.in" "$problemName.out" $i.a || exit 1
done
rm --force $problemName.{in,out}

