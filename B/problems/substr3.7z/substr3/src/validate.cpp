// template code for validating tests
// author: burunduk3 (Oleg Davydov)
// *** change log (please notice all changes here) ***
//  2009-08-18 changelog added

#include <cassert>
#include <cstdio>
#include <cstring>

#define maxn 10
#define maxl 10000

int n;
char s[maxl + 100];

int main( int argc, char *argv[] )
{
//  assert(argc == 2);
//  assert(freopen(argv[1], "r", stdin) != NULL);
  assert(scanf("%d", &n) == 1);
  assert(1 <= n && n <= 10);
  assert(fgets(s, maxl + 5, stdin) == s);
  assert(s[0] == '\n');
  for (int i = 0; i < n; i++)
  {
    assert(fgets(s, maxl + 5, stdin) == s);
    int len = strlen(s);
    s[len] = '\0', len--;
    assert(1 <= len && len <= maxl);
    for (int j = 0; j < len; j++)
      assert('a' <= s[j] && s[j] <= 'z');
  }
  return 0;
}

