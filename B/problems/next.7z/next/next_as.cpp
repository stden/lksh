#define _CRT_SECURE_NO_DEPRECATE
#include <cstdio>
#include <set>
using namespace std;

set<int> S;

int main(){
  freopen("next.in", "r", stdin);
  freopen("next.out", "w", stdout);
  int i, n, a, b = 0;
  char ch;
  scanf("%d\n", &n);
  for (i=0; i<n; i++){
    scanf("%c%d\n", &ch, &a);
    if (ch == '+'){
      S.insert((a+b)%1000000000);
      b = 0;
    }
    else{
      set<int>::iterator iter = S.lower_bound(a);
      if (iter == S.end()) b = -1;
      else b = *iter;
      printf("%d\n", b);
    }
  }
  return 0;
}