#include "testlib.h"

int main(){
  registerValidation();

  int n = inf.readInt(1, 300000);
  inf.readEoln();

  for(int i = 0; i < n; i ++){
    char c = inf.readChar();
    inf.readSpace();
    int query = inf.readInt(0, 1000000000);
    inf.readEoln();

    ensure(c == '+' || c == '?');   
  }
  inf.readEof();
}
