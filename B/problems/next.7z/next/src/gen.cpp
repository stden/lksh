#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

//long long Time()
//{
//  asm("rdtsc");
//}

unsigned R( unsigned A, unsigned B )
{
  return A + ((rand() << 15) + rand()) % (B - A + 1);
}

int main( int argc, char *argv[] )
{
  int seed = atoi(argv[1]), n = atoi(argv[2]), c = atoi(argv[3]);

  // seed - base for random (0 means Time())
  // n - number of queries
  // c - range of all numbers in input will be [0..c]

//  srand(seed ? seed : Time());
  printf("%d\n", n);
  while (n--)
    if (rand() % 10 < 3)
      printf("? %d\n", R(0, c));
    else
      printf("+ %d\n", R(0, c));
  return 0;
}

