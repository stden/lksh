#! /bin/bash

rm -rf ../tests
mkdir ../tests

cp 01.hand ../tests/01

g++ -O2 -o ../tests/gen gen.cpp

cd ../tests

g++ -O2 -o solve ../next_as.cpp

./gen 1000001 30 100 > 02
./gen 1000002 100 1000000000 > 03
./gen 1000003 300 1000000000 > 04
./gen 1000004 1000 1000000000 > 05
./gen 1000005 3000 1000000000 > 06
./gen 1000006 10000 1000000000 > 07
./gen 1000007 30000 1000000000 > 08
./gen 1000008 100000 1000000000 > 09
./gen 1000009 300000 1000000000 > 10

for i in ??; do
	cp $i next.in
	./solve
	mv next.out $i.a;
done

rm next.in solve gen
