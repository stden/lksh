#include <cassert>
#include <cstdio>
#include <cstdlib>

#if (defined(WIN32) || !defined(__GNUC__))
#  define I64 "%I64d"
#else
#  define I64 "%Ld"
#endif

#define MOD (int)1e9

typedef long long ll;

struct tree 
{
  int x, si, xmi, xma;
  ll sum;
  tree *l, *r;
};

#define maxt 1000010

tree mem[maxt];
int mpos = 0;

void Calc( tree *t )
{
  if (!t)
    return;
  t->si = 1, t->sum = t->x;
  if (t->l)
    t->si += t->l->si, t->sum += t->l->sum;
  if (t->r)
    t->si += t->r->si, t->sum += t->r->sum;
}

tree *NewT( int x )
{
  tree *t = &mem[mpos++];
  t->x = x;
  t->l = t->r = 0;
  Calc(t);
  return t;
}

void Split( tree *t, tree **l, tree **r, int x )
{
  if (!t)
    *l = *r = 0;
  else if (t->x < x)
    *l = t, Split(t->r, &t->r, r, x);
  else
    *r = t, Split(t->l, l, &t->l, x);
  Calc(*l), Calc(*r);  
}

void Add( tree **t, int x )
{
  if (!*t)
    *t = NewT(x);
  else if (rand() % ((*t)->si + 1) != 0)
    if ((*t)->x > x)
      Add(&(*t)->l, x);
    else
      Add(&(*t)->r, x);
  else
  {
    tree *l, *r;
    Split(*t, &l, &r, x);
    *t = NewT(x);
    (*t)->l = l, (*t)->r = r;
  }
  Calc(*t);
}

int Find( tree *t, int x )
{
  if (!t)
    return 0;
  if (t->x == x)
    return 1;
  return Find(t->x > x ? t->l : t->r, x);
}

void AddF( tree **t, int x )
{
  if (!Find(*t, x))
    Add(t, x);
}

ll Get( tree *t, int i )
{
  if (!t) return MOD;
  ll x, y;
  if (t->x >= i)
  {
    x = t->x;
    y = Get(t->l, i);
    return(x < y ? x : y);
  }
  else return(Get(t->r, i));
}

void Out( tree *t, int dep )
{
  if (!t)
    return;
  Out(t->l, dep + 1);
  fprintf(stderr, "%*s(x=%d,si=%d,sum=%I64d)\n", dep * 2, "", t->x, t->si, t->sum);
  Out(t->r, dep + 1);
}

int main()
{
  tree *root = 0;
  int n;

  freopen("next.in", "r", stdin);
  freopen("next.out", "w", stdout);

  scanf("%d", &n);
  assert(1 <= n && n <= 300000);

  ll y = 0;
  while (n--)
  {
    char ch;
    scanf(" %c", &ch);
    if (ch == '+')
    {
      int a;
      scanf("%d", &a);
      AddF(&root, (a + y + MOD) % MOD);
      y = 0;
    }
    else
    {
      int i;
      scanf("%d", &i);
      assert(0 <= i && i <= MOD);

      y = Get(root, i);
      if (y == MOD) y = -1;
      printf("%Ld\n", y);
    }
  }
  return 0;
}
