#!/bin/bash

fpc generate.dpr
./generate

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

