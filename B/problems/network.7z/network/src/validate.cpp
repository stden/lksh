#include "testlib.h"
#include <string>
#include <cstdio>
#include <cstdlib>
#include <iostream>

using namespace std;

const int MAXN = 18;

int main()
{
  registerValidation();

  int n = inf.readInt(1, MAXN);
  inf.readEoln();

  for (int i = 0; i < n; ++i)
  {
  	string s = inf.readWord("[YN]*");
  	ensure(s.length() == n);
  	ensure(s[i] == 'N');
  	inf.readEoln();
  }

  inf.readEof();
}
