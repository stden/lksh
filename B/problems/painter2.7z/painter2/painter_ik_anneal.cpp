// simulated annealing solution
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
// #include <sys/time.h>

// #define DO0
// #define TASKNAME "painter"

using namespace std;

typedef double real;
const real RandMult = 1.0 / (RAND_MAX + 1.0);
#define rndvalue_ex() (rand () * RandMult)
#define rndvalue(x) (rand () % (x))
#define initrand(x) (srand ((x)))

const int MinN = 1, MaxN = 300, AndStepReport = 15;
const int MinC = -1000000000, MaxC = 1000000000;
const int TL = int (1.9 * CLOCKS_PER_SEC);

int a [MaxN], b [MaxN], p [MaxN], z [MaxN], u [MaxN], v [MaxN];
int ans, cur, n, starttime;

inline int gettime (void)
{
 return clock ();
//  timeval ct;
//  gettimeofday (&ct, NULL);
//  return ct.tv_sec * 1000 * 1000 + ct.tv_usec - starttime;
}

inline int score (void)
{
 int res, i, j, k;
 res = 0;
 for (i = 0; i < n; i++)
 {
  k = a[i];
  for (j = 0; j < n && a[j] <= k && k < b[i]; j++)
   if (v[j] > v[i] && k < b[j])
    k = b[j];
  if (k < b[i])
   res++;
 }
 return res;
}

inline void check_max (void)
{
 if (ans < cur)
 {
  ans = cur;
  memmove (z, u, sizeof (z));
#ifdef DO0
  int i;
  fprintf (stderr, "New maximum found: %d!\n", cur);
  for (i = 0; i < n; i++)
   fprintf (stderr, "%d%c", p[u[i]] + 1, i + 1 < n ? ' ' : '\n');
  fflush (stderr);
#endif
 }
}

int main (void)
{
 int i, j, old_cur;
//  freopen (TASKNAME ".in", "rt", stdin);
//  freopen (TASKNAME ".out", "wt", stdout);
 initrand (123);
 while (scanf (" %d", &n) != EOF)
 {
  starttime += gettime ();
  assert (MinN <= n && n <= MaxN);
  for (i = 0; i < n; i++)
  {
   scanf (" %d %d", &a[i], &b[i]);
   assert (MinC <= a[i] && a[i] < b[i] && b[i] <= MaxC);
  }
  for (i = 0; i < n; i++)
   p[i] = i;
  for (i = 0; i < n - 1; i++)
   for (j = i + 1; j < n; j++)
    if (a[i] > a[j] || a[i] == a[j] && b[i] > b[j])
    {
     swap (a[i], a[j]);
     swap (b[i], b[j]);
     swap (p[i], p[j]);
    }

  for (i = 0; i < n; i++)
   z[i] = i;
  ans = -1;
  for (i = 0; i < n; i++)
   u[i] = v[i] = i;
  cur = score ();
  check_max ();

  const real TempMin = 0.6;
  const real TempMax = 12.0;
  const real TempDiff = TempMax / TempMin;
  real temp;
  int acc, total;
  int curtime, step;
  acc = total = 0;
  temp = 0.0;
  for (step = 0; n > 1; step++)
  {
   if (!(step & AndStepReport))
   {
    curtime = gettime ();
    if (curtime > TL) break;
#ifdef DO0
    fprintf (stderr, "Step %d: temp = %10.6lf, stats %5d/%5d.\n",
     step, temp, acc, total);
    fflush (stderr);
#endif
    temp = TempMin * (pow (TempDiff, (real (curtime)) / TL));
    acc = total = 0;
   }

   i = rndvalue (n);
   j = rndvalue (n - 1);
   if (j >= i) j++;
   swap (u[i], u[j]);
   swap (v[u[i]], v[u[j]]);
   old_cur = cur;
   cur = score ();

   if (rndvalue_ex () >= exp ((cur - old_cur) * temp))
   {
    swap (u[i], u[j]);
    swap (v[u[i]], v[u[j]]);
    cur = old_cur;
   }
   else
   {
    acc++;
    check_max ();
   }
   total++;
  }
  printf ("%d\n", ans);
  for (i = 0; i < n; i++)
   printf ("%d%c", p[z[i]] + 1, i + 1 < n ? ' ' : '\n');
 }
 return 0;
}
