#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <map>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 300;
const int MAXC = 1000000000;

int n;
int l[MAXN], r[MAXN];
int maxc;

void Load()
{
	freopen("painter2.in","rt",stdin);
	freopen("painter2.out","wt",stdout);
	scanf("%d", &n);
	assert(1 <= n && n <= MAXN);
	int i;
	for (i = 0; i < n; i++)
	{
		scanf("%d%d", &l[i], &r[i]);
		assert(-MAXC <= l[i] && l[i] < r[i] && r[i] <= MAXC);
	}
	vector<int> havec;
	for (i = 0; i < n; i++)
	{
		havec.push_back(l[i]);
		havec.push_back(r[i]);
	}
	sort(havec.begin(), havec.end());
	havec.erase(unique(havec.begin(), havec.end()), havec.end());
	maxc = havec.size() - 1;
	map<int, int> remap;
	for (i = 0; i < havec.size(); i++) remap[havec[i]] = i;
	for (i = 0; i < n; i++)
	{
		l[i] = remap[l[i]];
		r[i] = remap[r[i]] - 1;
	}
}

int res[2 * MAXN][2 * MAXN];
int pth[2 * MAXN][2 * MAXN];
int num[2 * MAXN + 1];
int have[2 * MAXN][2 * MAXN];
int cdpt;

int Count(int ll, int rr)
{
	if (ll < 0 || rr > maxc || rr < ll) return 0;
	if (res[ll][rr] != -1) return res[ll][rr];
	//cerr << "Count(" << ll << "," << rr << ")\n";
	//int have[2 * MAXN];
	int i;
	for (i = ll; i <= rr; i++) { have[cdpt][i] = 0; num[i] = 0; }
	for (i = 0; i < n; i++)
	{
		if (l[i] >= ll && r[i] <= rr)
		{
			num[l[i]]++;
			num[r[i] + 1]--;
		}
	}
	int cnt = 0;
	for (i = ll; i <= rr; i++)
	{
		cnt += num[i];
		if (cnt != 0) have[cdpt][i] = 1;
	}
	res[ll][rr] = 0;
	pth[ll][rr] = -1;
	cdpt++;
	for (i = ll; i <= rr; i++)
	{
		int cur = Count(ll, i - 1);
		cur += Count(i + 1, rr);
		cur += have[cdpt - 1][i];
		if (cur > res[ll][rr])
		{
			res[ll][rr] = cur;
			pth[ll][rr] = i;
		}
	}
	cdpt--;
	//cerr << "Result: " << res[ll][rr] << " Path: " << pth[ll][rr] << "\n";
	return res[ll][rr];
}

int p[MAXN];
int was[MAXN];
int curord;

void RAns(int ll, int rr)
{
	if (ll < 0 || rr > maxc || ll > rr) return;
	if (res[ll][rr] == 0) return;
	//cerr << "RAns(" << ll << "," << rr << ")\n";
	int pos = pth[ll][rr];
	//cerr << "position = " << pos << "\n";
	int i;
	for (i = 0; i < n; i++)
	{
		if (was[i] == 1) continue;
		if (l[i] < ll || r[i] > rr) continue;
		if (l[i] <= pos && r[i] >= pos)
		{
			p[curord++] = i;
			was[i] = 1;
			//cerr << "We took segment #" << i << "\n";
			break;
		}
	}
	RAns(ll, pos - 1);
	RAns(pos + 1, rr);
}

void Solve()
{
	int i;
	//cerr << "We have segments:\n";
	//for (i = 0; i < n; i++) cerr << l[i] << " " << r[i] << "\n";
	memset(res, 0xFF, sizeof(res));
	memset(was, 0, sizeof(was));
	cdpt = 0;
	int rr = Count(0, maxc);
	memset(p, 0xFF, sizeof(p));
	curord = n - rr;
	RAns(0, maxc);
	curord = 0;
	for (i = 0; i < n; i++)
	{
		if (was[i] == 0)
		{
			p[curord++] = i;
		}
	}
	printf("%d\n", rr);
	for (i = 0; i < n; i++)
	{
		printf("%d ", p[i] + 1);
	}
}

int main()
{
//	freopen("painter.in", "rt", stdin);
	Load();
	Solve();
	return 0;
}
