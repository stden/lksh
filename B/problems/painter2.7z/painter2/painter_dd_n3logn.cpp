#include <iostream>
#include <fstream>
#include <cstdio>
#include <map>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 300;

int n;
int l[MAXN], r[MAXN];
int maxc;

void Load()
{
	scanf("%d", &n);
	int i;
	for (i = 0; i < n; i++)
	{
		scanf("%d%d", &l[i], &r[i]);
	}
	vector<int> havec;
	for (i = 0; i < n; i++)
	{
		havec.push_back(l[i]);
		havec.push_back(r[i]);
	}
	sort(havec.begin(), havec.end());
	havec.erase(unique(havec.begin(), havec.end()), havec.end());
	maxc = havec.size() - 1;
	map<int, int> remap;
	for (i = 0; i < havec.size(); i++) remap[havec[i]] = i;
	for (i = 0; i < n; i++)
	{
		l[i] = remap[l[i]];
		r[i] = remap[r[i]] - 1;
	}
}

int res[2 * MAXN][2 * MAXN];
int pth[2 * MAXN][2 * MAXN];
int num[2 * MAXN + 1];
int have[2 * MAXN][2 * MAXN];
int cdpt;

class Evt
{
public:
	int p, t;
};

bool operator<(const Evt &a, const Evt &b)
{
	if (a.p < b.p) return true;
	if (a.p > b.p) return false;
	return a.t < b.t;
}

Evt eve[2 * MAXN];
int neve;        

int Count(int ll, int rr)
{
	if (ll < 0 || rr > maxc || rr < ll) return 0;
	if (res[ll][rr] != -1) return res[ll][rr];
	//cerr << "Count(" << ll << "," << rr << ")\n";
	int i;
	for (i = ll; i <= rr; i++) { have[cdpt][i] = 0; }
	neve = 0;
	for (i = 0; i < n; i++)
	{
		if (l[i] >= ll && r[i] <= rr)
		{
			eve[neve].p = l[i];
			eve[neve].t = -1;
			neve++;
			eve[neve].p = r[i];
			eve[neve].t = 1;
			neve++;
			//cerr << "Now neve = " << neve << "\n";
		}
	}
	if (neve > 1) 
	{
		sort(eve, eve + neve);
	}
	int cnt = 0;
	int ceve = 0;
	for (i = ll; i <= rr; i++)
	{
		while (ceve < neve && eve[ceve].p == i && eve[ceve].t == -1) { ceve++; cnt++; }
		if (cnt != 0) 
		{
			have[cdpt][i] = 1;
		}
		while (ceve < neve && eve[ceve].p == i && eve[ceve].t == 1) { ceve++; cnt--; }
	}
	//cerr << "Count(" << ll << "," << rr << ") finished preparing\n";
	//cerr << "have: ";
	//for (i = ll; i <= rr; i++) cerr << have[cdpt][i] << " ";
	//cerr << "\n";
	res[ll][rr] = 0;
	pth[ll][rr] = -1;
	cdpt++;
	for (i = ll; i <= rr; i++)
	{
		int cur = Count(ll, i - 1);
		cur += Count(i + 1, rr);
		cur += have[cdpt - 1][i];
		if (cur > res[ll][rr])
		{
			res[ll][rr] = cur;
			pth[ll][rr] = i;
		}
	}
	cdpt--;
	//cerr << "Result: " << res[ll][rr] << " Path: " << pth[ll][rr] << "\n";
	return res[ll][rr];
}

int p[MAXN];
int was[MAXN];
int curord;

void RAns(int ll, int rr)
{
	if (ll < 0 || rr > maxc || ll > rr) return;
	if (res[ll][rr] == 0) return;
	//cerr << "RAns(" << ll << "," << rr << ")\n";
	int pos = pth[ll][rr];
	//cerr << "position = " << pos << "\n";
	int i;
	for (i = 0; i < n; i++)
	{
		if (was[i] == 1) continue;
		if (l[i] < ll || r[i] > rr) continue;
		if (l[i] <= pos && r[i] >= pos)
		{
			//cerr << "We took segment #" << i << "\n";
			//cerr << "curord = " << curord << "\n";
			p[curord++] = i;
			was[i] = 1;
			break;
		}
	}
	//cerr << "We try to go somewhere\n";
	RAns(ll, pos - 1);
	RAns(pos + 1, rr);
}

void Solve()
{
	int i;
	//cerr << "We have segments:\n";
	//for (i = 0; i < n; i++) cerr << l[i] << " " << r[i] << "\n";
	memset(res, 0xFF, sizeof(res));
	memset(was, 0, sizeof(was));
	cdpt = 0;
	int rr = Count(0, maxc);
	memset(p, 0xFF, sizeof(p));
	//cerr << "rr = " << rr << "\n";
	curord = n - rr;
	RAns(0, maxc);
	curord = 0;
	for (i = 0; i < n; i++)
	{
		if (was[i] == 0)
		{
			p[curord++] = i;
		}
	}
	printf("%d\n", rr);
	for (i = 0; i < n; i++)
	{
		printf("%d ", p[i] + 1);
	}
	//cerr << "nsort = " << nsort << " numsort = " << numsort << "\n";
}

int main()
{
//	freopen("painter.in", "rt", stdin);
	Load();
	Solve();
	return 0;
}
