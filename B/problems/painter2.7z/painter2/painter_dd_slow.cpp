#include <iostream>
#include <fstream>
#include <cstdio>
#include <map>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 300;

int n;
int l[MAXN], r[MAXN];
int maxc;

void Load()
{
	scanf("%d", &n);
	int i;
	for (i = 0; i < n; i++)
	{
		scanf("%d%d", &l[i], &r[i]);
	}
	vector<int> havec;
	for (i = 0; i < n; i++)
	{
		havec.push_back(l[i]);
		havec.push_back(r[i]);
	}
	sort(havec.begin(), havec.end());
	havec.erase(unique(havec.begin(), havec.end()), havec.end());
	maxc = havec.size() - 1;
	map<int, int> remap;
	for (i = 0; i < havec.size(); i++) remap[havec[i]] = i;
	for (i = 0; i < n; i++)
	{
		l[i] = remap[l[i]];
		r[i] = remap[r[i]] - 1;
	}
}

int res[2 * MAXN][2 * MAXN];
int pth[2 * MAXN][2 * MAXN];
int stk[MAXN];
int top;
int whr[MAXN];
int firstb[2 * MAXN];
int nextb[MAXN];
int firste[2 * MAXN];
int nexte[MAXN];

int Count(int ll, int rr)
{
	if (ll < 0 || rr > maxc || rr < ll) return 0;
	if (res[ll][rr] != -1) return res[ll][rr];
	//cerr << "Count(" << ll << "," << rr << ")\n";
	int have[2 * MAXN];
	int i, j;
	for (i = ll; i <= rr; i++) have[i] = 0;
	top = 0;
	for (i = ll; i <= rr; i++) 
	{
		firstb[i] = -1;
		firste[i] = -1;
	}
	for (i = 0; i < n; i++)
	{
		if (l[i] >= ll && r[i] <= rr)
		{
			nextb[i] = firstb[l[i]];
			firstb[l[i]] = i;
			nexte[i] = firste[r[i]];
			firste[r[i]] = i;
		}
	}
	for (i = ll; i <= rr; i++)
	{
		for (j = firstb[i]; j != -1; j = nextb[j])
		{
			stk[top] = j;
			whr[j] = top;
			top++;
		}
		while (top > 0 && stk[top - 1] == -1) top--;
		//cerr << "We are at: " << i << "\n";
		//cerr << "Stack after adding: ";
		//for (j = 0; j < top; j++) cerr << stk[j] << " ";
		//cerr << "\n";
		if (top > 0) have[i] = 1;
		for (j = firste[i]; j != -1; j = nexte[j])
		{
			stk[whr[j]] = -1;
			whr[j] = -1;
		}
		while (top > 0 && stk[top - 1] == -1) top--;
		//cerr << "Stack after erasing: ";
		//for (j = 0; j < top; j++) cerr << stk[j] << " ";
		//cerr << "\n";
	}
	//cerr << "have: ";
	//for (i = ll; i <= rr; i++) cerr << have[i];
	//cerr << "\n";
	res[ll][rr] = 0;
	pth[ll][rr] = -1;
	for (i = ll; i <= rr; i++)
	{
		int cur = Count(ll, i - 1) + Count(i + 1, rr) + have[i];
		if (cur > res[ll][rr])
		{
			res[ll][rr] = cur;
			pth[ll][rr] = i;
		}
	}
	//cerr << "Result: " << res[ll][rr] << " Path: " << pth[ll][rr] << "\n";
	return res[ll][rr];
}

int p[MAXN];
int was[MAXN];
int curord;

void RAns(int ll, int rr)
{
	if (ll < 0 || rr > maxc || ll > rr) return;
	if (res[ll][rr] == 0) return;
	//cerr << "RAns(" << ll << "," << rr << ")\n";
	int pos = pth[ll][rr];
	//cerr << "position = " << pos << "\n";
	int i;
	for (i = 0; i < n; i++)
	{
		if (was[i] == 1) continue;
		if (l[i] < ll || r[i] > rr) continue;
		if (l[i] <= pos && r[i] >= pos)
		{
			p[curord++] = i;
			was[i] = 1;
			//cerr << "We took segment #" << i << "\n";
			break;
		}
	}
	RAns(ll, pos - 1);
	RAns(pos + 1, rr);
}

void Solve()
{
	int i;
	//cerr << "We have segments:\n";
	//for (i = 0; i < n; i++) cerr << l[i] << " " << r[i] << "\n";
	memset(res, 0xFF, sizeof(res));
	memset(was, 0, sizeof(was));
	int rr = Count(0, maxc);
	memset(p, 0xFF, sizeof(p));
	curord = n - rr;
	RAns(0, maxc);
	curord = 0;
	for (i = 0; i < n; i++)
	{
		if (was[i] == 0)
		{
			p[curord++] = i;
		}
	}
	printf("%d\n", rr);
	for (i = 0; i < n; i++)
	{
		printf("%d ", p[i] + 1);
	}
}

int main()
{
//	freopen("painter.in", "rt", stdin);
	Load();
	Solve();
	return 0;
}
