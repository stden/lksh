#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 300;
const int MAXC = 1000000000;

class Seg
{
public:
	int l, r, id;
};

int n;
Seg s[MAXN];
int maxc;

void Load()
{
	freopen("painter2.in","rt",stdin);
	freopen("painter2.out","wt",stdout);
	scanf("%d", &n);
	int i;
	for (i = 0; i < n; i++)
	{
		scanf("%d%d", &s[i].l, &s[i].r);
		s[i].id = i + 1;
	}
	vector<int> havec;
	for (i = 0; i < n; i++)
	{
		havec.push_back(s[i].l);
		havec.push_back(s[i].r);
	}
	sort(havec.begin(), havec.end());
	havec.erase(unique(havec.begin(), havec.end()), havec.end());
	maxc = havec.size() - 1;
	map<int, int> remap;
	for (i = 0; i < havec.size(); i++) remap[havec[i]] = i;
	for (i = 0; i < n; i++)
	{
		s[i].l = remap[s[i].l];
		s[i].r = remap[s[i].r] - 1;
	}
}

bool cmp1(const Seg &a, const Seg &b)
{
	return a.l < b.l;
}

bool cmp2(const Seg &a, const Seg &b)
{
	return a.r > b.r;
}

int clr[2 * MAXN];

int Count()
{
	memset(clr, 0xFF, sizeof(clr));
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = s[i].l; j <= s[i].r; j++) clr[j] = s[i].id;
	}
	set<int> ans;
	for (i = 0; i <= maxc; i++)
	{
		if (clr[i] != -1) ans.insert(clr[i]);
	}
	return ans.size();
}

void Solve()
{
	sort(s, s + n, cmp1);
	int r1 = Count();
	sort(s, s + n, cmp2);
	int r2 = Count();
	if (r1 < r2) sort(s, s + n, cmp1);
	else sort(s, s + n, cmp2);
	int res = min(r1, r2);
	int i;
	printf("%d\n", res);
	for (i = 0; i < n; i++) printf("%d ", s[i].id);
}

int main()
{
//	freopen("painter.in", "rt", stdin);
	Load();
	Solve();
	return 0;
}
