#/bin/bash

g++ -o bigcoord bigcoord.cpp
g++ -o genrand genrand.cpp
g++ -o genrand2 genrand2.cpp
g++ -o solution ../painter_dd.cpp

cp 01.hand 01
cp 02.hand 02

./genrand 20 1 20 | ./bigcoord -100 100 > 03
./genrand 30 1 14 | ./bigcoord -90 90 > 04
./genrand 40 1 10 | ./bigcoord -200 200 > 05


./genrand2 20 1 20 280 100 200000 | ./bigcoord -1000000000 1000000000 > 06
./genrand2 20 1 18 280 100 200000 | ./bigcoord -1000000000 1000000000 > 07
./genrand2 10 1 5 290 100 200000 | ./bigcoord -1000000000 1000000000 > 08
./genrand 300 100 400000 | ./bigcoord -1000000000 1000000000 > 09
./genrand2 30 3 20 270 100 400000 | ./bigcoord -1000000000 1000000000 > 10
./genrand2 20 1 15 280 100 400000 | ./bigcoord -1000000000 1000000000 > 11
./genrand2 20 1 10 280 100 400000 | ./bigcoord -1000000000 1000000000 > 12
./genrand2 30 1 6  270 100 400000 | ./bigcoord -1000000000 1000000000 > 13



./genrand 100 1  50 | ./bigcoord -1000000000 1000000000 > 14
./genrand 130 1  50 | ./bigcoord -1000000000 1000000000 > 15
./genrand 170 1  50 | ./bigcoord -1000000000 1000000000 > 16
./genrand 200 1  50 | ./bigcoord -1000000000 1000000000 > 17
./genrand 230 1 100 | ./bigcoord -1000000000 1000000000 > 18
./genrand 260 1  40 | ./bigcoord -1000000000 1000000000 > 19
./genrand 290 1  80 | ./bigcoord -1000000000 1000000000 > 20
./genrand 300 1 100 | ./bigcoord -1000000000 1000000000 > 21

for i in ??; do
	echo $i
	cp $i painter2.in
	./solution
	mv painter2.out $i.a;
done

rm -f solution 
rm -f genrand
rm -f genrand2
rm -f bigcoord
rm -f painter2.in

rm -rf ../tests
mkdir ../tests
for i in ??; do
	mv $i.a ../tests/$i.a
	mv $i ../tests/$i
done