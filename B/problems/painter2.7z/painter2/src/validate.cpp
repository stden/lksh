#include "testlib.h"
#include <string>
#include <cstdio>
#include <cstdlib>
#include <iostream>

using namespace std;

const int MAXN = 300;
const int MAX = 1000000000;

int main()
{
  registerValidation();

  int n = inf.readInt(1, MAXN);
  inf.readEoln();

  for (int i = 0; i < n; ++i)
  {
  	int l = inf.readInt(-MAX, MAX);
  	inf.readSpace();
  	inf.readInt(l + 1, MAX);
  	inf.readEoln();
  }

  inf.readEof();
}
