#include "random.h"
#include <iostream>
#include <fstream>

using namespace std;



int main(int argc, char *argv[])
{
	int n = atoi(argv[1]);
	int minc = atoi(argv[2]);
	int maxc = atoi(argv[3]);
	int n2 = atoi(argv[4]);
	int minc2 = atoi(argv[5]);
	int maxc2 = atoi(argv[6]);
	initrand(n*728394+minc*78934+maxc*734895);
	cout << n+n2 << "\n";
	int i;
	for (i = 0; i < n; i++)
	{
		int cl = R(minc, maxc - 1);
		int cr = R(cl + 1, maxc);
		cout << cl << " " << cr << "\n";
	}
	for (i = 0; i < n2; i++)
	{
		int cl = R(minc2, maxc2 - 1);
		int cr = R(cl + 1, maxc2);
		cout << cl << " " << cr << "\n";
	}
	return 0;
}
