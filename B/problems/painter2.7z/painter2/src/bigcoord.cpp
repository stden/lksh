#include "random.h"
#include <stdio.h>
#include <stdlib.h>

#define MAXN 300

int main(int argc, char** argv){
	int l = atoi(argv[1]);
	int r = atoi(argv[2]);
	int n; scanf("%d",&n);printf("%d\n",n);
	initrand(l*678324+r*78324+n*67324);
	int ll[MAXN];
	int lr[MAXN];
	int i,j,k, t;
	int z[2*MAXN];
	int rl[MAXN];
	int rr[MAXN];
	int zz[2*MAXN];
	for(i = 0;i<n;i++){
		scanf("%d",ll+i);
		scanf("%d",lr+i);
		z[2*i] = ll[i];
		z[2*i+1] = lr[i];
	}
	for(i = 0;i<2*n;i++)
		for(j = i+1;j<2*n;j++)
			if (z[i]>z[j]){
				t = z[i]; z[i] = z[j]; z[j] = t;
			}
	k = 1;
	for(i = 1;i<2*n;i++){
		if (z[i]!=z[k-1])
			z[k++] = z[i];
	}
	for(i = 0;i<k;i++){
		zz[i] = R(l,r);
	}
	for(i = 0;i<k;i++)
		for(j=i+1;j<k;j++)
			if (zz[i]>zz[j]){
				t = zz[i]; zz[i] = zz[j]; zz[j] = t;
			}
	for(i = 0;i<n;i++)
		for(j = 0;j<k;j++){
			if (ll[i]==z[j]){
				rl[i] = zz[j];
			}
			if (lr[i]==z[j]){
				rr[i] = zz[j];
			}
		}
	for(i = 0;i<n;i++)
		printf("%d %d\n",rl[i],rr[i]);


}
