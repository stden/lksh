#/bin/bash
rm -rf ../tests/
rm -f bigcoord solution genrand genrand2
rm -f *.exe
