#include "random.h"
#include <iostream>
#include <fstream>

using namespace std;



int main(int argc, char *argv[])
{
	int n = atoi(argv[1]);
	int minc = atoi(argv[2]);
	int maxc = atoi(argv[3]);
	initrand(n*728394+minc*78934+maxc*734895);
	cout << n << "\n";
	int i;
	for (i = 0; i < n; i++)
	{
		int cl = R(minc, maxc - 1);
		int cr = R(cl + 1, maxc);
		cout << cl << " " << cr << "\n";
	}
	return 0;
}
