// Author: Denis Denisov
#include "testlib.h"
#include <sstream>
#include <string>
#include <iostream>
#include <cassert>
#include <set>
#include <map>

using namespace std;

const int MAXN = 500;

int n;
int l[MAXN], r[MAXN];
int maxc;

void Load()
{
	n = inf.readInt();
	int i;
	for (i = 0; i < n; i++)
	{
		l[i] = inf.readInt();
		r[i] = inf.readInt();
	}
	vector<int> havec;
	for (i = 0; i < n; i++)
	{
		havec.push_back(l[i]);
		havec.push_back(r[i]);
	}
	sort(havec.begin(), havec.end());
	havec.erase(unique(havec.begin(), havec.end()), havec.end());
	maxc = havec.size() - 1;
	map<int, int> remap;
	for (i = 0; i < havec.size(); i++) remap[havec[i]] = i;
	for (i = 0; i < n; i++)
	{
		l[i] = remap[l[i]];
		r[i] = remap[r[i]] - 1;
	}
}

int clr[2 * MAXN];
int was[MAXN];

int main(int argc, char * argv[])
{
	setName("checker for problem painter");
    registerTestlibCmd(argc, argv);
	Load();
	int jans = ans.readInt();
	int cans = ouf.readInt();
	if (cans < jans) quitf(_wa, "Contestant can paint %d visible segments, but jury can %d.", cans, jans);
	int i;
	memset(was, 0, sizeof(was));
	memset(clr, 0xFF, sizeof(clr));
    for (i = 0; i < n; i++)
	{
		int p = ouf.readInt();
		if (p < 1 || p > n) quitf(_wa, "There is no segment with number %d.", p);
		p--;
		if (was[p] == 1) quitf(_wa, "Segment number %d is already painted.", p);
		was[p] = 1;
		int j;
		for (j = l[p]; j <= r[p]; j++)
		{
			clr[j] = i;
		}
	}
	set<int> clrs;
	for (i = 0; i <= maxc; i++)
	{
		if (clr[i] != -1) clrs.insert(clr[i]);
	}
	if (clrs.size() != cans) quitf(_wa, "Contestant declared %d colors, but in fact he has %d.", clrs.size());
	if (cans > jans) quitf(_fail, "Contestant has better answer: %d, when jury has only %d.", cans, jans);
	quitf(_ok, "n = %d visible colors = %d", n, cans);
}
