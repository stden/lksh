#include "testlib.h"

int main()
{
  registerValidation();
  char c;
  int open = 0;
  int close = 0;
  int ct = 0;
  while (scanf("%c", &c) > 0)
  {
    ct ++;
    if (c == '<')
    {
      scanf("%c", &c);
      if (c == '/')
      {
        close++;
      } else {
        open++;
      }
    }
  }
  ensure(ct <= 10000 / sizeof(char));
  ensure(close <= 500);
  ensure(open <= 500);
}
