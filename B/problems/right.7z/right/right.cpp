#include <iostream>
#include <cstdio>

using namespace std;

int n, m;
int mas[110000];

void Load()
{
    cin >> n >> m;
    for (int i = 0; i < n; i++) cin >> mas[i];
}
void Solve() {
    int i, l, r, t, x, ans;
    for (i = 0; i < m; i++) {
        cin >> x;
        l = 0;
        r = n - 1;
        ans = -1;       
        while (l <= r) {
            t = (r + l) / 2;
            if (mas[t] <= x) {
                if (mas[t] == x) ans = t;
                l = t + 1;
            } else r = t - 1;
        }
        cout << ans + 1 << "\n";
    }
}

int main()
{
    freopen("right.in", "rt", stdin);
    freopen("right.out", "wt", stdout);
    Load();
    Solve();
    return 0;
}
