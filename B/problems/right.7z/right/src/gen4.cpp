#include <cstdio>

int main( int argc, char *argv[] ) {
  int n = 100000, k = 100000;
  printf("%d %d\n", n, k);
  printf("3 3 ");
  for (int i = 0; i < n - 4; i++) {
    printf("%d ", 100000);
  }
  printf("100001 100001\n");
  for (int i = 0; i < k; i++) {
    printf("100000\n");
  }
  return 0;
}
