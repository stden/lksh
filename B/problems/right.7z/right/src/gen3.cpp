#include <cstdio>
#include <iostream>
#include <cstdlib>

using namespace std;

int n, m;

int Rand() {
    return ((int)rand()) * 30000 + rand();
}

int main(int argc, char *argv[])
{
    int i;
    freopen("11", "wt", stdout);
    cout << "100000 100000\n";
    for (i = 0; i < 50000; i++) {
        cout << "1 ";
    }
    for (i = 0; i < 50000; i++) {
        cout << "2";
        if (i + 1 < 50000) {
          cout << " ";
        }
    }

    cout << endl;
    for (i = 0; i < 50000; i++) {
        cout << "1\n";
    }
    for (i = 0; i < 50000; i++) {
        cout << "2\n";
    }

    return 0;
}
