#!/bin/bash

for i in *.manual; do
  cp "$i" "${i/\.manual/}"
done

g++ -o gen gen.cpp || exit 1
g++ -o gen2 gen2.cpp || exit 1
g++ -o gen3 gen3.cpp || exit 1
g++ -o gen4 gen4.cpp || exit 1

./gen 100000 100000 12345 > 09 || exit 1
./gen2 100000 100000 54321 > 10 || exit 1
./gen3 > 11 || exit 1
./gen4 > 12 || exit 1

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

