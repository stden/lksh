#include "testlib.h"

int main() {
  registerValidation();
  int n = inf.readInt();
  inf.readSpace();
  int k = inf.readInt();
  inf.readEoln();
  int a = inf.readInt();
  for (int i = 1; i < n; i++) {
    inf.readSpace();
    int b = inf.readInt();
    ensure(a <= b);
    a = b;
  }
  inf.readEoln();
  for (int i = 0; i < k; i++) {
    inf.readInt();
    inf.readEoln();
  }
  return 0;
}
