#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <algorithm>

using namespace std;

#include "random.h"

const int maxN = 100000;

vector <int> v;

int main(int argc, char *argv[])
{
	int n = atoi(argv[1]);
	int m = atoi(argv[2]);
	initrand(atoi(argv[3]));
	cout << n << " " << m << "\n";
	int i;
        int k = 0;
	for (i = 0; i < n; i++) {
		v.push_back(k);
		k += nextrand() % ((50000 - k) / 2 + 1);		
	}
	sort(v.begin(), v.end());
	for (int i = 0; i < n; ++i)
		printf("%d%c", v[i], (i == n - 1) ? '\n' : ' ');

	for ( i = 0; i < m; i++) {
		cout << R(-1000000, 1000000) << endl;
	}
	return 0;
}
