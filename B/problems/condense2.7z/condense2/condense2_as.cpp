#define _CRT_SECURE_NO_DEPRECATE
#include <cstdio>
#include <cstring>
#include <vector>
#include <set>
using namespace std;

int n, m, comp, k;
vector<int> adj[2][10100];
char used[10100];
int topol[10100], tnum;
int color[10100];
set<pair<int, int> > s;

void dfs(int dir, int a){
  used[a] = 1;
  int i, k;
  for (i=0; i<(int)adj[dir][a].size(); i++){
    k = adj[dir][a][i];
    if (!used[k]) dfs(dir, k);
  }
  if (!dir) topol[++tnum] = a;
  else color[a] = comp;
}

int main(){
  freopen("condense2.in", "r", stdin);
  freopen("condense2.out", "w", stdout);
  int i, a, b, j;
  scanf("%d%d", &n, &m);
  for (i=1; i<=m; i++){
    scanf("%d%d", &a, &b);
    adj[0][a].push_back(b);
    adj[1][b].push_back(a);
  }
  for (i=1; i<=n; i++){
    if (!used[i]){
      dfs(0, i);
    }
  }
  memset(used, 0, sizeof(used));
  for (i=n; i>=1; i--){
    if (!used[topol[i]]){
      comp++;
      dfs(1, topol[i]);
    }
  }
  for (i=1; i<=n; i++){
    for (j=0; j<(int)adj[0][i].size(); j++){
      if (color[adj[0][i][j]] != color[i]){
        s.insert(make_pair(color[i], color[adj[0][i][j]]));
      }
    }
  }
  printf("%d\n", s.size());
  return 0;
}
