// condense

#define _CRT_SECURE_NO_DEPRECATE

#include <algorithm>
#include <iostream>
#include <cassert>
#include <vector>
#include <set>

using namespace std;

const int nmax = 10001;
const int mmax = 100001;

vector < int > d[nmax];
vector < int > id[nmax];
vector < int > order;
int n, m, color;
int use[nmax];
int f[nmax];

void init() {
    scanf("%d%d", &n, &m);
    for (int i = 0; i < m; ++i) {
        int x, y;
        scanf("%d%d", &x, &y);
        d[x - 1].push_back(y - 1);
        id[y - 1].push_back(x - 1);
    }
}

void dfs(int x, vector < int > * e) {
    use[x] = color;
    for (int i = 0; i < (int)e[x].size(); ++i) {
        int y = e[x][i];
        if (!use[y]) dfs(y, e);
    }
    order.push_back(x);
}

void solve() {
    memset(use, 0, sizeof(use));
    order.reserve(n);
    color = 0;
    for (int i = 0; i < n; ++i) {
        if (use[i] == 0) {
            color++;
            dfs(i, d);
        }
    }
    memset(use, 0, sizeof(use));
    color = 0;
    for (int i = n - 1; i >= 0; --i) {
        if (use[order[i]] == 0) {
            color++;
            dfs(order[i], id);
        }
    }

    for (int i = 0; i < color; ++i) id[i].clear();
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < (int)d[i].size(); ++j) {
            if (use[i] != use[d[i][j]]) {
                id[use[i]].push_back(use[d[i][j]]);
            }
        }
    }
}

void writeanswer() {
    int ans = 0;
    for (int i = 0; i < color; ++i) {
        set < int > temp(id[i].begin(), id[i].end());
        ans += (int)temp.size();
    }
    printf("%d", ans);
}

int main() {
    freopen("condense2.in", "rt", stdin);
    freopen("condense2.out", "wt", stdout);

    init();
    solve();
    writeanswer();
    
    return 0;
}
