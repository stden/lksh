#!/bin/bash

fpc -Mdelphi dotests.dpr

for i in ??.hand; do
  cp "$i" "${i/\.hand/}"
done

./dotests

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

