#include <fstream>
#include <set>
#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;

#pragma comment (linker, "/STACK:40000000")

const int MAXN = 110000;

class Edge
{
public:
	int be, en;
};

int n, k;
vector<Edge> edg;
int first[MAXN], next[2 * MAXN];

void AddEdge(int v1, int v2)
{
	Edge a;
	a.be = v1;
	a.en = v2;
	edg.push_back(a);
	next[edg.size() - 1] = first[v1];
	first[v1] = edg.size() - 1;
}

void Load()
{
	edg.clear();
	memset(first, 0xFF, sizeof(first));
	memset(next, 0xFF, sizeof(next));
	scanf("%d%d", &n, &k);
	int i;
	for (i = 1; i <= n - 1; i++)
	{
		int p, q;
		scanf("%d%d", &p, &q);
		AddEdge(p, q);
		AddEdge(q, p);
	}
}

int was[MAXN];
int numc[MAXN];
int dst[MAXN];
int rt[MAXN];
int root;

void Dfs(int ver, int dpt = 0)
{
	was[ver] = 1;
	dst[ver] = dpt;
	numc[ver] = 0;
	int i;
	for (i = first[ver]; i != -1; i = next[i])
	{
		if (was[edg[i].en] == 1) continue;
		Dfs(edg[i].en, dpt + 1);
		rt[edg[i].en] = ver;
		numc[ver]++;
	}
	if (dpt != 0) numc[ver]++;
}

vector<int> pth;
int placed[MAXN];
vector<int> q;

int Check(int len)
{
	memset(was, 0, sizeof(was));
	q.clear();
	int i;
	for (i = 1; i <= n; i++)
	{
		if (placed[i] == 1)
		{
			q.push_back(i);
			was[i] = 1;
			dst[i] = 0;
		}
	}
	i = 0;
	while (i < q.size())
	{
		int cver = q[i];
		int j;
		for (j = first[cver]; j != -1; j = next[j])
		{
			if (was[edg[j].en] == 0)
			{
				dst[edg[j].en] = dst[cver] + 1;
				was[edg[j].en] = 1;
				q.push_back(edg[j].en);
			}
		}
		i++;
	}
	for (i = 1; i <= n; i++)
	{
		if (dst[i] > len) return 0;
	}
	return 1;
}

int CanDo(int len)
{
	memset(placed, 0, sizeof(placed));
	int cpos = 0;
	while (cpos < pth.size())
	{
		int npos = cpos + 2 * len;
		int rpos = cpos + len;
		if (rpos >= pth.size()) rpos = pth.size() - 1;
		if (npos >= pth.size()) npos = pth.size() - 1;
		placed[pth[rpos]] = 1;
		cpos = npos + 1;
	}
	return Check(len);
}

void Solve()
{
	Dfs(1);
	int i;
	int max, mi;
	max = -1;
	mi = 0;
	for (i = 1; i <= n; i++)
	{
		if (dst[i] > max)
		{
			max = dst[i];
			mi = i;
		}
	}
	memset(was, 0, sizeof(was));
	Dfs(mi);
	int root = mi;
	max = -1;
	mi = 0;
	for (i = 1; i <= n; i++)
	{
		if (dst[i] > max)
		{
			max = dst[i];
			mi = i;
		}
	}
	pth.clear();
	int curver = mi;
	while (curver != root)
	{
		pth.push_back(curver);
		curver = rt[curver];
	}
	pth.push_back(root);
	int l, r, mid, min;
	l = 0;
	r = n;
	min = r + 1;
	while (l <= r)
	{
		mid = (l + r) / 2;
		if (CanDo(mid))
		{
			if (mid < min) min = mid;
			r = mid - 1;
		}
		else
		{
			l = mid + 1;
		}
	}
	CanDo(min);
	printf("%d\n", min);
	int num = 0;
	for (i = 1; i <= n; i++)
	{
		if (placed[i] == 1) num++;
	}
	for (i = 1; i <= n; i++)
	{
		if (num >= k) break;
		if (placed[i] == 0)
		{
			placed[i] = 1;
			num++;
		}
	}
	for (i = 1; i <= n; i++)
	{
		if (placed[i] == 1)
		{
			printf("%d ", i);
		}
	}
}

int main()
{
	freopen("barns.in", "rt", stdin);
	freopen("barns.out", "wt", stdout);
	Load();
	Solve();
	return 0;
}