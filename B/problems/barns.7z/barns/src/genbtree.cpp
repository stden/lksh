#include <fstream>
#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
	int n = 50000, k = 100;
	printf("%d %d\n", n, k);
	int i;
	for (i = 1; i <= n; i++)
	{
		if (2 * i <= n) printf("%d %d\n", i, 2 * i);
		if (2 * i + 1 <= n) printf("%d %d\n", i, 2 * i + 1);
	}
	return 0;
}