#!/bin/bash

g++ -o gen3 gen3.cpp
g++ -o genbtree genbtree.cpp
g++ -o genchain genchain.cpp
fpc -Mdelphi gen2.dpr
fpc -Mdelphi gen.dpr

rm -rf ../tests/
mkdir ../tests/

for i in *.hand; do
  cp "$i" "${i/\.hand/}"
done

./gen 100 10 9857 > 04
./gen 500 2 2875 > 05
./gen 500 10 15986 > 06
./gen 1000 10 817 > 07
./gen 5000 2 17485 > 08
./gen 10000 10 18746 > 09
./gen 50000 20 36578 > 10
./gen2 5000 5 17586 > 11
./gen2 10000 10 19480 > 12
./gen2 50000 10 36899 > 13
./gen2 50000 2 28756 > 14
./gen3 9000 10000 2 2 1462 > 15
./gen3 9000 10000 2 50 18918 > 16
./gen3 9000 10000 2 2 1126 > 17
./gen3 9000 10000 2 50 1998 > 18
./gen3 9000 10000 2 2 18756 > 19
./gen3 40000 50000 2 2 2657 > 20
./gen3 40000 50000 2 100 23489 > 21
./gen3 40000 50000 2 2 85990 > 22
./gen3 40000 50000 2 100 12352 > 23
./gen3 40000 50000 2 2 871568 > 24
./genchain > 25
./genbtree > 26

mv ?? ../tests/

