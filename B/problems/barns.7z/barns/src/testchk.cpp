#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

typedef long long int64;
typedef double real;
const int MaxBuf = 524288;

char buf [MaxBuf];
char ch;

char * getstr (char * buf)
{
 if (fgets (buf, MaxBuf, stdin) == NULL)
  return NULL;
 for (int n = strlen (buf) - 1; n >= 0 &&
  (buf[n] == '\n' || buf[n] == '\t' || buf[n] == ' '); n--)
   buf[n] = '\0';
 return buf;
}

bool isempty (char * buf)
{
 return (strlen (buf) == 0);
}

const int MaxN = 50000;

int a [MaxN + 1];

int find (int k)
{
 if (a[k] != k)
  a[k] = find (a[k]);
 return a[k];
}

bool merge (int p, int q)
{
 p = find (p);
 q = find (q);
 if (p != q)
 {
  a[p] = q;
  return true;
 }
 return false;
}

int main (int argc, char * argv [])
{
 int i, j, k, l, n;
 assert (argc > 1);
 freopen (argv[1], "rt", stdin);

 {
  assert (getstr (buf) != NULL);
  stringstream ssbuf (buf);
  assert (ssbuf >> n);
  assert (n >= 1 && n <= 50000);
  assert (ssbuf >> k);
  assert (k >= 1 && k <= n);
  assert (ssbuf.eof ());
 }

 for (i = 1; i <= n; i++)
  a[i] = i;

 for (i = 0; i < n - 1; i++)
 {
  assert (getstr (buf) != NULL);
  stringstream ssbuf (buf);
  assert (ssbuf >> j);
  assert (j >= 1 && j <= n);
  assert (ssbuf >> l);
  assert (l >= 1 && l <= n);
  assert (ssbuf.eof ());
  assert (merge (j, l));
 }
 
 assert (fscanf (stdin, " %c", &ch) == EOF);
 printf ("Correct.\n");
 return 0;
}
