#include <fstream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <iostream>
using namespace std;

int GetRand()
{
	unsigned a;
	a = rand();
	a = a << 10;
	a ^= rand();
        a %= (unsigned)1e9;
	return a;                  
}


class Edge
{
public:
	int be, en;
};

const int MAXN = 110000;

int minn, maxn, mink, maxk;
int n, k;
vector<Edge> edg;

void AddEdge(int v1, int v2)
{
	Edge a;
	a.be = v1;
	a.en = v2;
	edg.push_back(a);
}

int dst[MAXN];
int dpt[MAXN];
int lusn;
vector<int> gver;

void AddTree(int root, int dptmax, int numver)
{
	gver.clear();
	dpt[root] = 0;
	int i;
	gver.push_back(root);
	for (i = 1; i <= numver; i++)
	{
		int pos = GetRand() % gver.size();
		int cvver = ++lusn;
		dpt[cvver] = dpt[gver[pos]] + 1;
		if (dpt[cvver] < dptmax)
		{
			gver.push_back(cvver);
		}
		AddEdge(gver[pos], cvver);
	}
}

void GenTree(int diam, int numver, int &v1, int &v2)
{
	int i;
	int cv1, cv2;
	cv1 = lusn + 1;
	cv2 = lusn + diam + 1;
	for (i = cv1; i < cv2; i++)
	{
		AddEdge(i, i + 1);
	}
	numver -= (cv2 - cv1 + 1);
	if (numver != 0)
	{
		if (rand() % 2 == 1)
		{
			cv2++;
			AddEdge(cv2 - 1, cv2);
			numver--;
		}
	}
	int lc = (cv1 + cv2) / 2;
	dst[lc] = 0;
	for (i = lc - 1; i >= cv1; i--)
	{
		dst[i] = dst[i + 1] + 1;
	}
	lc = (cv1 + cv2) / 2 + (cv1 + cv2) % 2;
	dst[lc] = 0;
	for (i = lc + 1; i <= cv2; i++)
	{
		dst[i] = dst[i - 1] + 1;
	}
	lusn = cv2;
	while (numver != 0)
	{
		int curver = GetRand() % numver + 1;
		int cver = GetRand() % (cv2 - cv1 + 1) + cv1;
		while (dst[cver] == 0)
		{
			cver = GetRand() % (cv2 - cv1 + 1) + cv1;
		}
		AddTree(cver, dst[cver], curver);
		numver -= curver;
	}
	v1 = cv1;
	v2 = cv2;
}

int prm[MAXN];

void GenPrm()
{
	int i;
	for (i = 1; i <= n; i++)
	{
		prm[i] = i;
	}
	for (i = 1; i <= 2 * n; i++)
	{
		int p1, p2;
		p1 = GetRand() % n + 1;
		p2 = GetRand() % n + 1;
		int t = prm[p1];
		prm[p1] = prm[p2];
		prm[p2] = t;
	}
}

int main(int argc, char *argv[])
{
	minn = atoi(argv[1]);
	maxn = atoi(argv[2]);
	mink = atoi(argv[3]);
	maxk = atoi(argv[4]);

	if (argc >= 6)
	{
		srand(atoi(argv[5]));
	}
	else srand((unsigned)301703);
	edg.clear();
	n = GetRand() % (maxn - minn + 1) + minn;
	k = GetRand() % (maxk - mink + 1) + mink;
	int size = n / k;
	int i;
	int x = rand() % (size - 1) + 1;
	if (x == 1)
	{
		cerr << "Too less vertices... Cannot generate test :(\n";
		return 1;
	}
	int v1, v2;
	int pvv = 0;
	lusn = 0;
	for (i = 1; i <= k; i++)
	{
		if (i == k) GenTree(x, n - size * (k - 1), v1, v2);
		else GenTree(x, size, v1, v2);
		if (pvv != 0)
		{
			AddEdge(pvv, v1);
		}
		pvv = v2;
	}
	
	GenPrm();

	printf("%d %d\n", n, k);
	for (i = 0; i < edg.size(); i++)
	{
		printf("%d %d\n", prm[edg[i].be], prm[edg[i].en]);
	}
	return 0;
}
