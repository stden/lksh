#include "testlib.h"
#include <vector>

using namespace std;

const int MAXN = 50000;

bool use[MAXN];
vector <int> ed[MAXN];

int dfs(int s)
{
	if (use[s])
		return 0;

	use[s] = 1;
	int cnt = 1;
	for (int i = 0; i < int(ed[s].size()); ++i)
		cnt += dfs(ed[s][i]);
	return cnt;
}

int main()
{
	registerValidation();

	int n = inf.readInt(2, MAXN);
	inf.readSpace();
	inf.readInt(1, n);
	inf.readEoln();

	for (int i = 1; i < n; ++i)
	{
		int u = inf.readInt(1, n) - 1;
		inf.readSpace();
		int v = inf.readInt(1, n) - 1;
		inf.readEoln();

		ed[u].push_back(v);
		ed[v].push_back(u);
	}

	inf.readEof();

	memset(use, 0, sizeof(use));
	ensure(dfs(0) == n);
	
	return 0;
}
