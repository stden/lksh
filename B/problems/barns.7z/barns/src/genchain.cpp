#include <iostream>
#include <fstream>
using namespace std;


int main()
{
	int n = 50000, k = 100;
	printf("%d %d\n", n, k);
	int i;
	for (i = 1; i < n; i++)
	{
		printf("%d %d\n", i, i + 1);
	}
	return 0;
}