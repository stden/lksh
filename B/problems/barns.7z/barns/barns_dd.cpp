#include <fstream>
#include <set>
#include <iostream>
#include <cstdio>
#include <vector>
#include <cstring>
using namespace std;

#pragma comment (linker, "/STACK:40000000")

const int MAXN = 110000;

class Edge
{
public:
	int be, en;
};

int n, k;
vector<Edge> edg;
int first[MAXN], next[2 * MAXN];

void AddEdge(int v1, int v2)
{
	Edge a;
	a.be = v1;
	a.en = v2;
	edg.push_back(a);
	next[edg.size() - 1] = first[v1];
	first[v1] = edg.size() - 1;
}

void Load()
{
	edg.clear();
	memset(first, 0xFF, sizeof(first));
	memset(next, 0xFF, sizeof(next));
	scanf("%d%d", &n, &k);
	int i;
	for (i = 1; i <= n - 1; i++)
	{
		int p, q;
		scanf("%d%d", &p, &q);
		AddEdge(p, q);
		AddEdge(q, p);
	}
}

class Leaf
{
public:
	int id;
};

int was[MAXN];
int r;
int dst[MAXN];
int numc[MAXN];
int rt[MAXN];
int root;

bool operator<(const Leaf &a, const Leaf &b)
{
	if (dst[a.id] < dst[b.id]) return true;
	else if (dst[a.id] > dst[b.id]) return false;
	if (a.id < b.id) return true;
	else return false;
}

void Dfs(int ver, int dpt)
{
	was[ver] = 1;
	dst[ver] = dpt;
	numc[ver] = 0;
	int i;
	for (i = first[ver]; i != -1; i = next[i])
	{
		if (was[edg[i].en] == 1) continue;
		Dfs(edg[i].en, dpt + 1);
		rt[edg[i].en] = ver;
		numc[ver]++;
	}
	if (dpt != 0) numc[ver]++;
}

set<Leaf> leaves;
int kill[MAXN];
int todelete[MAXN];
vector<int> leaftodelete;

void Dfs2(int ver, int prev, int dpt)
{
	kill[ver] = 1;
	if (numc[ver] <= 1)
	{
		if (todelete[ver] == 0)
		{
			leaftodelete.push_back(ver);
			todelete[ver] = 1;
		}
	}
	if (dpt >= r) return;
	int i;
	for (i = first[ver]; i != -1; i = next[i])
	{
		if (edg[i].en == prev) continue;
		Dfs2(edg[i].en, ver, dpt + 1);
	}
}

void MarkVertices(int tver)
{
	leaftodelete.clear();
	Dfs2(tver, 0, 0);
}

void DeleteBadLeaves()
{
	int hd = 0;
	while (hd < leaftodelete.size())
	{
		int curl = leaftodelete[hd];
		if (curl == root)
		{
			int i;
			for (i = first[root]; i != -1; i = next[i])
			{
				if (todelete[edg[i].en] != 2) break;
			}
			Leaf a;
			a.id = root;
			leaves.erase(leaves.find(a));
			todelete[root] = 2;
			if (i != -1)
			{
				root = edg[i].en;
				numc[edg[i].en]--;
				if (numc[edg[i].en] <= 1)
				{
					Leaf a;
					a.id = edg[i].en;
					leaves.insert(a);
					if ((kill[edg[i].en] == 1) && (todelete[edg[i].en] == 0))
					{
						leaftodelete.push_back(edg[i].en);
						todelete[edg[i].en] = 1;
					}
				}
			}
		}
		else
		{
			todelete[curl] = 2;
			numc[rt[curl]]--;
			Leaf a;
			a.id = curl;
			leaves.erase(leaves.find(a));
			if (numc[rt[curl]] <= 1)
			{
				Leaf a;
				a.id = rt[curl];
				leaves.insert(a);
				if ((kill[rt[curl]] == 1) && (todelete[rt[curl]] == 0))
				{
					leaftodelete.push_back(rt[curl]);
					todelete[rt[curl]] = 1;
				}
			}
		}
		hd++;
	}
}

vector<int> placed;

int CanPlace(int rr)
{
	r = rr;
	root = 1;
	memset(was, 0, sizeof(was));
	memset(todelete, 0, sizeof(todelete));
	Dfs(1, 0);
	int i;
	for (i = 1; i <= n; i++)
	{
		if (was[i] == 0)
		{
			cerr << "It is not a tree!!!";
			cout << "It is not a tree!!!";
			return 0;
		}
		if (numc[i] == 1)
		{
			Leaf a;
			a.id = i;
			leaves.insert(a);
		}
	}
	memset(kill, 0, sizeof(kill));
	placed.clear();
	while (1)
	{
		if (leaves.size() == 0) break;
		// find maximal leaf
		int lpos = (--leaves.end())->id;
		int tpos = lpos;
		for (i = 1; i <= r; i++)
		{
			if (tpos == root)
			{
				break;
			}
			tpos = rt[tpos];
		}
		placed.push_back(tpos);
		MarkVertices(tpos);
		DeleteBadLeaves();
	}
	if (placed.size() <= k) return 1;
	else return 0;
}

int tobomb[MAXN];

void Solve()
{
	int l, r, mid, min;
	l = 0;
	r = n;
	min = r + 1;
	while (l <= r)
	{
		mid = (l + r) / 2;
		if (CanPlace(mid))
		{
			if (mid < min) min = mid;
			r = mid - 1;
		}
		else
		{
			l = mid + 1;
		}
	}
	printf("%d\n", min);
	CanPlace(min);
	int i;
	memset(tobomb, 0, sizeof(tobomb));
	int num = 0;
	for (i = 0; i < placed.size(); i++)
	{
		tobomb[placed[i]] = 1;
		num++;
	}
	for (i = 1; i <= n; i++)
	{
		if (num == k) break;
		if (tobomb[i] == 0)
		{
			tobomb[i] = 1;
			num++;
		}
	}
	for (i = 1; i <= n; i++)
	{
		if (tobomb[i] == 1)
		{
			printf("%d ", i);
		}
	}
}

int main()
{
	freopen("barns.in", "rt", stdin);
	freopen("barns.out", "wt", stdout);
	Load();
	Solve();
	return 0;
}