#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:30000000")

#include <cstring>
#include <string>
#include <vector>
#include <cmath>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iostream>
#include <cstdio>
#include <sstream>
#include <cassert>
#include <utility>

using namespace std;

#define EPS 1E-8
const int INF = (int)1E+9;

#define C_IN_FILE "barns.in"
#define C_OUT_FILE "barns.out"

#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define forv(i, v) for (int i = 0; i < (int)(v.size()); ++i)
#define fors(i, s) for (int i = 0; i < (int)(s.length()); ++i)
#define all(a) a.begin(), a.end()
#define pb push_back
#define PII pair<int, int>
#define mp make_pair
#define VI vector<int>
#define VS vector<string>
#define norm(a) sort(all(a)); a.erase(unique(all(a)), a.end());
#define num(a, v) (int)(lower_bound(all(a), v) - a.begin())

const int NMAX = 50000;

int n, k, ans;
vector<int> g[NMAX];

bool u[NMAX], tk[NMAX];
int d[NMAX], p[NMAX], st[NMAX], mk[NMAX];

vector< pair<int, int> > seq;

void outdata() {
}

bool go(int v, int pr) {
	if (u[v]) {
		return false;
	}
	u[v] = true;
	st[v] = 0;
	forv(i, g[v]) if (g[v][i] != pr) {
		int nv = g[v][i];
		d[nv] = d[v] + 1;
		p[nv] = v;
		++st[v];
		if (!go(nv, v)) {
			return false;
		}
	}
	return true;
}

void us(int v) {
	u[v] = true;
	forv(i, g[v]) if (g[v][i] != p[v]) {
		us(g[v][i]);
	}
}

bool ok(int r) {
	memset(u, 0, sizeof u);
	memset(tk, 0, sizeof tk);
	memset(mk, 255, sizeof mk);
	int put = 0;
	forv(i, seq) {
		int v = seq[i].second;
		if (u[v] || mk[v] >= 0) continue;
		bool active = true;
		forn(i, r) {
			if (mk[p[v]] > i) {
				us(v);
				active = false;
				break;
			}
			if (v == 0) break;
			v = p[v];
		}
		if (!active) continue;
		++put;
		tk[v] = true;
		if (put > k) return false;
		us(v);
		forn(i, r) {
			if (v == 0) break;
			v = p[v];
			mk[v] = r - i - 1;
		}
	}
	return true;
}

void solve() {
	memset(u, 0, sizeof u);
	memset(d, 0, sizeof d);
	assert(go(0, -1));
	p[0] = 0;
	forn(i, n) if (!u[i]) assert(false);
	forn(i, n) seq.pb(mp(-d[i], i));
	sort(all(seq));
	int l = 0, r = n;
	while (l != r) {
		int m = (l + r) >> 1;
		if (ok(m)) r = m; else l = m + 1;
	}
	printf("%d\n", l);
	ok(l);
	int put = 0;
	forn(i, n) if (tk[i]) ++put;
	forn(i, n) if (put < k && !tk[i]) {
		++put;
		tk[i] = true;
	}
	put = 0;
	forn(i, n) if (tk[i]) {
		if (put > 0) printf(" ");
		printf("%d", i + 1);
		++put;
	}
	printf("\n");
}

void readdata() {
	scanf("%d%d", &n, &k);
	assert(1 <= n && n <= NMAX);
	assert(1 <= k && k <= n);
	forn(i, n - 1) {
		int x, y;
		scanf("%d%d", &x, &y);
		--x, --y;
		g[x].pb(y);
		g[y].pb(x);
	}
}

int main() {
    freopen(C_IN_FILE, "rt", stdin);
    freopen(C_OUT_FILE, "wt", stdout);
	readdata();
	solve();
	outdata();
	return 0;
}

