#include "testlib.h"
#include <vector>

using namespace std;

const int MAXN = 20;
const long long catalan[MAXN + 1] = {1, 1, 2, 5, 14, 42, 132, 429, 1430, 4862, 16796, 58786, 208012, 742900, 2674440, 9694845, 35357670, 129644790, 477638700, 1767263190, 6564120420};

int main()
{
	registerValidation();

	int n = inf.readInt(1, MAXN);
	inf.readSpace();
	inf.readLong(0, (catalan[n] << n) - 1);
	inf.readEoln();

	inf.readEof();

	return 0;
}
