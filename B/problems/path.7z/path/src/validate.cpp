#include <testlib.h>

const int maxn = 2000;
const int maxm = 5000;

int main() {
  registerValidation();
  int n = inf.readInt(2, maxn);
  inf.readSpace();
  int m = inf.readInt(1, maxm);
  inf.readSpace();
  inf.readInt(1, n);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    inf.readInt(1, n);
    inf.readSpace();
    inf.readInt(1, n);
    inf.readSpace();
    inf.readLong((long long)-1e15, (long long)1e15);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}

