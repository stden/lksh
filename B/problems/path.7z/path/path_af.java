import java.io.*;
import java.math.*;
import java.util.*;

public class path_af implements Runnable {
    public static void main(String[] args) {
        new Thread(new path_af()).start();
    }

    BufferedReader br;
    StringTokenizer st;
    PrintWriter out;
    boolean eof;

    public void run() {
        try {
            String FNAME = "path";
            br = new BufferedReader(new FileReader(FNAME + ".in"));
            out = new PrintWriter(FNAME + ".out");
            solve();
            out.close();
        } catch (Throwable e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    String nextToken() {
        while (st == null || !st.hasMoreElements()) {
            try {
                st = new StringTokenizer(br.readLine());
            } catch (Exception e) {
                eof = true;
                return "0";
            }
        }
        return st.nextToken();
    }

    int nextInt() {
        return Integer.parseInt(nextToken());
    }

    long nextLong() {
        return Long.parseLong(nextToken());
    }

    double nextDouble() {
        return Double.parseDouble(nextToken());
    }

    Random rand = new Random(this.hashCode());

    
    

    
    ArrayList<Edge>[] G;
    
    boolean[] v;
    
    void dfs(int i) {
        v[i] = true;
        for (Edge E : G[i]) {
            if (!v[E.j]) {
                dfs(E.j);
            }
        }
    }
    
    void solve() throws IOException {
        int n = nextInt();
        int m = nextInt();
        int s = nextInt() - 1;
        G = new ArrayList[n];
        for (int i = 0; i < n; i++) G[i] = new ArrayList<Edge>();
        for (int i = 0; i < m; i++) {
            G[nextInt() - 1].add(new Edge(nextInt() - 1, nextLong()));
        }
        
        long[][] D = new long[2][n];
        boolean[][] u = new boolean[2][n];
        Arrays.fill(D[0], Long.MAX_VALUE);
        u[0][s] = true;
        D[0][s] = 0;
        int c = 0;
        for (int i = 0; i < n; i++) {
            System.arraycopy(D[c], 0, D[1 ^ c], 0, n);
            System.arraycopy(u[c], 0, u[1 ^ c], 0, n);
            for (int j = 0; j < n; j++) {
                for (Edge E : G[j]) {
                    if (u[c][j] && D[c][j] + E.w < D[1 ^ c][E.j]) {
                        D[1 ^ c][E.j] = D[c][j] + E.w;
                        u[1 ^ c][E.j] = true;
                    }
                }
            }
            c ^= 1;
        }
        
        v = new boolean[n];
        
        for (int j = 0; j < n; j++) {
            for (Edge E : G[j]) {
                if (u[c][j] && D[c][j] + E.w < D[c][E.j]) {
                    dfs(j);
                }
            }
        }
        
        
        for (int i = 0; i < n; i++) {
            if (!u[c][i]) {
                out.println('*');
                continue;
            }
            if (v[i]) {
                out.println('-');
                continue;
            }
            out.println(D[c][i]);
        }
        
        
    }
    
    class Edge {
        int j;
        long w;
        public Edge(int j, long w) {
            this.j = j;
            this.w = w;
        }
    }
                
    
}
