#define _CRT_SECURE_NO_DEPRECATE

#include <list>
#include <utility>
#include <stdio.h>
#include <limits.h>

using namespace std;

const int MAXN = 2010;
const int MAXM = 5010;

const long long INF = LLONG_MAX;

int N, M, s;
list<pair<int, long long > > adj[MAXN];
long long d[MAXN] = {0};
int color[MAXN] = {0};

void init(void) {
	for (int i = 0; i < MAXN; ++i) {d[i] = INF;}
}

void read(void) {
	scanf("%d %d %d", &N, &M, &s);
	for (int i = 0; i < M; ++i) {
		int u, v;
		long long w;
		scanf("%d %d %lld", &u, &v, &w);
		pair<int, long long > p; p.first = v; p.second = w;
		adj[u].push_front(p);
	}
}

bool relax(int u, int v, long long w) {
	if ((INF != d[u]) && (d[v] > d[u] + w)) {
		d[v] = d[u] + w;
		return true;
	}
	return false;
}

void dfs(int u) {
	color[u] = 1;
	for (list<pair<int, long long > >::iterator iter = adj[u].begin(); iter != adj[u].end(); iter++) {
		if (0 == color[iter->first]) {
			dfs(iter->first);
		}
	}
}

void ford_bellman(int s) {
	d[s] = 0;
	for (int i = 0; i < N; ++i) {
		for (int u = 1; u <= N; ++u) {
			for (list<pair<int, long long > >::iterator iter = adj[u].begin(); iter != adj[u].end(); iter++) {
				relax(u, iter->first, iter->second);
			}
		}
	}

	for (int u = 1; u <= N; ++u) {
		for (list<pair<int, long long > >::iterator iter = adj[u].begin(); iter != adj[u].end(); iter++) {
			if (relax(u, iter->first, iter->second)) {
				if (0 == color[iter->first]) {
					dfs(iter->first);
				}
			}
		}
	}
}

void print_ans(void) {
	for (int i = 1; i <= N; ++i) {
		if (color[i]) {puts("-"); continue;}
		if (INF == d[i]) {puts("*"); continue;}
		printf("%lld\n", d[i]);
	}
}

int main(void) {
	freopen("path.in", "rt", stdin);
	freopen("path.out", "wt", stdout);
	init();
	read();
	ford_bellman(s);
	print_ans();
	return 0;
}
