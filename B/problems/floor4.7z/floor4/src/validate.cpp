#include "testlib.h"

const int maxN = 100000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxN);
  inf.readEoln();
  for (int i = 0; i < n; i++) {
    int t = inf.readInt(-maxN * 2, maxN);
    ensure(t != 0);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}
