#include "testlib.h"

#include <set>

using namespace std;

const int maxN = 250;

int main() {
  registerValidation();
  int na = inf.readInt(1, maxN);
  inf.readSpace();
  int nb = inf.readInt(1, maxN);
  inf.readEoln();

  set <pair <int, int> > s;
  for (int i = 0; i < na; i++) {
    while (true) {
      int t = inf.readInt(0, nb);
      if (t == 0) {
        inf.readEoln();
        break;
      } else {
        s.insert(make_pair(i + 1, t));
        inf.readSpace();
      }
    }
  }
  inf.readEof();
  return 0;
}
