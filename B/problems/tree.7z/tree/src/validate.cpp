#include "testlib.h"

const int maxN = 50000;
const int maxX = 30000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxN);
  inf.readEoln();
  for (int i = 0; i < n; i++) {
    inf.readInt(-maxX, maxX);
    inf.readSpace();
    inf.readInt(-maxX, maxX);
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}
