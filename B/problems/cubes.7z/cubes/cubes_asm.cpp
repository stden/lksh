#include <algorithm>
#include <cstdio>

using namespace std;

#define maxn 300000

int a[maxn], z[maxn];


void zfunc( int n )
{
  int r = 0;
  z[0] = 0;

  for (int i = 1; i < n; i++)
  {
    z[i] = z[r] + r > i ? min(z[r] + r - i, z[i - r]) : 0;
    while (a[z[i]] == a[z[i] + i]) z[i]++;
    r = z[i] + i > z[r] + r ? i : r;
  }
}

int main( void )
{

  freopen("cubes.in", "r", stdin); 
  freopen("cubes.out", "w", stdout);

  int n;
  scanf("%d%*d", &n);

  for (int i = 0; i < n; i++)
    scanf("%d", &a[i]), a[n + n - i - 1] = a[i];
  a[2 * n] = -1;
  zfunc(2 * n);
  for (int i = 0; i <= n / 2; i++)
    if (z[2 * n - (i) * 2] >= i)
      printf("%d ", n - i);
 
  return 0;
}