#include <cstdio>

typedef long long ll;

const ll P = 997;
const ll Q = ll(1e9) + 7;

const int N = 128 * 1024;

int a[N];
ll powerP[N];
ll hash[N], rhash[N];

int main()
{
	freopen("cubes.in", "r", stdin);
	freopen("cubes.out", "w", stdout);

	int n, m;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i)
		scanf("%d", &a[i]);

	hash[0] = 0;
	for (int i = 1; i <= n; ++i)
		(hash[i] = hash[i - 1] * P + a[i]) %= Q;

	rhash[n + 1] = 0;
	for (int i = n; i >= 1; --i)
		(rhash[i] = rhash[i + 1] * P + a[i]) %= Q;

	powerP[0] = 1;
	for (int i = 1; i <= n; ++i)
		(powerP[i] = powerP[i - 1] * P) %= Q;


	for (int i = 0; i <= n; ++i)
	{
		if (i * 2 > n)
			continue;
//		printf("%d %d %d %d\n", 1, i, i + 1, 2 * i);
		if ((hash[i] - rhash[i + 1] + rhash[2 * i + 1] * powerP[i]) % Q == 0)
			printf("%d ", n - i);
	}

	return 0;
}