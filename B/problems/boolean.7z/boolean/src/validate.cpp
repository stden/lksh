#include "testlib.h"
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <iostream>

using namespace std;

const int MAXN = 10000;

int main()
{
  registerValidation();

  int n = inf.readInt(1, MAXN);
  inf.readSpace();
  inf.readInt(0, 1);
  inf.readEoln();

  ensure(n % 2 == 1);

	for (int i = 1; i <= n; ++i)
		if (i * 2 <= n)
		{
			inf.readInt(0, 1);
			inf.readSpace();
			inf.readInt(0, 1);
			inf.readEoln();
		}
		else
		{
			inf.readInt(0, 1);
			inf.readEoln();
		}

  inf.readEof();
}
