#include "testlib.h"
#include <vector>
#include <set>
#include <iostream>
#include <cstdio>

using namespace std;

typedef pair < int, int > pii;

const int MAXN = 100000;
const int MAXM = 100000;

int main()
{
	registerValidation();

	int n = inf.readInt(1, MAXN);
	inf.readSpace();
	int m = inf.readInt(1, MAXM);
	inf.readEoln();
	for (int i = 0; i < n; ++i)
	{
		inf.readInt(1, 2);
		if (i + 1 < n)
			inf.readSpace();
	}
	inf.readEoln();
	for (int i = 0; i < m; ++i)
	{
		int a = inf.readInt(1, n);
		inf.readSpace();
		int b = inf.readInt(1, n);
		inf.readEoln();

		ensure(a != b);
	}

	inf.readEof();
	
	return 0;
}
