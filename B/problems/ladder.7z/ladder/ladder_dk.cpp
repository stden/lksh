#include<fstream>
using namespace std;

int main()
{
	int N,K,i;
	ifstream in("ladder.in");
	ofstream out("ladder.out");
	in>>N;
	int L[N+2];
	int S[N+2];
	for (i=1;i<=N;++i)
	{
		in>>L[i];
	}
	in>>K;
	L[0]=L[N+1]=0;
	S[0]=0;
	for(i=1;i<=N+1;++i)
	{
		S[i]=-1000000000;
		for(int j=max(i-K,0);j<i;++j)
		{
			if(S[j]>S[i])
				S[i]=S[j];
		}
		S[i]+=L[i];
	}
	out<<S[N+1]<<endl;
}

