#include <stdio.h>

int a[1002],b[1002];

int main(){      
  freopen("ladder.in","rt",stdin);
  freopen("ladder.out","wt",stdout);
  int n,k;                                                              
  scanf("%d",&n);
  for (int i=0;i<n+2;i++)
    b[i]=-1000000;
  b[0]=0;
  a[0]=0;            
  for (int i=0;i<n;i++)
    scanf("%d",&a[i+1]);
  scanf("%d",&k);
  a[n+1]=0;
  for (int i=0;i<n+1;i++)
    for (int j=1;j<=k;j++)
      if (i+j<=n+1 && b[i+j]<b[i]+a[i+j])
        b[i+j]=b[i]+a[j+i];
  printf("%d ",b[n+1]);
  return 0;
 }
