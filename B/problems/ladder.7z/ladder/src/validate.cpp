#include "testlib.h"

const int maxN = 1000;
const int maxA = 1000;

int main() {
  registerValidation();
  int n = inf.readInt(0, maxN);
  inf.readEoln();
  for (int i = 0; i < n; i++) {
    inf.readInt(-maxA, maxA);
    if (i + 1 < n) {
      inf.readSpace();
    }
  }
  inf.readEoln();
  inf.readInt(1, n);
  inf.readEoln();
  inf.readEof();
  return 0;
}
