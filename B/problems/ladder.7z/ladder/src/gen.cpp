#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int rnd(int a) {
  return rand() % a;
}

int a,b[1002];

int main(void) {
  srand((int)time(NULL));
  printf("%d\n",1000);
  for (int i=0;i<1000;i++)
    printf("%d ",-rnd(1000)-1);
  printf("\n%d",100);
  return 0;
}
