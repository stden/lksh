#! /bin/bash

rm -rf ../tests
mkdir ../tests
for i in ??.hand; do
	cp $i ../tests/${i/\.hand/};
done

cd ../tests
g++ -o solve ../ladder_dk.cpp
for i in ??; do
	cp $i ladder.in
	./solve
	mv ladder.out $i.a;
done

rm ladder.in solve
