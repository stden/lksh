#! /bin/bash

rm -rf ../tests
mkdir ../tests

g++ -O2 -o ../tests/genall genall.cpp
cp tests.lst ../tests/

cd ../tests
./genall
rm tests.lst

fpc -Mdelphi ../kth_gk.dpr
rm ../kth_gk.o
mv ../kth_gk solve

for i in ??; do
	cp $i kth.in
	./solve
	mv kth.out $i.a;
done

rm solve kth.in genall
cd ../src
