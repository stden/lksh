#include <iostream>
#include <cstdio>
#include <cstring>

char s[1000];
char file_name[10];

int main()
{
	freopen("tests.lst", "r", stdin);

	int i = 0;
	while (std::cin.getline(s, 1000)){
		sprintf(file_name, "%02d", ++i);
		freopen(file_name, "w", stdout);

		printf("%s\n", s);
	}
	return 0;
}
