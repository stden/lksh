#! /bin/bash

rm -rf ../tests
