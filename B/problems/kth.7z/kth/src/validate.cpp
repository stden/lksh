#include "testlib.h"

int main(){
  registerValidation();
  
  int n = inf.readInt(1, 4000000);
  inf.readSpace();
  int k = inf.readInt(1, 4000000);
  ensure(k <= n);

  inf.readEoln();
  inf.readEof();  
}