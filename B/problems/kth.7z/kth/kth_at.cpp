#include <stdio.h>
#include <stdlib.h>

#define FILE_IN "kth.in"
#define FILE_OUT "kth.out"
#define MAXN 4000000

const int COOF[4] = {132,77,1345,1577};
const int p = 1743;

int n,k;
int ans;
int a[MAXN];

void quicksort(int * a,int l, int r) {
	int i=l,j=r,t;
	int x = a[l+rand()%(r-l+1)];
	do {
		while (a[i]<x) i++;
		while (x<a[j]) j--;
		if (i<=j) {
			t = a[i];
			a[i] = a[j];
			a[j] = t;
			i++;j--;
		}
	} while (i<=j);
	if (l<j) quicksort(a,l,j);
	if (i<r) quicksort(a,i,r);	
}

int getpol(int x,int p) {
	x = x % p;
	int ans = 0;
	int i;
	for (i=0;i<4;i++) {
		ans = ans * x % p;
		ans = (ans + COOF[i]) % p;		
	}
	return ans;
}
void init() {
	freopen(FILE_IN,"r",stdin);
	freopen(FILE_OUT,"w",stdout);		
}

void read() {
	scanf("%d %d",&n,&k);
}

void write() {
	printf("%d\n",ans);
	fclose(stdout);
	exit(0);
}

void solve() {
	int i;
	
	for (i=0;i<n;i++) {
		a[i] = getpol(i+1,p);	
		//printf("%d ",a[i]);
	}
	//printf("\n");
	
	quicksort(a,0,n-1);
	ans = a[k-1];
}

int main () {
	init();
	read();
	solve();
	write();
	return 0;
}

