#include <cstdio>
#include <cstring>
#include <iostream>

using namespace std;

typedef long long ll;

struct tree{
	bool change;
	ll sum,val;
};

tree *t;

int size=1;

void push(int v,int L,int R)
{
	if (t[v].change){
		t[v].sum=(R-L+1)*t[v].val;
		if (v<size){
			t[v<<1].change=true; t[v<<1].val=t[v].val;
			t[(v<<1)+1].change=true; t[(v<<1)+1].val=t[v].val;
		}
		t[v].change=false;
	}
}

ll rsq(int l,int r,int L,int R,int v)
{
	push(v,L,R);
	if (r<L||l>R)return 0;
	if (l<=L&&R<=r)return t[v].sum;
	return rsq(l,r,L,(L+R)/2,2*v)+rsq(l,r,(L+R)/2+1,R,2*v+1);
}

void upd(int l,int r,int L,int R,int v,int x)
{
	push(v,L,R);
	if (r<L||l>R)return;
	if (l<=L&&R<=r){
		t[v].change=true; t[v].val=(ll)x;
		push(v,L,R);
		return;
	}
	upd(l,r,L,(L+R)/2,2*v,x);
	upd(l,r,(L+R)/2+1,R,2*v+1,x);
	t[v].sum=t[2*v].sum+t[2*v+1].sum;
}

int main()
{
	freopen("sum.in","rt",stdin);
	freopen("sum.out","wt",stdout);
	
	int n,k;
	
	scanf("%d %d ",&n,&k);
	
	while (size<n)size<<=1;
	
	t=new tree [size*2];
	
	memset(t,0,sizeof(t));
	
	for (int i=0;i<k;i++){
		char ch;
		int l,r,x;
		scanf("%c",&ch);
		if (ch=='A'){
			scanf("%d %d %d ",&l,&r,&x);
			upd(l,r,1,size,1,x);
		} else {
			scanf("%d %d ",&l,&r);
			cout << rsq(l,r,1,size,1) << endl;
		}
	}
	
	delete [] t;
	
	return 0;
}
	
