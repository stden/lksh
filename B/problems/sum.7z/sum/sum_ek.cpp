#include <cstdio>
#include <cassert>
#include <iostream>

using namespace std;

typedef long long ll;

const int N = 1 << 18;

class SegmentTree {
private:
	const static int NONE_ASSIGN = -1;
	ll _sum[N * 2];
	int _assign[N * 2];

	ll getSum(int l, int r, int t, int L, int R);
	void assign(int l, int r, int value, int t, int L, int R);
	void pushInfo(int t, int L, int R);
	void assignNode(int t, int L, int R, int value);

public:
	SegmentTree();

	ll getSum(int l, int r);
	void assign(int l, int r, int value);
};

SegmentTree::SegmentTree()
{
	assignNode(1, 1, N, 0);
}

void SegmentTree::assignNode(int t, int L, int R, int value)
{
	_assign[t] = value;
	_sum[t] = ll(value) * (R - L + 1);
}

void SegmentTree::pushInfo(int t, int L, int R)
{
	if (_assign[t] != NONE_ASSIGN)
	{
		assignNode(2 * t, L, (L + R) / 2, _assign[t]);
		assignNode(2 * t + 1, (L + R) / 2 + 1, R, _assign[t]);

		_assign[t] = NONE_ASSIGN;
	}
}

ll SegmentTree::getSum(int l, int r, int t, int L, int R)
{
	if (r < L || R < l)
		return 0;
	if (l <= L && R <= r)
		return _sum[t];

	pushInfo(t, L, R);

	return getSum(l, r, 2 * t, L, (L + R) / 2) + 
					getSum(l, r, 2 * t + 1, (L + R) / 2 + 1, R);
}

void SegmentTree::assign(int l, int r, int value, int t, int L, int R)
{
	if (r < L || R < l)
		return ;

	if (l <= L && R <= r)
	{
		assignNode(t, L, R, value);
		return ;
	}

	pushInfo(t, L, R);

	assign(l, r, value, 2 * t, L, (L + R) / 2);
	assign(l, r, value, 2 * t + 1, (L + R) / 2 + 1, R);

	_sum[t] = _sum[2 * t] + _sum[2 * t + 1];
}

ll SegmentTree::getSum(int l, int r)
{
	return getSum(l, r, 1, 1, N);
}

void SegmentTree::assign(int l, int r, int value)
{
	assign(l, r, value, 1, 1, N);
}

SegmentTree tree;

int main()
{
	freopen("sum.in", "r", stdin);
	freopen("sum.out", "w", stdout);

	int n, k;
	scanf("%d%d\n", &n, &k);
	for (int i = 0; i < k; ++i)
	{
		char ch;
		scanf("%c", &ch);
		if (ch == 'A')
		{
			int l, r, v;
			scanf("%d%d%d\n", &l, &r, &v);
			tree.assign(l, r, v);
		}
		else if (ch == 'Q')
		{
			int l, r;
			scanf("%d%d\n", &l, &r);
			cout << tree.getSum(l, r) << endl;
		}
		else
			assert(0);
	}

	return 0;
}