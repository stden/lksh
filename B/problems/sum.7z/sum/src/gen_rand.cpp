#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include "rand.h"

using namespace std;

int random(int l, int r)
{
	return rand31() % (r - l + 1) + l;
}

int main( int argc, char *argv[] )
{
  int n = atoi(argv[1]), k = atoi(argv[2]), x = atoi(argv[3]), c = atoi(argv[4]);

  // n, k - see statements.
  // x - average length of the segments
  // numbers will be in range [0..c]

  printf("%d %d\n", n, k);
  while (k--){
    if (rand() % 3 < 2)
    {
      int a = random(1, n), b = random(max(1, a - x), min(n, a + x));
      printf("A %d %d %d\n", min(a, b), max(a, b), random(0, c));
    }
    else
    {
      int a = random(1, n), b = random(max(1, a - x), min(n, a + x));
      printf("Q %d %d\n", min(a, b), max(a, b));
    }
  }
  return 0;
}
