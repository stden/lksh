#include "testlib.h"

const int maxN = 100000;
const int maxK = 100000;
const int maxA = 1000000000;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxN);
  inf.readSpace();
  int k = inf.readInt(0, maxK);
  inf.readEoln();

  for (int i = 0; i < k; i++) {
    char c = inf.readChar();
    inf.readSpace();
    ensure(c == 'Q' || c == 'A');
    if (c == 'Q') {
      int l = inf.readInt(1, n);
      inf.readSpace();
      int r = inf.readInt(1, n);
      ensure(l <= r);
    } else if (c == 'A') {
      int l = inf.readInt(1, n);
      inf.readSpace();
      int r = inf.readInt(1, n);
      ensure(l <= r);
      inf.readSpace();
      inf.readInt(0, maxA);
    }
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}
