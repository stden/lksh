#!/bin/bash

for i in *.hand; do
  cp "$i" "${i/\.hand/}"
done

g++ -O2 -Wall gen_rand.cpp -o gen_rand

./gen_rand 30 100 10 10 > 02
./gen_rand 100 1000 10 100 > 03
./gen_rand 300 1000 10 100 > 04
./gen_rand 1000 100000 100 100 > 05
./gen_rand 3000 100000 1000 100 > 06
./gen_rand 10000 100000 100000 1000 > 07
./gen_rand 25000 100000 100000 1000 > 08
./gen_rand 50000 100000 100000 1000000 > 09
./gen_rand 100000 100000 100000 1000000000 > 10

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

