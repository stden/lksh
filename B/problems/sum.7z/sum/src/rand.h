
static int seed=0;
static unsigned int zeed=0;

static inline int rand8() {
  unsigned int x=zeed;
  for(int i=0;i<8;++i) {
    unsigned int z=x&0x02D;
    unsigned int s;
    for(s=0;z;s^=1,z&=(z-1));
    x=(x>>1)|(s<<31);
  }
  zeed=x;
  return x&0xFF;
}

static inline int rand31() {
  return (seed=(1664525*seed+1013904223)&0x7FFFFFFF);
}

static int tablex[256];
static int initialized=0;

void z_srand(int seed) {
  ::seed=seed;
  zeed=3562951413U;
  for(int i=0;i<256;++i) {
    tablex[i]=rand31();
  }
  initialized=1;
}

int z_rand() {
  if(!initialized) {
    z_srand(3141592653U);
  }
  int ind=rand8();
  int res=tablex[ind];
  tablex[ind]=rand31();
  return res&0x7FFF;
}
