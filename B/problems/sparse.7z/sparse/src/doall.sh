#!/bin/bash

for i in *.hand; do
  cp "$i" "${i/\.hand/}"
done

g++ gen_test.cpp -o gen_test

./gen_test 11 5 0			> 02
./gen_test 102 117 0		> 03
./gen_test 1013 1007 0		> 04
./gen_test 1017 17 0		> 05
./gen_test 113 100017 0		> 06
./gen_test 23 1000023 0		> 07
./gen_test 90113 1000117 0	> 08
./gen_test 50007 9000013 0	> 09
./gen_test 11 5 0         > 02
./gen_test 102 117 0      > 03
./gen_test 1013 1007 0        > 04
./gen_test 1017 17 0      > 05
./gen_test 113 100017 0       > 06
./gen_test 23 9000023 0      > 07
./gen_test 90113 1000117 0    > 08
./gen_test 50007 9000013 0    > 09
./gen_test 100000 10000000 0    > 10
./gen_test 1 10000000 0    > 11
./gen_test 100000 1 0    > 12
./gen_test 1 1 0    > 13

for i in `seq -w 14 30`; do
  ./gen_test 123 217 $i > $i
done

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests

