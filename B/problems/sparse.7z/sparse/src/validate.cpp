#include "testlib.h"

const int maxN = 100000;
const int maxM = 10000000;
const int maxA = 16714589 - 1;

int main() {
  registerValidation();
  int n = inf.readInt(1, maxN);
  inf.readSpace();
  inf.readInt(1, maxM);
  inf.readSpace();
  inf.readInt(0, maxA);
  inf.readEoln();

  inf.readInt(1, n);
  inf.readSpace();
  inf.readInt(1, n);
  inf.readEoln();
  inf.readEof();
  return 0;
}
