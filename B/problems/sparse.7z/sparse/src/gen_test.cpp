#include <cstdlib>
#include <iostream>
#include "random.h"

using namespace std;

int main(int argc, char** argv)
{
    if (argc == 4) {
             int n, m, a0, u0, v0;
             n = atoi (argv[1]);
             m = atoi (argv[2]);
             initrand ((n+m+17*atoi(argv[3])) % 113);
             if (atoi(argv[3]) != 0) {
                n = rndInt (99999)+1;
                m = rndInt (9999999)+1;
             }
             a0 = rndInt (16714589);
             u0 = rndInt (n)+1;
             v0 = u0 + rndInt(n - u0 + 1);
             cout << n << " " << m << " " << a0 << endl;
             cout << u0 << " " << v0 << endl;
    } else cerr << "not enough parameters" << endl;
    
    return 0;
}
