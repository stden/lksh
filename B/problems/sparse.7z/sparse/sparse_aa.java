import java.io.*;
import java.util.*;
import java.math.*;

public class sparse_aa implements Runnable {

	public static void main(String[] args) {
		new Thread(new sparse_aa()).start();
	}

	BufferedReader br;

	StringTokenizer st;

	PrintWriter out;

	boolean eof = false;

	Random rand = new Random(this.hashCode());

	public void run() {
		try {
			br = new BufferedReader(new FileReader(FNAME + ".in"));
			out = new PrintWriter(FNAME + ".out");
			solve();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(566);
		}
		out.close();
	}

	String nextToken() {
		while (st == null || !st.hasMoreTokens()) {
			try {
				st = new StringTokenizer(br.readLine());
			} catch (Exception e) {
				eof = true;
				return "0";
			}
		}
		return st.nextToken();
	}

	int nextInt() {
		return Integer.parseInt(nextToken());
	}

	long nextLong() {
		return Long.parseLong(nextToken());
	}

	double nextDouble() {
		return Double.parseDouble(nextToken());
	}

	BigInteger nextBigInteger() {
		return new BigInteger(nextToken());
	}

	void MyAssert(boolean u, String message) {
		if (!u) {
			throw new Error("Assertion failed!!! " + message);
		}
	}

	int inBounds(int x, int l, int r, String name) {
		MyAssert(l <= x && x <= r, name + " is not in bounds!!! " + x
				+ " not in [" + l + ".." + r + "]");
		return x;
	}

	String FNAME = "sparse_aa".substring(0, "sparse_aa".indexOf("_"));

	private void solve() throws IOException {
		// HashSet<Long> hs = new HashSet<Long>();
		// long time = System.currentTimeMillis();
		int n = inBounds(nextInt(), 1, 100000, "n");
		int m = inBounds(nextInt(), 1, 10000000, "m");
		int[] a = new int[n];
		a[0] = inBounds(nextInt(), 0, 16714588, "a[0]");
		for (int i = 1; i < a.length; i++) {
			a[i] = (23 * a[i - 1] + 21563) % 16714589;
		}
		int k = Integer.numberOfTrailingZeros(Integer.highestOneBit(n - 1)) + 2;
		int[][] b = new int[k][n];
		for (int i = 0; i < b[0].length; i++) {
			b[0][i] = a[i];
		}
		for (int i = 1; i < b.length; i++) {
			for (int j = 0; j < b[i].length; j++) {
				b[i][j] = Math.min(b[i - 1][j], j + (1 << (i - 1)) < n
						&& j + (1 << (i - 1)) >= 0 ? b[i - 1][j
						+ (1 << (i - 1))] : Integer.MAX_VALUE);
			}
		}
		int u = inBounds(nextInt(), 1, n, "u[1]") - 1;
		int v = inBounds(nextInt(), 1, n, "v[1]") - 1;
		for (int i = 0; i < m; i++) {
			// hs.add((long) u * n + v);
			int l = Integer.numberOfTrailingZeros(Integer.highestOneBit(Math
					.abs(u - v) + 1));
			int ans = Math.min(b[l][Math.min(u, v)], b[l][Math.max(u, v)
					- (1 << l) + 1]);
			if (i + 1 == m) {
				out.println((u + 1) + " " + (v + 1) + " " + ans);
			}
			u = ((17 * (u + 1) + 751 + ans + 2 * (i + 1)) % n);
			v = ((13 * (v + 1) + 593 + ans + 5 * (i + 1)) % n);
		}
		// System.out.pr+intln((System.currentTimeMillis() - time) / 1000.0);
		// System.out.println(hs.size());
	}
}
