#include <algorithm>
#include <cstdio>
#include <cstring>

using namespace std;

#define maxn 1100000

char s[maxn];
int z[maxn];

int main( void )
{
  freopen("basis.in", "r", stdin);
  freopen("basis.out", "w", stdout);

  gets(s);
  int n = strlen(s);

  int r = 0;

  for (int i = 1; i < n; i++)
  {
    z[i] = z[r] + r > i ? min(z[r] + r - i, z[i - r]) : 0;
    while (s[z[i]] == s[z[i] + i]) z[i]++;
    r = z[r] + r < z[i] + i ? i : r;
    if (z[i] == n - i)
    {
      printf("%d\n", i);
      return 0;
    }
  }
  printf("%d\n", n);

  
  return 0;
}