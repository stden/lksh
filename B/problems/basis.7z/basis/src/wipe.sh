#! /bin/bash

rm ../tests -rf
