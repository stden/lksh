#! /bin/bash

rm -rf ../tests
mkdir ../tests

for i in ??.hand; do
	cp "$i" ../tests/"${i/\.hand/}";
done

for i in gen??.dpr; do
	fpc $i -Mdelphi
	mv "${i/\.dpr/}" ../tests/
	echo "${i/\.dpr/.o}"
	sleep 1
	rm "${i/\.dpr/.o}"
	cd ../tests
	./"${i/\.dpr/}"
	rm "${i/\.dpr/}"
	cd ../src;
done

cd ../tests

fpc ../basis_pk.dpr -Mdelphi
mv ../basis_pk solve
rm ../basis_pk.o

for i in ??; do
	cp $i basis.in
	./solve
	mv basis.out $i.a;
done

rm solve
rm basis.in
cd ../src
