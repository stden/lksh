#include "testlib.h"
#include <string>
#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
  registerValidation();
  string s;
  getline(cin, s);

  ensure(s.length() <= 50001);
  int len = s.length();
  for(int i = 0; i < len - 1; i++)
  {
    ensure(('a' <= s[i] && s[i] <= 'z') || 'A' <= s[i] && s[i] <= 'Z');
  }

  inf.readEof();
}
