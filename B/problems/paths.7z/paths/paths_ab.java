import java.io.*;
import java.util.*;
import java.math.*;

public class paths_ab implements Runnable {

	final int MAXN = 1000;
	final int MAXM = 100000;
	
	private void solve() throws IOException {
		int n = in.nextInt();
		if (n < 1 || n > MAXN) throw new Error();
		int m = in.nextInt();
		if (m < 0 || m > MAXM) throw new Error();
		g = new ArrayList[n];
		for (int i = 0; i < n; ++i) {
			g[i] = new ArrayList<Integer>();
		}
		for (int i = 0; i < m; ++i) {
			int a = in.nextInt() - 1;
			int b = in.nextInt() - 1;
			if (a < 0 || a >= n) throw new Error();
			if (b < 0 || b >= n) throw new Error();
			g[a].add(b);
		}
		time = 0;
		u = new boolean[n];
		perm = new int[n];
		tm = new int[n];
		for (int i = 0; i < n; ++i) {
			if (!u[i]) {
				topsort(i);
			}
		}
		for (int i = 0; i < n; ++i) {
			for (int j : g[perm[i]]) {
				if (tm[j] >= i) throw new Error("Not acyclic");
			}
		}
		
		cl = new int[n];
		col = 1;
		p = new int[n];
		Arrays.fill(p, -1);
		int ans = 0;
		for (int i = 0; i < n; ++i) {
			++col;
			if (dfs(i)) ++ans;
		}
		out.println(n - ans);
	}

	private boolean dfs(int i) {
		cl[i] = col;
		for (int j : g[i]) {
			if (p[j] == -1 || cl[p[j]] != col && dfs(p[j])) {
				p[j] = i;
				return true;
			}
		}
		return false;
	}

	ArrayList<Integer>[] g;
	
	boolean[] u;
	int[] perm, tm, p;
	int time;
	int[] cl;
	int col;
	
	void topsort(int i) {
		u[i] = true;
		for (int j : g[i]) {
			if (!u[j]) {
				topsort(j);
			}
		}
		perm[time] = i;
		tm[i] = time;
		++time;
	}
	
	final String FILE_NAME = "paths";

	SimpleScanner in;
	PrintWriter out;

	@Override
	public void run() {
		try {
			in = new SimpleScanner(new FileReader(FILE_NAME + ".in"));
			out = new PrintWriter(FILE_NAME + ".out");
			solve();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public static void main(String[] args) {
		new Thread(new paths_ab()).start();
	}

	class SimpleScanner extends BufferedReader {

		private StringTokenizer st;
		private boolean eof;

		public SimpleScanner(Reader a) {
			super(a);
		}

		String next() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(readLine());
				} catch (Exception e) {
					eof = true;
					return "";
				}
			}
			return st.nextToken();
		}

		boolean seekEof() {
			String s = next();
			if ("".equals(s) && eof)
				return true;
			st = new StringTokenizer(s + " " + st.toString());
			return false;
		}

		private String cnv(String s) {
			if (s.length() == 0)
				return "0";
			return s;
		}

		int nextInt() {
			return Integer.parseInt(cnv(next()));
		}

		double nextDouble() {
			return Double.parseDouble(cnv(next()));
		}

		long nextLong() {
			return Long.parseLong(cnv(next()));
		}
	}
}