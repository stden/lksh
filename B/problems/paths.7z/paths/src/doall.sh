#!/bin/bash

cp 01{.t,}

javac TestsGen.java
java TestsGen
rm TestsGen.class

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

