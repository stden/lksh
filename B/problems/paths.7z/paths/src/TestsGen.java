import java.io.*;
import java.util.*;

public class TestsGen implements Runnable {
	public static void main(String[] args) {
		if (args.length < 1) {
			for (I = 1; (new File(getName(I) + ".t")).exists(); I++)
				;
		} else {
			I = Integer.parseInt(args[0]);
		}
		new Thread(new TestsGen()).start();
	}

	PrintWriter out;

	Random rand = new Random(6439586L);

	static int I;

	static String getName(int i) {
		return ((i < 10) ? "0" : "") + i;
	}

	void open() {
		try {
			System.out.println("Generating test " + I);
			out = new PrintWriter(getName(I));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	void close() {
		out.close();
		I++;
	}

	final String ALPHA = "abcdefghijklmnopqrstuvwxyz";

	String randString(int len, String alpha) {
		StringBuilder ans = new StringBuilder();
		int k = alpha.length();
		for (int i = 0; i < len; i++) {
			ans.append(alpha.charAt(rand.nextInt(k)));
		}
		return ans.toString();
	}

	long rand(long l, long r) {
		return l + (rand.nextLong() >>> 1) % (r - l + 1);
	}

	int rand(int l, int r) {
		return l + rand.nextInt(r - l + 1);
	}

	final int MAXN = 1000;
	final int MAXM = 100000;
	
	class Edge {
		int a, b;
		
		public Edge(int a, int b) {
			this.a = a;
			this.b = b;
		}
	}
	
	int[] randPerm(int n) {
		int[] p = new int[n];
		for (int i = 1; i < n; ++i) {
			int j = rand.nextInt(i);
			p[i] = p[j];
			p[j] = i;
		}
//		System.out.println(Arrays.toString(p));
		return p;
	}
	
	void save(ArrayList<Edge> g, int n) {
		int[] p = randPerm(n);
		Collections.shuffle(g);
		open();
		out.println(n + " " + g.size());
		for (Edge e : g) {
			out.println((p[e.a] + 1) + " " + (p[e.b] + 1));
		}
		close();
	}
	
	void genPaths(int n, int m, int k) {
		ArrayList<Edge> g = new ArrayList<Edge>();
		
		int[] sz = new int[k];
		int tn = n;
		for (int i = 0; i < k; ++i) {
			sz[i] = tn / (k - i);
			tn -= sz[i];
		}
		int f = 0;
		int[] s = new int[k];
		for (int i = 0; i < k; ++i) {
			s[i] = f;
			for (int j = 0; j < sz[i] - 1; ++j) {
				g.add(new Edge(f + j, f + j + 1));
				--m;
			}
			f += sz[i];
		}
		
		for (int i = 0; i < m; ++i) {
			int a = rand.nextInt(n);
			int b = rand.nextInt(n - 1);
			if (b >= a) ++b;
			g.add(new Edge(Math.min(a, b), Math.max(a, b)));
		}
		save(g, n);
	}
	
	
	void genRand(int n, int m) {
		ArrayList<Edge> g = new ArrayList<Edge>();
		
		for (int i = 0; i < m; ++i) {
			int a = rand.nextInt(n);
			int b = rand.nextInt(n - 1);
			if (b >= a) ++b;
			g.add(new Edge(Math.min(a, b), Math.max(a, b)));
		}
		
		save(g, n);
	}
	
	int[] choose(int n, int k) {
		return Arrays.copyOf(randPerm(n), k);
	}

	public void solve() throws IOException {
		genRand(2, 1);
		for (int i = 0; i < 5; ++i) {
			genRand(rand(2, 5), rand(5, 10));
		}
		for (int i = 0; i < 5; ++i) {
			int n = rand(5, 10);
			int m = rand(5, 20);
			int k = rand(1, n / 2);
			genPaths(n, m, k);
		}
		genRand(2, MAXM);
		genPaths(MAXN, MAXN - 1, 1);
		genRand(MAXN, 0);
		for (int i = 0; i < 5; ++i) {
			genRand(rand(MAXN / 2, MAXN), rand(MAXM / 2, MAXM));
		}
		for (int i = 0; i < 5; ++i) {
			int n = rand(MAXN / 2, MAXN);
			int m = rand(MAXM / 2, MAXM);
			int k = rand(1, n / 2);
			genPaths(n, m, k);
		}
		genPaths(MAXN, MAXM, 1);
		genPaths(MAXN, MAXM, 2);
	}

	void myAssert(boolean e) {
		if (!e) {
			throw new Error("Assertion failed");
		}
	}

	public void run() {
		try {
			solve();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
}