#include "testlib.h"

#include <vector>

using namespace std;

const int maxN = 1000;
const int maxM = 100000;

vector <int> c[maxN];
int u[maxN];

bool dfs( int v ) {
  u[v] = 1;
  for (int i = 0; i < (int)c[v].size(); i++) {
    int w = c[v][i];
    if (u[w] == 1) {
      return true;
    } else if (u[w] == 0 && dfs(w)) {
      return true;
    }
  }
  u[v] = 2;
  return false;
}

int main() {
  registerValidation();
  int n = inf.readInt(2, maxN);
  inf.readSpace();
  int m = inf.readInt(0, maxM);
  inf.readEoln();
  for (int i = 0; i < m; i++) {
    int a = inf.readInt(1, n);
    inf.readSpace();
    int b = inf.readInt(1, n);
    inf.readEoln();
    c[a - 1].push_back(b - 1);
  }
  inf.readEof();
  for (int i = 0; i < n; i++) {
    u[i] = 0;
  }
  for (int i = 0; i < n; i++) {
    if (!u[i] && dfs(i)) {
      ensure(false);
    }
  }
  return 0;
}
