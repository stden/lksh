#!/bin/bash

function compile() {
  fpc -Mdelphi $1.dpr -o$1
}

compile gen13
compile gen14
compile gen15
compile gen16
compile gen17
compile gen18
compile genchess
compile genev
compile genfull
compile genodd
compile genrnd
compile gentria

cp 01{.manual,}
t=1
function next_test {
  t=$((t+1))
  $* > $(printf '%02d' "$t")
}
next_test ./genchess 10 10
next_test ./genchess 100 100
next_test ./genfull 1 100
next_test ./genfull 100 1
next_test ./genfull 13 13
next_test ./genfull 100 100
next_test ./genev 21 41
next_test ./genev 99 95
next_test ./genodd 61 21
next_test ./genodd 99 95
next_test ./gentria 70 80 100
next_test ./gentria 100 100 1000
next_test ./gen13
next_test ./gen14
next_test ./gen15
next_test ./gen16
next_test ./gen17
next_test ./gen18
next_test ./genrnd 89 98 50
next_test ./genrnd 89 98 80
next_test ./genrnd 89 98 85
next_test ./genrnd 89 98 90
next_test ./genrnd 89 98 95
next_test ./genrnd 89 98 99

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

