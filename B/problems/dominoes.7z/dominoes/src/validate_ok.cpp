#include "testlib.h"

int main()
{
  registerValidation();
  int n = inf.readInt(1, 100);
  inf.readSpace();
  int m = inf.readInt(1, 100);
  inf.readSpace();
  inf.readInt(-1000, 1000);
  inf.readSpace();
  inf.readInt(-1000, 1000);
  inf.readEoln();

  for(int i = 0; i < n; i++)
  {
    for(int j = 0; j < m; j++)
    {
      char c = inf.readChar();
      ensure(c == '.' || c == '*');
    }
    inf.readEoln();      
  }
  inf.readEof();
}
