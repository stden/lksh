#include "testlib.h"

const int maxW = 100;
const int maxA = 1000;

int main() {
  registerValidation();
  int h = inf.readInt(1, maxW);
  inf.readSpace();
  int w = inf.readInt(1, maxW);
  inf.readSpace();
  inf.readInt(-maxA, maxA);
  inf.readSpace();
  inf.readInt(-maxA, maxA);
  inf.readEoln();
  for (int i = 0; i < h; i++) {
    for (int j = 0; j < w; j++) {
      char c = inf.readChar();
      ensure(c == '.' || c == '*');
    }
    inf.readEoln();
  }
  inf.readEof();
  return 0;
}
