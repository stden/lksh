#!/bin/bash

for i in *.manual; do
  cp "$i" "${i/\.manual/}"
done

fpc generate.dpr
./generate

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

