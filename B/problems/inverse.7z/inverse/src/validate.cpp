#include "testlib.h"
#include <algorithm>
#include <vector>

using namespace std;

const int MAX = 1000000000;

int main()
{
	registerValidation();

	vector <int> v;

	int n = inf.readInt(1, 50000);
	inf.readEoln();

	for (int i = 0; i < n; ++i)
	{
		v.push_back(inf.readInt(-MAX, MAX));
		if (i == n - 1)
			inf.readEoln();
		else
			inf.readSpace();
	}

	sort(v.begin(), v.end());
	for (int i = 1; i < n; ++i)
		ensure(v[i] != v[i - 1]);
	
	return 0;
}
