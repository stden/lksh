#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:30000000")

#include <string>
#include <vector>
//#include <cmath>
//#include <queue>
//#include <set>
//#include <map>
#include <algorithm>
#include <iostream>
#include <cstdio>
//#include <sstream>
#include <cassert>
#include <cstring>
//#include <utility>

using namespace std;

#define EPS 1E-8
const int INF = (int)1E+9;

#define C_IN_FILE "inverse.in"
#define C_OUT_FILE "inverse.out"

#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define forv(i, v) for (int i = 0; i < (int)(v.size()); ++i)
#define fors(i, s) for (int i = 0; i < (int)(s.length()); ++i)
#define all(a) a.begin(), a.end()
#define pb push_back
#define PII pair<int, int>
#define mp make_pair
#define VI vector<int>
#define VS vector<string>

const int NMAX = 100000;
const int list = 1 << 17;

int n, m, ans;
VI a, b;
int tree[list << 1];
int treel[list << 1];
int treer[list << 1];

void outdata() {
	printf("%d\n", ans);
}

int calc(int l) {
	int v = 1, res = 0;
	while (v < list) {
		v <<= 1;
		if (treer[v] < l) ++v; else {
			res += tree[v ^ 1];
		}
	}
	return res;
}

void update(int v, int b) {
	v += list;
	tree[v] = b;
	while (v > 1) {
		tree[v >> 1] = tree[v] + tree[v ^ 1];
		v >>= 1;
	}
}

void solve() {
	memset(tree, 0, sizeof tree);
	forn(i, list) treel[i + list] = treer[i + list] = i;
	for(int i = list - 1; i > 0; --i) treel[i] = treel[i << 1];
	for(int i = list - 1; i > 0; --i) treer[i] = treer[(i << 1) ^ 1];
	for(int i = n - 1; i >= 0; --i) {
		ans += calc(a[i]);
		update(a[i], 1);
	}
}

void readdata() {
	scanf("%d", &n);
	assert(1 <= n && n <= 50000);
	a = VI(n, 0);
	forn(i, n) scanf("%d", &a[i]);
	b = a;
	sort(all(b));
	forn(i, n) a[i] = (int)(lower_bound(all(b), a[i]) - b.begin());
	reverse(all(a));
}

int main() {
    freopen(C_IN_FILE, "rt", stdin);
    freopen(C_OUT_FILE, "wt", stdout);
	readdata();
	solve();
	outdata();
	return 0;
}

