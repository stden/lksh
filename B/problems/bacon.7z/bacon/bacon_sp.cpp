#include <cstdio>
#include <set>
#include <cassert>
#include <string>
#include <cstring>

using namespace std;

typedef unsigned int UI;

#define HSIZE 21417

class Hash
{
	UI val[HSIZE];
	UI val2[HSIZE];
	UI free[HSIZE];
	int tp;
	
	UI HF(UI key)
	{
		return key%HSIZE;
	}
public:
	Hash(int _tp):tp(_tp)
	{
		for (int i=0;i<HSIZE;i++)
			free[i] = 0;
	}
	
	void Init(int _tp)
	{
		tp = _tp;
	}
	
	bool Add(UI key, UI key2)
	{
		UI hf = HF(key);
		while ( 1 )
		{
			if ( free[hf]!=tp ) break;
			if ( val[hf]==key && val2[hf]==key2 ) return false;
			hf = (hf+1)%HSIZE;
		}
		
		val[hf] = key;
		val2[hf] = key2;
		free[hf] = tp;
		return true;
	}
};


const int MAX = 5100;
const UI PRIME = 59;
const UI PRIME2 = 34;

char a[MAX];
UI b[MAX];
int n;
//set<UI> hash;

int main()
{
	freopen("bacon.in", "r", stdin);
	freopen("bacon.out", "w", stdout);
	
	int n;
	int i, j;
	scanf("%s", a);
	n = strlen(a);
	assert(n>=1 && n<=5000);
	for (i=0;i<n;i++)
	{
		assert(a[i]>='a' && a[i]<='z');
		b[i] = a[i]-'a';
	}
	
	int ans = 0;
	Hash hash(0);
	for (i=1;i<=n;i++)
	{
		hash.Init(i);
		//hash.clear();
		UI tec = 0, tec2 = 0;
		UI tr = 1, tr2 = 1;
		for (j=0;j<i;j++)
		{
			if ( j!=0 ) tr *= PRIME;
			if ( j!=0 ) tr2 *= PRIME2;
			tec *= PRIME;
			tec += b[j];
			tec2 *= PRIME2;
			tec2 += b[j];
		}
		
		ans++;
		hash.Add(tec, tec2);
		//hash.insert(tec);
		
		for (j=i;j<n;j++)
		{
			tec = (tec-tr*b[j-i])*PRIME+b[j];
			tec2 = (tec2-tr2*b[j-i])*PRIME2+b[j];
			
			if ( hash.Add(tec, tec2) ) ans++;
			//if ( hash.find(tec)==hash.end() )
			//{
			//	ans++;
			//	hash.insert(tec);
			//}
		}
	}
	
	printf("%d\n", ans);
	return 0;
}
