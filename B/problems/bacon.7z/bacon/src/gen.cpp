#include<cstdio>
#include<iostream>
#include<sstream>
#include<cstdlib>
#include<cmath>
#include<vector>
#include<string>
#include<algorithm>
using namespace std;
typedef vector<int>VI;typedef vector<VI>VVI;
typedef vector<string>VS;
typedef pair<int,int>PII;
#define FOR(i,n) for((i)=0;(i)<(n);(i)++)
#define FORN(i,n) for((i)=(n)-1;(i)>=0;(i)--)
#define BE(a) ((a).begin()),((a).end())
#define SI(a) ((a).size())
#define PB push_back
#define MP make_pair
#define FORIT(i,a) for((i)=(a).begin();(i)!=(a).end();(i)++)
#define CLR(a,v) memset((a),(v),sizeof(a))
int random(int x) {
    return ((rand() << 15) | rand()) % x;
}

void gen(int caseno, int n, int lets) {
    char cs[100];
    string s;
    int i;
    s = string(n, 'a');
    FOR (i,n) s[i] = (char)('a' + random(lets));
    sprintf(cs, "%.2d", caseno);
    freopen(cs, "w", stdout);
    cout << s << endl;
    fclose(stdout);
}

int main() {
    srand(4733);
    int n, i;
    n = 21;
    gen(2, 2000, 1);
    gen(3, 2000, 2);
    gen(4, 2000, 2);
    gen(5, 2000, 4);
    gen(6, 2000, 26);
    gen(7, 1, 26);
    gen(8, 3, 26);
    gen(9, 1469, 10);
    gen(10, 600, 8);
    for (i = 11; i <= n; i++) gen(i, 1 + random(2000), 1 + random(26));
}
