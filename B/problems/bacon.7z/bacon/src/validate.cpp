#include "testlib.h"
#include <string>
#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
  registerValidation();
  string s;
  getline(cin, s);

  ensure(s.length() <= 2001);

  inf.readEof();
}
