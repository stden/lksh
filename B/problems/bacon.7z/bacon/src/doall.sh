#!/bin/bash

for i in *.hand; do
  cp "$i" "${i/\.hand/}"
done

g++ -O2 -Wall -o gen gen.cpp
./gen

rm -rf ../tests/
mkdir ../tests/
mv ?? ../tests/

