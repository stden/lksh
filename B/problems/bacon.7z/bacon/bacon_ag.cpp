#include<cstring>
#include<cstdio>
#include<iostream>
#include<sstream>
#include<cstdlib>
#include<cmath>
#include<vector>
#include<string>
#include<algorithm>
using namespace std;
typedef vector<int>VI;typedef vector<VI>VVI;
typedef vector<string>VS;
typedef pair<int,int>PII;
#define FOR(i,n) for((i)=0;(i)<(n);(i)++)
#define FORN(i,n) for((i)=(n)-1;(i)>=0;(i)--)
#define BE(a) ((a).begin()),((a).end())
#define SI(a) ((a).size())
#define PB push_back
#define MP make_pair
#define FORIT(i,a) for((i)=(a).begin();(i)!=(a).end();(i)++)
#define CLR(a,v) memset((a),(v),sizeof(a))

#define MAXN 10000

string s;
int dp[2][MAXN];
int a[MAXN];
int n;

void solve(void) {
    int cura, nexta, ret, i, j;
    n = SI(s);
    CLR(a,0);
    cura = 0;
    CLR(dp[cura],0);
    FOR (i,n) {
        nexta = cura ^ 1;
        FOR (j,n) if (s[i] != s[j]) dp[nexta][j] = 0;
        else dp[nexta][j] = 1 + (j ? dp[cura][j - 1] : 0);
        cura = nexta;
        FOR (j,i) a[j] = max(a[j], dp[cura][j]);
    }
    ret = 0;
    FOR (i,n) ret += i + 1 - a[i];
    cout << ret << endl;
}

int main() {
    freopen("bacon.in", "r", stdin);
    freopen("bacon.out", "w", stdout);
    cin >> s;
    solve();
    fclose(stdin);
    fclose(stdout);
}
