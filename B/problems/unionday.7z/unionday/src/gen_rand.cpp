#include <cstdio>
#include <cstdlib>

int xs[5010], ys[5010];

inline unsigned int zrand(){
  return (rand() & ~(-1 << 15) | (rand() << 15));
}

int main(int argc, char* argv[]){
  int n = atoi(argv[1]);
  srand(n + 1000);
  printf("%d\n",n);
  int i, j;
  for (i=1; i<=n; i++){
    xs[i] = zrand()%20001 - 10000;
    ys[i] = zrand()%20001 - 10000;
    for (j=1; j<i; j++){
      if ((xs[i] == xs[j]) && (ys[i] == ys[j])) break;
    }
    if (j < i) i--;
    else printf("%d %d\n", xs[i], ys[i]);
  }
  return 0;
}
