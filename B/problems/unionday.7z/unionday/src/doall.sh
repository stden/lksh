#!/bin/bash

for i in ??.hand 
do
	cp "$i" "../tests/${i/\.hand/}"
done

cd ../tests

g++ -o gen_rand ../src/gen_rand.cpp
g++ -o gen_chain ../src/gen_chain.cpp 
g++  -o gen_blocks ../src/gen_blocks.cpp
./gen_rand 15 > 06
./gen_rand 102 > 07
./gen_rand 1987 > 08
./gen_rand 4999 > 09

./gen_chain 30 > 10
./gen_chain 1111 > 11
./gen_chain 5000 > 12

./gen_blocks 876 3 > 13
./gen_blocks 2345 10 > 14
./gen_blocks 5000 5 > 15

rm gen_rand
rm gen_chain
rm gen_blocks
