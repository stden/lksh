#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;

int xs[5010], ys[5010];
int inds[5010]={0,1};

inline unsigned int zrand(){
  return (rand() & ~(-1 << 15) | (rand() << 15));
}

inline int randcor(){
  return zrand()%20001 - 10000;
}

int main(int argc, char* argv[]){
  int n = atoi(argv[1]);
  srand(n + 2000);
  printf("%d\n",n);
  int i, a, b;
  xs[1] = randcor();
  ys[1] = randcor();
  while (1){
    a = zrand()%201 - 100;
    b = zrand()%201 - 100;
    if (!a && !b) continue;
    int nx = xs[1] + (n-1)*a;
    int ny = ys[1] + (n-1)*b;
    if ((-10000 <= nx) && (nx <= 10000) && (-10000 <= ny) && (ny <= 10000)) break;
  }
  for (i=2; i<=n; i++){
    xs[i] = xs[i-1] + a;
    ys[i] = ys[i-1] + b;
    inds[i] = i;                 
  }
  random_shuffle(inds+1, inds+n+1);
  for (i=1; i<=n; i++){
    printf("%d %d\n", xs[inds[i]], ys[inds[i]]);
  }
  return 0;
}
