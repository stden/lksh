#include "testlib.h"
#include <vector>
#include <set>

using namespace std;

typedef pair < int, int > pii;

const int MAXN = 5000;
const int MAXX = 10000;

int main()
{
	registerValidation();

	set <pii> points;

	int n = inf.readInt(1, MAXN);
	inf.readEoln();

	for (int i = 0; i < n; ++i)
	{
		int x = inf.readInt(-MAXX, MAXX);
		inf.readSpace();
		int y = inf.readInt(-MAXX, MAXX);
		inf.readEoln();

		ensure(points.find(pii(x, y)) == points.end());
		points.insert(pii(x, y));
	}

	inf.readEof();
	
	return 0;
}
