#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;

int xs[5010], ys[5010];
int kx[5010], ky[5010];

inline unsigned int zrand(){
  return (rand() & ~(-1 << 15) | (rand() << 15));
}

inline int randcor(){
  return zrand()%20001 - 10000;
}

int main(int argc, char* argv[]){
  int n = atoi(argv[1]);
  unsigned int k = atoi(argv[2]);
  srand(n + k + 3000);
  printf("%d\n",n);
  int i, j, a, b;
  for (i=0; i<k; i++){
    kx[i] = randcor();
    ky[i] = randcor();
  }
  for (i=1; i<=n; i++){
    int ck = zrand()%k;
    while (1){
      int nx = kx[ck] + rand()%201 - 100;
      int ny = ky[ck] + rand()%201 - 100;
      int ok = 1;
      for (j=1; j<i; j++) if ((xs[j] == nx) && (ys[j] == ny)) ok = 0;
      if (ok){
        xs[i] = nx;
        ys[i] = ny;
        break;
      }
    }
    printf("%d %d\n", xs[i], ys[i]);
  }
  return 0;
}
