#define _CRT_SECURE_NO_DEPRECATE
#include <cstdio>
#include <cmath>
#include <cassert>

const double INF = 1e100;

int n;
int xs[5010], ys[5010];
char used[5010];
double d[5010];

inline double dist(int a, int b){
  return sqrt(double((xs[a]-xs[b])*(xs[a]-xs[b]) + (ys[a]-ys[b])*(ys[a]-ys[b])));
}

int main(){
  freopen("unionday.in", "r", stdin);
  freopen("unionday.out", "w", stdout);
  int i, j;
  scanf("%d", &n);
  assert(1<=n && n<=5000);
  for (i=1; i<=n; i++){
    scanf("%d%d", &xs[i], &ys[i]);
    assert(-10000<=xs[i] && xs[i]<=10000 && -10000<=ys[i] && ys[i]<=10000);
    for (j=1; j<i; j++) assert((xs[i]!=xs[j]) || (ys[i]!=ys[j]));
    d[i] = INF;
  }
  d[1] = 0;
  double ans = 0;
  while (1){
    int bi = 0;
    double bd = INF;
    for (i=1; i<=n; i++){
      if ((!used[i]) && (d[i] < bd)){
        bd = d[i];
        bi = i;
      }
    }
    if (!bi) break;
    ans += bd;
    used[bi] = 1;
    for (i=1; i<=n; i++){
      double t = dist(bi, i);
      if (t < d[i]) d[i] = t;
    }
  }
  printf("%.10lf\n", ans);
  return 0;
}